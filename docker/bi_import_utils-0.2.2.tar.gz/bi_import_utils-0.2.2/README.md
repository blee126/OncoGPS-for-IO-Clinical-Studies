# bi_import_utils

## Installing for development
Install using `python setup.py develop`. This will create softlinks in your
Python installation to your local copy of the repo such that changes will be
reflected immediately.

## Installing for general use
```
pip install bi_import_utils-x.y.z.tar.gz
```

## Testing
To run tests, install `pytest` package. Change into this repo and execute
`pytest` from the command line.

## Building a release version
To build a release, bump version as necessary in `setup.py` and execute
```
python setup.py sdist
```

## Installing for general use
```
pip install bi_import_utils-x.y.z.tar.gz
```

## TODO
* Update the metadata import part with new convension. Enrich examples.
* Document additional data types (fusions, sparse, rppa)
* Add usage examples for additional data types (fusions, sparse, rppa)

