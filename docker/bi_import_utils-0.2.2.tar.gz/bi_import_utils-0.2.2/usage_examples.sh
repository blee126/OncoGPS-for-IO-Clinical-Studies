#!/bin/bash

IN='usage_examples'
OUT='usage_examples_output'
SPARSE='tests/data'
mkdir -p ${OUT}

# See below examples of formatting gene-list, omics tables, and metadata tables.

# 1) Gene list
import_data_table genes ${IN}/gene_list.txt ${OUT}/gene_list.tbl --use-synonyms

# 2) Gene expression statitics
import_data_table genestats ${IN}/gene_expression_stats.tsv ${OUT}/gene_expression_stats.tbl --use-synonyms --duplicate-genes-p-value-column "P-value"

# 3) Omics tables
# Gene somatic mutation table
import_data_table omics ${IN}/gene_somatic_mutation.tsv somatic_mutation D4C ${OUT}/gene_somatic_mutation.tbl --use-synonyms

# Gene somatic mutation table (Mouse genes)
import_data_table omics ${IN}/gene_somatic_mutation_Mouse.tsv somatic_mutation D4C ${OUT}/gene_somatic_mutation_Mouse.tbl --map-to-human-orth mouse --use-synonyms

# Gene expression table
import_data_table omics ${IN}/gene_expression.tsv rna_expression D4C ${OUT}/gene_expression.tbl --use-synonyms

# Gene methylation table
import_data_table omics ${IN}/gene_methylation.tsv methylation D4C ${OUT}/gene_methylation.tbl --use-synonyms

# Gene hypermethylation table
import_data_table omics ${IN}/gene_hypermethylation.tsv hypermethylation D4C ${OUT}/gene_hypermethylation.tbl --use-synonyms

# Gene copy-loss table
import_data_table omics ${IN}/gene_copy_loss.tsv copy_loss D4C ${OUT}/gene_copy_loss.tbl --use-synonyms

# Gene copy-gain table
import_data_table omics ${IN}/gene_copy_gain.tsv copy_gain D4C ${OUT}/gene_copy_gain.tbl --use-synonyms

# Gene expression, transposed table
import_data_table omics ${IN}/gene_expression_transpose.tsv rna_expression D4C ${OUT}/gene_expression_transpose.tbl --use-synonyms --transpose

# Gene expression, transposed table, use max value from duplicated genes
import_data_table omics ${IN}/gene_expression_transpose_max.tsv rna_expression D4C ${OUT}/gene_expression_transpose_max.tbl --use-synonyms --transpose --duplicate-genes max

# Gene expression, transposed table (mouse genes)
import_data_table omics ${IN}/gene_expression_transpose_Mouse.tsv rna_expression D4C ${OUT}/gene_expression_transpose_Mouse.tbl --use-synonyms --transpose --map-to-human-orth mouse --map-to-human-high-conf-only

# Gene expression, genes represented as ensembl ids, use mean value from duplicated genes
import_data_table omics ${IN}/gene_expression_mean_ensembl.tsv rna_expression D4C ${OUT}/gene_expression_mean_ensembl.tbl --use-synonyms --use-ensembl --duplicate-genes mean

# 4) Metadata tables
# Metadata table, extensive examples of different metadata variables
import_data_table metad ${IN}/metadata.tsv ${IN}/metadata.yaml D4C ${OUT}/metadata.tbl

# Metadata table, misc: numeric, categorical, character, and censored data
import_data_table metad ${IN}/metadata_misc.tsv ${IN}/misc.yaml D4C ${OUT}/meta_misc.tbl

# Metadata table, gene/hotspot mutations
import_data_table metad ${IN}/metadata_mutation.tsv ${IN}/mut.yaml D4C ${OUT}/meta_mutation.tbl

# 5)Cell-type specific signatures table
# Cell-type specific signatures table
import_data_table cell_type_signatures ${IN}/cell_type_signatures.tsv ${OUT}/cell_type_signatures.tbl --use-synonyms

# Cell-type specific signatures transposed table
import_data_table cell_type_signatures ${IN}/cell_type_signatures_transpose.tsv ${OUT}/cell_type_signatures_transpose.tbl --use-synonyms --transpose

# Cell-type specific signatures with genes represented by ensembl ids
import_data_table cell_type_signatures ${IN}/cell_type_signatures_ensembl.tsv ${OUT}/cell_type_signatures_ensembl.tbl --use-synonyms --use-ensembl

# Cell-type specific signatures transposed table, use median value from duplicated genes
import_data_table cell_type_signatures ${IN}/cell_type_signatures_median_transpose.tsv ${OUT}/cell_type_signatures_median_transpose.tbl --use-synonyms --duplicate-genes median --transpose

# Cell-type specific signatures table, use mean value from duplicated genes
import_data_table cell_type_signatures ${IN}/cell_type_signatures_mean.tsv ${OUT}/cell_type_signatures_mean.tbl --use-synonyms --duplicate-genes mean

# Cell-type specific signatures table with genes represented as ensembl ids, use max value from duplicated genes
import_data_table cell_type_signatures ${IN}/cell_type_signatures_ensembl_max.tsv ${OUT}/cell_type_signatures_ensembl_max.tbl --use-synonyms --duplicate-genes max --use-ensembl

# 6) Phosphoprotein tables
# Phosphoprotein/gene data table with genes represented as ensembl ids, use median value from duplicated genes
import_data_table modified_protein_abundance ${IN}/phosphoprotein_expression_ensembl_median.tsv D4C ${OUT}/phosphoprotein_expression_ensembl_median.tbl --duplicate-features median --use-ensembl

# Phosphoprotein/gene data transposed table with genes represented as ensembl ids, use max value from duplicated genes
import_data_table modified_protein_abundance usage_examples/phosphoprotein_expression_ensembl_max_transpose.tsv D4C ${OUT}/phosphoprotein_expression_ensembl_max_transpose.tbl --transpose --use-ensembl --duplicate-features max

# Modified protein/gene data table with phosphorylation as well as pipetide sequences
import_data_table modified_protein_abundance ${IN}/modified_protein_expression.tsv D4C ${OUT}/modified_protein_expression.tbl

# 7) Single cell data - sparse tool
# Data will be written as integers, genes are represented as ensembl ids, use max value from duplicate genes
import_data_table sparse --use-ensembl --counts ${SPARSE}/counts_ensembl_duplicates.mtx ${SPARSE}/mtx_genes_ensembl_duplicates.txt \
    ${SPARSE}/mtx_cells_ensembl_duplicates.txt D4C ${SPARSE}/d4c_counts_ensembl_duplicates_max.mtx --duplicate-genes max

# Transposed table, genes are represented as ensembl ids, use median value from duplicate genes
import_data_table sparse --use-ensembl ${SPARSE}/decimals_ensembl_duplicates_transpose.mtx ${SPARSE}/mtx_genes_ensembl_duplicates.txt \
    ${SPARSE}/mtx_cells_ensembl_duplicates.txt D4C ${SPARSE}/d4c_decimals_ensembl_duplicates_median_transpose.mtx --duplicate-genes median --transpose

# Mouse genes, use mean value from duplicate genes
import_data_table sparse --map-to-human-orth mouse ${SPARSE}/decimals_ensembl_duplicates.mtx ${SPARSE}/mtx_genes_mouse_duplicates.txt \
    ${SPARSE}/mtx_cells_ensembl_duplicates.txt D4C ${SPARSE}/d4c_decimals_mouse_duplicates_mean.mtx --duplicate-genes mean

# 8) numeric features tool - Data table with arbitrary numeric features
# use median value from duplicate features
import_data_table numeric_features ${IN}/gene_expression_median.tsv D4C D4C \
    ${OUT}/numeric_features_duplicates_median.tbl --duplicate-features median

# Transposed table, use mean value from duplicate features
import_data_table numeric_features ${IN}/numeric_features_duplicates_transpose.tsv D4C D4C \
    ${OUT}/numeric_features_duplicates_mean_transpose.tbl --duplicate-features mean --transpose

# 9) Cell-type fractions - Data table with cell-type fractions
# Cell-type fractions table
import_data_table cell_type_fractions ${IN}/cell_type_fractions.tsv D4C ${OUT}/cell_type_fractions.tbl

# Cell-type fractions transposed table
import_data_table cell_type_fractions ${IN}/cell_type_fractions_transpose.tsv D4C \
    ${OUT}/cell_type_fractions_transpose.tbl --transpose

# 9) gene fusions
# Gene fusions table
import_data_table fusions ${IN}/gene_fusions_duplicates.tsv D4C ${OUT}/gene_fusions_duplicates.tbl

# Mouse gene fusions
import_data_table fusions ${IN}/gene_fusions_duplicates_mouse.tsv D4C ${OUT}/gene_fusions_duplicates_mouse.tbl \
  --map-to-human-orth mouse --dont-reorder-items

# Mouse gene fusions, get max value from duplicate features, reorder genes in fusions
import_data_table fusions ${IN}/gene_fusions_duplicates_mouse.tsv D4C ${OUT}/gene_fusions_duplicates_mouse_max.tbl \
 --map-to-human-orth mouse --duplicate-features max

# Gene fusions table with genes represented by ensembl ids,
# get min value from duplicate features, don't reorder genes in fusions
import_data_table fusions ${IN}/gene_fusions_duplicates_ensembl.tsv D4C ${OUT}/gene_fusions_duplicates_ensembl_min.tbl \
 --use-ensembl --duplicate-features min

### IMPORT UTILS ###
# convert gene identifiers to HGNC symbols
import_utils genes_to_hgnc ${IN}/gene_list.txt ${OUT}/genes.tsv

# convert gene identifiers, which are represented as ensembl ids
import_utils genes_to_hgnc ${IN}/gene_ensembl.tsv ${OUT}/genes_ensembl.tsv --use-ensembl

# convert gene identifiers, which are represented as ensembl ids and use map-to-human othology mapping
import_utils genes_to_hgnc ${IN}/genes_mouse_ensembl.tsv ${OUT}/genes_mouse_ensembl.tsv \
    --use-synonyms --use-ensembl --map-to-human-orth mouse
