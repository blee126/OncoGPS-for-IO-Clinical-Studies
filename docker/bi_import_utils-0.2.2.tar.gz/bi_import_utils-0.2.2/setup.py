import sys
from setuptools import setup, find_packages

ep = {
    'console_scripts': [
        'import_data_table = bi_import_utils.import_data_table:main',
        'import_domain = bi_import_utils.import_domain:main',
        'import_utils = bi_import_utils.utils:main'
    ],
}

if sys.version_info >= (3, 7):  # for python <= 3.6 pandas >= 1.0 cannot be installed
    INSTALL_REQUIRES = [
        'pyyaml',
        'pandas<1.2.0,>=1.0.0',  # version for tests to pass (in newer versions numeric precision has changed)
        'scipy>=1.1.0',
        'six',
        'plotly>=4.5.0',
        'numpy',
        'scikit-learn',
        'natsort',
        'scanpy==1.7.2'
    ]
else:
    INSTALL_REQUIRES = [
        'pyyaml',
        # 'pandas==0.24.2',
        'pandas>=0.21.1',
        'scipy>=1.1.0',
        'six',
        'plotly>=4.5.0',
        'numpy',
        'scikit-learn',
        'natsort'
    ]

setup(
    name='bi_import_utils',
    packages=['bi_import_utils'],
    entry_points=ep,
    version='0.2.2',
    author='Data4Cure, Inc.',
    author_email='roy@data4cure.com',
    description='Utilites for formatting & preparing data for import into the Biomedical Intelligence Cloud.',
    include_package_data=True,
    install_requires=INSTALL_REQUIRES,
)

# package_data={
#     '': ['*.sh'],
#     'data': ['*'],
# },

# packages=find_packages('bi_import_utils'),
# package_dir={'':'bi_import_utils'},
