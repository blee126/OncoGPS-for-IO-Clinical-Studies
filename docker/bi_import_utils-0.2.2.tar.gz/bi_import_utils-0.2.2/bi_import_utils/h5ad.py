import numpy as np
import pandas as pd
import scanpy as sc
import scipy.sparse as sp
from anndata import AnnData
import warnings
import sys
from bi_import_utils import sparse
from bi_import_utils import omics
from bi_import_utils import commons

NAN_VALUES = ['None', 'nan', 'null', 'none', '', 'NA', '<NA>', np.nan]
warnings.simplefilter(action='ignore', category=FutureWarning)


def decode_bytes(row):
    return [el.decode('utf-8') if isinstance(el, bytes) else el for el in row]


def check_anndata(adata, verbose):
    # Decode bytes
    adata.var_names = decode_bytes(adata.var_names)
    adata.obs_names = decode_bytes(adata.obs_names)
    adata.obs = adata.obs.apply(decode_bytes, axis=0)
    adata.var = adata.var.apply(decode_bytes, axis=0)
    # Remove unneeded adata attributes to limit output h5ad file size
    if adata.var is not None:
        del adata.var
        if verbose:
            sys.stderr.write('\nadata.var was removed\n')
    if adata.uns is not None and adata.uns:
        del adata.uns
        if verbose:
            sys.stderr.write('\nadata.uns was removed\n')
    if adata.layers is not None and adata.layers:
        del adata.layers
        if verbose:
            sys.stderr.write('\nadata.layers was removed\n')
    if adata.raw is not None and adata.raw:
        del adata.raw
        if verbose:
            sys.stderr.write('\nadata.raw was removed\n')
    if adata.varm is not None and adata.varm:
        del adata.varm
        if verbose:
            sys.stderr.write('\nadata.varm was removed\n')
    if adata.varp is not None and adata.varp:
        del adata.varp
        if verbose:
            sys.stderr.write('\nadata.varp was removed\n')
    if adata.obsp is not None and adata.obsp:
        del adata.obsp
        if verbose:
            sys.stderr.write('\nadata.obsp was removed\n')
    return adata


def prepare_metadata(meta, unique_thresh, verbose):
    todrop = []
    for col in meta:
        meta[col].replace(NAN_VALUES, np.nan, inplace=True)
        try:
            if meta[col].isnull().all():
                todrop.append(col)
                sys.stderr.write('\nColumn {} from metadata contains only NaNs - it was removed\n'.format(col))
            elif all(el.is_integer() for el in meta[col].astype(float)):
                if len(meta[col].unique()) <= unique_thresh:
                    if verbose:
                        sys.stderr.write('\nColumn {} from metadata has less than {} unique integers ({}...) - '
                                         'it is saved as categorical\n'.
                                         format(col, unique_thresh,
                                                ', '.join([str(el) for el in meta[col].unique()[:5]])))
                    raise ValueError
                meta[col] = meta[col].astype(int)
            else:
                if len(meta[col].unique()) <= unique_thresh:
                    if verbose:
                        sys.stderr.write('\nColumn {} from metadata has less than {} unique floats ({}...) - '
                                         'it is saved as categorical\n'.
                                         format(col, unique_thresh,
                                                ', '.join([str(el) for el in meta[col].unique()[:5]])))
                    raise ValueError
                meta[col] = meta[col].astype(float)
        except ValueError:
            meta[col] = meta[col].astype(str)
    meta.drop(todrop, axis=1, inplace=True)
    return meta


def format_file(
        input_file,
        output_file,
        matrix_type,
        obs_metadata=None,
        unique_thresh=None,
        use_ensembl=False,
        use_synonyms=True,
        no_hgnc_match=False,
        duplicate_genes='first',
        verbose=False,
        no_save_dropped=False,
        map_to_human_orth=None,
        map_to_human_high_conf_only=False,
        map_to_human_orth_more=False,
        map_to_human_orth_all=False,
        map_to_human_expand_with_random_noise=False,
        map_to_human_orth_more_duplicate_genes=None
):

    if map_to_human_orth is not None and map_to_human_orth_more_duplicate_genes is None:
        map_to_human_orth_more_duplicate_genes = 'mean'
    if verbose:
        sys.stderr.write('\nLoading h5ad file from {}\n'.format(input_file))

    input_adata = check_anndata(sc.read_h5ad(input_file), verbose)
    if verbose:
        sys.stderr.write('\nInput data size: {}\n'.format(input_adata.shape))

    # if input matrix contains counts it can be easily normalized
    if matrix_type == 'counts':
        if verbose:
            sys.stderr.write('\nNormalization of input counts matrix\n')
        sc.pp.normalize_per_cell(input_adata, counts_per_cell_after=1e4)
        sc.pp.log1p(input_adata, base=2)
        if 'log1p' in input_adata.uns:
            del input_adata.uns['log1p']
        matrix_type = 'log2-transformed'

    if sp.issparse(input_adata.X):
        sm, gene_names, cell_names, dropped_elements = sparse.process(
            input_adata.X.T,
            list(input_adata.var_names),
            list(input_adata.obs_names),
            map_to_human_orth=map_to_human_orth,
            map_to_human_high_conf_only=map_to_human_high_conf_only,
            use_ensembl=use_ensembl,
            use_synonyms=use_synonyms,
            no_hgnc_match=no_hgnc_match,
            duplicate_genes=duplicate_genes,
            verbose=verbose,
            map_to_human_orth_more=map_to_human_orth_more,
            map_to_human_orth_all=map_to_human_orth_all,
            map_to_human_expand_with_random_noise=map_to_human_expand_with_random_noise,
            map_to_human_orth_more_duplicate_genes=map_to_human_orth_more_duplicate_genes
        )
        input_adata = input_adata[[el for el in input_adata.obs_names if el in cell_names], :]
        adata = AnnData(sm.T.astype(np.float32), obs=input_adata.obs, var=pd.DataFrame({}, index=gene_names))
        if input_adata.obsm is not None and input_adata:
            adata.obsm = input_adata.obsm
    else:
        adata_df = pd.DataFrame(input_adata.X, index=list(input_adata.obs_names), columns=list(input_adata.var_names))
        df, dropped_elements = omics.process(
            adata_df,
            "rna_expression",
            use_ensembl=use_ensembl,
            use_synonyms=use_synonyms,
            no_hgnc_match=no_hgnc_match,
            map_to_human_orth=map_to_human_orth,
            map_to_human_high_conf_only=map_to_human_high_conf_only,
            duplicate_genes=duplicate_genes,
            verbose=verbose,
            map_to_human_orth_more=map_to_human_orth_more,
            map_to_human_orth_all=map_to_human_orth_all,
            map_to_human_expand_with_random_noise=map_to_human_expand_with_random_noise,
            map_to_human_orth_more_duplicate_genes=map_to_human_orth_more_duplicate_genes
        )
        input_adata = input_adata[[el for el in input_adata.obs_names if el in df.index], :]
        adata = AnnData(df.astype(np.float32), obs=input_adata.obs, var=pd.DataFrame({}, index=df.columns))
        if input_adata.obsm is not None and input_adata:
            adata.obsm = input_adata.obsm

    # if input anndata does not contain embedding it is added here
    if not adata.obsm:
        warnings.warn('Input AnnData does not contain any embedding, '
                      'consider analysis of this dataset by D4C single cell app.')
        if verbose:
            sys.stderr.write('\nCalculating PCA and UMAP embeddings\n')
        sc.tl.pca(adata, n_comps=10, random_state=0)
        sc.pp.neighbors(adata, n_neighbors=10, n_pcs=10, random_state=0)
        sc.tl.umap(adata, random_state=2, a=0.5830300205483709, b=1.334166992455648)
        del adata.obsp
        del adata.varm
        del adata.uns

    matrix_type_rename = {
        'log2-transformed': 'log2-transformed',
        'logn-transformed': 'natural-log-transformed',
        'scaled': 'standardized (z-scores)',
        'other': 'other'
    }
    adata.uns['X_values_info'] = matrix_type_rename[matrix_type]

    # Rewritting expression matrix to correct type and adding X_T layer
    # improves speed of the single-cell browser
    try:
        adata.X = adata.X.tocsr().astype(np.float32)
    except AttributeError:
        adata.X = sp.csr_matrix(adata.X).astype(np.float32)
    adata.layers['X_T'] = adata.X.tocsc().astype(np.float32)

    if unique_thresh is None:
        if adata.shape[0] <= 1e3:
            unique_thresh = 30
        else:
            unique_thresh = 50

    if obs_metadata is not None:
        if verbose:
            sys.stderr.write('\nAdding metadata from {}\n'.format(obs_metadata))
        adata.obs = pd.concat([adata.obs, pd.read_csv(obs_metadata, index_col=0)], axis=1)
    if adata.obs.empty:
        warnings.warn('There is no cells metadata in the given file')
    else:
        adata.obs = prepare_metadata(adata.obs, unique_thresh, verbose)

    if verbose:
        sys.stderr.write('\nSaving h5ad file to {}, size: {}\n'.format(output_file, adata.shape))
    adata.write(output_file)

    if not no_save_dropped and not dropped_elements.empty:
        commons.write_dropped_aggregated_as_tsv(dropped_elements, output_file, verbose)

    return adata

