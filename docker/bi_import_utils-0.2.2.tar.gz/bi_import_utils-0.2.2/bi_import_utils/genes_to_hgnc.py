import sys
import re
import pandas as pd
from collections import OrderedDict

from bi_import_utils import commons

'''
Convert genes to HGNC symbols.

Copyright 2020 Data4Cure, Inc. All rights reserved.
'''


def read(input_file, verbose=False):
    """Read line-separated file with genes.

    Parameters
    ----------
    input : txt
        Path to input file containing gene identifiers.
    verbose : bool, optional
        If True, print logging information to stderr.

    Returns
    -------
    genes : list
        List of gene identifiers.

    """

    def split_genes_string(gs):
        """Splits on commas and any whitespace (incl. new lines)"""
        return [x for x in re.sub(r'\s', ',', gs).split(',') if x]

    if verbose:
        sys.stderr.write('\nReading input from {}\n'.format(input_file))

    with open(input_file, 'r') as f:
        genes = split_genes_string(f.read())

    return genes


def process(genes, use_ensembl=False, use_synonyms=True, map_to_human_orth=None,
            map_to_human_high_conf_only=False, verbose=False, map_to_human_orth_more=False,
            map_to_human_orth_all=False):
    """Process list with gene identifiers.

    Parameters
    ----------
    genes : list
        List of gene identifiers.
    use_ensembl : bool, optional
        If True, convert ENSEMBL ids (rows in the dataframe) to HGNC gene names.
    use_synonyms : bool, optional
        If True, try to match gene names in the dataframe to HGNC gene names using synonyms when
        possible.
    map_to_human_orth : bool, optional
        Map from non-human to human genes using 1-to-1 orthology relationships.
    map_to_human_high_conf_only : bool, optional
        When converting from non-human to human genes using the 1-to-1  orthology
        relationships, use only the high-confidence subset.
    verbose : bool, optional
        If True, print logging information to stderr.
    map_to_human_orth_more : bool, optional
        If True, one2many and many2many orthology relationships where multiple human genes correspond
        to a mouse gene, will result in duplicating the data of said mouse gene into multiple
        (identical) columns in the output.
    map_to_human_orth_all : bool, optional
        If True, result in ignoring confidence (high-confidence / low-confidence) information
        when expanding data from a single mouse gene to multiple human genes, otherwise when both
        high- and low-confidence mappings exist for a given mouse gene, only the high-confidence subset will be used.

    Returns
    -------
    genes: list
        List of converted genes to HGNC symbols.
    """
    if verbose:
        sys.stderr.write('\nLoaded gene identifiers: {}\n'.format(len(genes)))

    # remove duplicates and keep order of genes
    genes = list(OrderedDict.fromkeys(genes))

    # not used anywhere, just to meet requirements of other functions
    dropped_elements = pd.DataFrame(index=genes).assign(HGNC_symbol=genes, description=None)

    # converting ENSEMBL ids to HGNC gene names and remove duplicates
    if use_ensembl:
        genes, _ = commons.translate_ensembl_ids_to_hgnc([g.upper() for g in genes], dropped_elements)
        if verbose:
            sys.stderr.write('\nGenes after converting ensembl ids to HGNC symbol names): '
                             '{}\n'.format(len(genes)))

    # mouse -> human genes orthology mapping
    if map_to_human_orth is not None:
        m2h_d = commons.read_predefined_orth_dict(
            species=map_to_human_orth,
            high_conf_orthology_only=map_to_human_high_conf_only,
            input_genes=genes,
            map_to_human_orth_more=map_to_human_orth_more,
            map_to_human_orth_all=map_to_human_orth_all
        )
        genes_h = []
        for gene in genes:
            if gene in m2h_d:
                genes_h += m2h_d[gene]
        genes = genes_h
        del genes_h

    genes = [g.upper() for g in genes]

    if verbose:
        sys.stderr.write('\nGenes: {}\n'.format(len(genes)))

    genes = commons.match_HGNC_names(genes, use_syn=use_ensembl or use_synonyms)
    if verbose:
        sys.stderr.write('\nFinal gene list (HGNC matched, duplicates removed): '
                         '{}\n'.format(len(genes)))

    return genes


def write(genes, output_file, verbose):
    """Write processed genes to file.

    Parameters
    ----------
    genes: list
        List of converted genes to HGNC symbols.
    output_file: str
        Path to write txt file to.
    verbose : bool, optional
        If True, print logging information to stderr.
    """

    with open(output_file, 'w') as f:
        for gene in genes:
            f.write('{}\n'.format(gene))

    if verbose:
        sys.stderr.write('\nWrote converted genes to: {}\n'.format(output_file))


def format_file(input_file, output_file, use_ensembl=False, use_synonyms=True, map_to_human_orth=None,
                map_to_human_high_conf_only=False, verbose=False, map_to_human_orth_more=False,
                map_to_human_orth_all=False):
    """Read file containing gene identifiers and save converted HGNC symbol as file.

    Parameters
    ----------
    input_file : txt
        Path to input file containing gene identifiers.
    output_file: str
        Path to write tbl file to.
    use_ensembl : bool, optional
        If True, convert ENSEMBL ids (rows in the dataframe) to HGNC gene names.
    use_synonyms : bool, optional
        If True, try to match gene names in the dataframe to HGNC gene names using synonyms when
        possible.
    map_to_human_orth : bool, optional
        Map from non-human to human genes using 1-to-1 orthology relationships.
    map_to_human_high_conf_only : bool, optional
        When converting from non-human to human genes using the 1-to-1  orthology
        relationships, use only the high-confidence subset.
    verbose : bool, optional
        If True, print logging information to stderr.
    map_to_human_orth_more : bool, optional
        If True, one2many and many2many orthology relationships where multiple human genes correspond
        to a mouse gene, will result in duplicating the data of said mouse gene into multiple
        (identical) columns in the output.
    map_to_human_orth_all : bool, optional
        If True, result in ignoring confidence (high-confidence / low-confidence) information
        when expanding data from a single mouse gene to multiple human genes, otherwise when both
        high- and low-confidence mappings exist for a given mouse gene, only the high-confidence subset will be used.
    """
    genes = read(input_file, verbose)
    genes = process(genes, use_ensembl, use_synonyms, map_to_human_orth,
                    map_to_human_high_conf_only, verbose, map_to_human_orth_more=map_to_human_orth_more,
                    map_to_human_orth_all=map_to_human_orth_all)
    write(genes, output_file, verbose)
