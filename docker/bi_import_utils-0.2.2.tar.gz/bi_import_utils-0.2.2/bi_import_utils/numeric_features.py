import json
import sys

import pandas as pd

from bi_import_utils import commons

'''
Format a tab-separated data matrix with arbitrary numeric features as BI data table.

Copyright 2017 Data4Cure, Inc. All rights reserved.
'''


def read(input_tsv, transpose=False, verbose=False):
    """Read tab-separated file with numeric features data.
    
    Parameters
    ----------
    input_tsv : str
        Path to input file containing numeric features. Rows correspond to samples and columns
        correspond to features.
    transpose : bool, optional
        Transpose matrix when reading; use if rows represent features and columns represent samples.
    verbose : bool, optional
        If True, print logging information to stderr.
    
    Returns
    -------
    df : pandas.DataFrame
        Pandas dataframe containing numeric features. Rows correspond to samples and columns
        correspond to features.
    """
    if verbose:
        sys.stderr.write('\nReading data file {}\n'.format(input_tsv))
    df = pd.read_csv(input_tsv, sep='\t', header=0, index_col=0,
                     na_values='NA', low_memory=False)
    if transpose:
        # reverse pandas mechanism to ensure column uniqueness and transpose matrix
        df = commons.remove_col_duplicates_pandas(df).T

    if verbose:
        sys.stderr.write('\nData dimensions: {}\n'.format(df.shape))

    return df


def process(df, duplicate_features='first', verbose=False):
    """Process dataframe with numeric features data by dropping duplicate features.

    Parameters
    ----------
    df : pandas.DataFrame
        Pandas dataframe containing numeric features data. Rows correspond to samples and columns
        correspond to features.
    duplicate_features : str, optional
        Duplicate features selection. Default: first occurrence is kept.
        Other options are min/mean/median/max value from duplicate features.
    verbose : bool, optional
        If True, print logging information to stderr.

    Returns
    -------
    df : pandas.DataFrame
        Processed pandas dataframe containing gene-level omics data. Rows correspond to samples and
        columns correspond to genes.
    dropped_elements: pandas.DataFrame
        Pandas dataframe containing dropped genes and a reason for it. Rows correspond to genes and
        columns to various information.

    """
    # Create deepcopy of input matrix to avoid changing input object
    df = df.copy(deep=True)

    # reverse pandas mechanism to ensure uniqueness of column names
    df = commons.remove_col_duplicates_pandas(df)

    # ensure uniqueness of samples
    if not df.index.is_unique:
        raise Exception("\nError: duplicate sample IDs. Please make sure your input has unique sample identifiers.")

    # create new dataframe for storing duplicates, not translated ids, etc.
    dropped_elements = pd.DataFrame(index=df.columns).assign(
        HGNC_symbol=df.columns, description=None)

    # remove duplicates: if exist in original data
    df, dropped_elements = commons.drop_duplicate_columns(
        df, dropped_elements, duplicate_genes=duplicate_features, verbose=True)

    if verbose:
        sys.stderr.write('\nData dimensions: {}\n'.format(df.shape))

    # select only dropped elements
    dropped_elements = dropped_elements.loc[~dropped_elements.description.isnull(), :]

    # drop column with HGNC symbols since it's a duplicate of an index
    dropped_elements.drop('HGNC_symbol', axis=1, inplace=True)

    # notify user about number of dropped elements due to duplication reasons
    no_of_duplicated_elements = dropped_elements[dropped_elements.description == 'Duplicated'].shape[0]
    if duplicate_features == 'first' and no_of_duplicated_elements > 0:
        sys.stderr.write(('\nNumber of dropped features due to duplication: {}. Consider using '
                          '`duplicate_features` option to aggregate them.\n'.format(no_of_duplicated_elements)))

    return df, dropped_elements


def write(df, dropped_elements, samples_domain, features_domain, output_tbl,
          no_save_dropped=False, verbose=False):
    """Write processed dataframe with gene-level omics data to BI tbl file.
    
    Parameters
    ----------
    df : pandas.DataFrame
        Processed pandas dataframe containing gene-level omics data. Rows correspond to samples and
        columns correspond to genes.
    dropped_elements: pandas.DataFrame
        Pandas dataframe containing dropped genes and a reason for it. Rows correspond to genes and
        columns to various information.
    samples_domain : str
        Domain of samples; e.g. your organization name.
    features_domain : str
        Domain of features; e.g. your organization name.
    output_tbl: str
        Path to write tbl file to.
    no_save_dropped : bool, optional
        Skip saving dropped elements to additional file. (default = False)
    verbose : bool, optional
        If True, print logging information to stderr.
    """

    column_json_func = commons.column_json_generic_numeric
    row_json_func = commons.sample_row_json


    # reformat row/column headers
    df.index = [json.dumps(row_json_func(x, samples_domain), sort_keys=True) for x in df.index]
    df.columns = [json.dumps(column_json_func(x, features_domain), sort_keys=True) for x in df.columns]

    # write table file
    commons.write_df_as_tbl(df, output_tbl)
    
    if verbose:
        sys.stderr.write('\nWrote data table (.tbl) file to: {}\n'.format(output_tbl))

    # Save dropped and aggregated elements to files
    if not no_save_dropped and not dropped_elements.empty:
        commons.write_dropped_aggregated_as_tsv(dropped_elements, output_tbl)


def format_file(
    input_tsv,
    samples_domain,
    features_domain,
    output_tbl,
    transpose=False,
    duplicate_features='first',
    no_save_dropped=False,
    verbose=False,
):
    """Format data file containing numeric features data as a BI tbl file.

    Parameters
    ----------
    input_tsv : str
        Path to input tab-separated file with numeric features data. Rows correspond to samples and columns
        correspond to features.
    samples_domain : str
        Domain of samples; e.g. your organization name.
    features_domain : str
        Domain of features; e.g. your organization name.
    output_tbl: str
        Path to write tbl file to.
    transpose : bool, optional
        Transpose matrix when reading; use if rows represent features and columns represent samples.
    duplicate_features : str, optional
        Duplicate features selection. Default: first occurrence is kept.
        Other options are min/mean/median/max value from duplicate features.
    no_save_dropped : bool, optional
        Skip saving dropped elements to additional file. (default = False)
    verbose : bool, optional
        If True, print logging information to stderr.
    """
    df = read(input_tsv, transpose=transpose, verbose=verbose)
    df, dropped_elements = process(df, duplicate_features=duplicate_features, verbose=verbose)
    write(df, dropped_elements, samples_domain, features_domain,
          output_tbl, no_save_dropped, verbose)
