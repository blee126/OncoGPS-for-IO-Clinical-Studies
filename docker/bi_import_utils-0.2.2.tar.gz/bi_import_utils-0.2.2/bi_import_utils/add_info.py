import os
import sys
import json
import shutil


def add_table_info(
    input_tbl,
    table_name=None,
    table_desc=None,
    data_url=None,
    pub_url=None,
    verbose=False,
):
    """Add metadata to a tbl file.

    Parameters
    ----------
    input_tbl : str
        Path to BI-formatted table file.
    table_name : str, optional
        Name for the data table.
    table_desc : str, optional
        Description for the data table.
    data_url : str, optional
        URL of the data or data source.
    pub_url : str, optional
        URL of associated publication.
    verbose : bool, optional
        If True, print logging information to stderr.
    """
    if not (table_name or table_desc or pub_url or data_url):
        if verbose:
            sys.stderr.write('\nNo table info provided. Exiting.\n\n')
        return(None)

    # read table & meta
    metalines, tbl = [], []
    with open(input_tbl, 'r') as f:
        for line in f:
            if line.startswith('#'):
                metalines.append(line)
            else:
                tbl.append(line)

    if len(metalines) > 1:
        sys.exit('Input data table (.tbl) file has > 1 metadata lines. Exiting.')

    meta = {}
    if len(metalines) == 1:
        meta = json.loads(metalines[0][1:])

    overwrite = []
    if table_name:
        if 'data_table_name' in meta:
            overwrite.append('data_table_name')
        meta['data_table_name'] = table_name

    if table_desc:
        if 'data_table_desc' in meta:
            overwrite.append('data_table_desc')
        meta['data_table_desc'] = table_desc

    if data_url:
        if 'data_url' in meta:
            overwrite.append('data_url')
        meta['data_url'] = data_url

    if pub_url:
        if 'pub_url' in meta:
            overwrite.append('pub_url')
        meta['pub_url'] = pub_url

    if verbose and len(overwrite) > 0:
        sys.stderr.write('\nOverwrite existing: {}\n'.format(', '.join(overwrite)))

    # make backup copy of input
    input_bak = input_tbl + '.backup'
    shutil.copyfile(input_tbl, input_bak)

    # overwrite input with new version
    try:
        with open(input_tbl, 'w') as f:
            f.write('#' + json.dumps(meta, sort_keys=True) + '\n')
            f.writelines(tbl)
        # succesfully wrote: remove backup
        os.remove(input_bak)
    except:
        # failed in write: copy backup to original, remove backup
        shutil.copyfile(input_bak, input_tbl)
        os.remove(input_bak)

    if verbose:
        sys.stderr.write('\nWrote augmented data table (.tbl) file to: {}\n\n'.format(input_tbl))
