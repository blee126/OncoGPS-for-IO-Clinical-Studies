#!/usr/bin/env
import os
import sys
import json
import argparse

from bi_import_utils import add_info
from bi_import_utils import fusions
from bi_import_utils import genes
from bi_import_utils import genestats
from bi_import_utils import omics
from bi_import_utils import numeric_features
from bi_import_utils import modified_protein_abundance
from bi_import_utils import sparse
from bi_import_utils import metad
from bi_import_utils import rppa
from bi_import_utils import cell_type_signatures
from bi_import_utils import cell_type_fractions
from bi_import_utils import qc_plots
from bi_import_utils import h5ad
from bi_import_utils import yaml_tool

'''
Main Biomedical Intelligence data table import application.

Copyright 2018 Data4Cure, Inc. All rights reserved.
'''


def main():
    no_save_dropped_help = 'Skip saving dropped elements to additional file'
    use_ensembl_help = 'Convert ENSEMBL ids to HGNC gene names'
    use_synonyms_help = ('Match gene names on synonyms & translate back to the '
                         'HGNC name, where possible')
    map_to_human_help = ('Map non-human genes to human gene names using 1-to-1 '
                         'orthology relationships. Specify a species, one of: mouse, rat.')
    map_to_human_hconf_help = ('Of the 1-to-1 non-human/human orthology relationships, '
                               'use only the high-confidence subset')
    duplicates_help = ('Gene symbols deduplication, use one of: first, min, max, '
                       'median, mean; default: first')
    duplicates_ft_help = ('Features deduplication, use one of first, min, max, '
                          'median, mean; default: first')
    map_to_human_orth_more_help = ('If set, orthology relationships other than 1-to-1 (one->many, many->one, '
                                   'many->many) will be used: relationships where a single non-human gene is mapped '
                                   'to multiple human genes will result in duplicating the data associated with '
                                   'the non-human gene, relationships where multiple non-human genes are mapped to a '
                                   'single human gene will result in merging the data associated with the non-human '
                                   'genes (by default using mean, see --map-to-human-orth-more-duplicate-genes '
                                   'parameter). Note that by default, if a non-human gene has both high-and '
                                   'low-confidence human orthologues, only the high-confidence subset is used.')
    map_to_human_orth_all_help = ('The same as --map-to-human-orth-more, but additionally using low-confidence '
                                  'orthology relationships when both high- and low-confidence relationships exist.')
    map_to_human_expand_with_random_noise_help = ('When duplicating data from a single non-human gene across multiple '
                                                  'human gene counterparts (see related settings '
                                                  '--map-to-human-orth-more and --map-to-human-orth-all), add a small '
                                                  'amount of random noise to avoid identically-duplicated data in the '
                                                  'result.')
    map_to_human_orth_more_duplicate_genes_help = ('Deduplication of duplicate gene symbols resulting from orthology '
                                                   'mapping, use one of min, max, median, mean; default: mean or max '
                                                   '(mean for continuous data types: rna_expression, '
                                                   'protein_expression and max for binary data types: '
                                                   'somatic_mutation, copy_gain, copy_loss, methylation, '
                                                   'hypermethylation')

    # parent parser
    p = argparse.ArgumentParser(description=('Format data files as Biomedical '
                                             'Intelligence (BI) table files.'))
    # sub-command parsers and options
    subparsers = p.add_subparsers(dest='application')

    ##### gene list #####
    genes_parser = subparsers.add_parser(
        'genes',
        description=('Format a line/space/comma separated gene-list file as a '
                     'Biomedical Intelligence (BI) Gene List.'),
    )
    genes_parser.add_argument('input_file', type=str,
                              help='Input gene-list file (line/space/comma separated)')
    genes_parser.add_argument('output_tbl', type=str, help='Output BI-formatted table file')
    genes_parser.add_argument('--use-ensembl', action='store_true', default=False,
                              help=use_ensembl_help)
    genes_parser.add_argument('--use-synonyms', action='store_true', default=False,
                              help=use_synonyms_help)
    genes_parser.add_argument('--no-save-dropped', action='store_true', default=False,
                              help=no_save_dropped_help)

    ##### gene stats table #####
    genestats_parser = subparsers.add_parser(
        'genestats',
        description=('Format a tab-separated data file with gene-level expression '
                     'statistics as a Biomedical Intelligence (BI) data table.'),
    )
    genestats_parser.add_argument('input_tsv', type=str, help='Input data file (tab-separated)')
    genestats_parser.add_argument('output_tbl', type=str, help='Output BI-formatted table file')
    genestats_parser.add_argument('--use-ensembl', action='store_true', default=False,
                                  help=use_ensembl_help)
    genestats_parser.add_argument('--use-synonyms', action='store_true', default=False,
                                  help=use_synonyms_help)
    genestats_parser.add_argument('--modified-protein', action='store_true', default=False,
                                  help='Rows correspond to gene-based modified proteins (e.g. `KRAS P:T33,T64`)')
    genestats_parser.add_argument('--map-to-human-orth', type=str, default=None,
                                  help=map_to_human_help)
    genestats_parser.add_argument('--map-to-human-high-conf-only', action='store_true', default=False,
                                  help=map_to_human_hconf_help)
    genestats_parser.add_argument('--no-save-dropped', action='store_true', default=False,
                                  help=no_save_dropped_help)
    genestats_parser.add_argument('--duplicate-genes', default='best', type=str,
                                  help='Deduplication of duplicate genes/features, use one of best, first; '
                                       'default: best. When "best" is used, the most significant (lowest '
                                       'p-value) duplicated gene/feature will be selected (see '
                                       '--duplicate-genes-p-value-column). When "first" is used, the first '
                                       'appearance of a duplicated gene/feature will be selected.')
    genestats_parser.add_argument('--duplicate-genes-p-value-column', metavar='P-VALUE', default=None, type=str,
                                  help='The label of the p-value column. Required when --duplicate-genes '
                                       'is set to "best".')
    genestats_parser.add_argument('--map-to-human-orth-more', action='store_true', default=False,
                                  help=map_to_human_orth_more_help)
    genestats_parser.add_argument('--map-to-human-orth-all', action='store_true', default=False,
                                  help=map_to_human_orth_all_help)

    ##### omics data table #####
    omics_parser = subparsers.add_parser(
        'omics',
        description=('Format a tab-separated data file as a '
                     'Biomedical Intelligence (BI) data table. '
                     'Table rows should specify samples and table columns should '
                     'specify genes.'),
    )
    omics_parser.add_argument('input_tsv', type=str, help='Input data file (tab-separated)')
    omics_parser.add_argument(
        'omic_type',
        type=str,
        help=('Type of gene-level omics data, one of: somatic_mutation, copy_number, copy_gain, '
              'copy_loss, rna_expression, protein_expression, methylation, hypermethylation.'),
    )
    omics_parser.add_argument('samples_domain', type=str,
                              help='Domain of samples; e.g. your organization name')
    omics_parser.add_argument('output_tbl', type=str, help='Output BI-formatted table file')
    omics_parser.add_argument('--use-ensembl', action='store_true', default=False,
                              help=use_ensembl_help)
    omics_parser.add_argument('--use-synonyms', action='store_true', default=False,
                              help=use_synonyms_help)
    omics_parser.add_argument('--no-hgnc-match', action='store_true', default=False,
                              help='Skip matching gene names to HGNC names. Use with care')
    omics_parser.add_argument('--map-to-human-orth', type=str, default=None,
                              help=map_to_human_help)
    omics_parser.add_argument('--map-to-human-high-conf-only', action='store_true', default=False,
                              help=map_to_human_hconf_help)
    omics_parser.add_argument('--no-save-dropped', action='store_true', default=False,
                              help=no_save_dropped_help)
    omics_parser.add_argument('--duplicate-genes', default='first', type=str, help=duplicates_help)
    omics_parser.add_argument('--map-to-human-orth-more', action='store_true', default=False, help=map_to_human_orth_more_help)
    omics_parser.add_argument('--map-to-human-orth-all', action='store_true', default=False,
                              help=map_to_human_orth_all_help)
    omics_parser.add_argument('--map-to-human-orth-more-duplicate-genes', type=str, default=None,
                              help=map_to_human_orth_more_duplicate_genes_help)
    omics_parser.add_argument('--map-to-human-expand-with-random-noise', action='store_true', default=False,
                              help=map_to_human_expand_with_random_noise_help)

    # only_high_q_orthology
    omics_parser.add_argument('--transpose', action='store_true', default=False,
                              help=('Transpose prior to formatting; use if rows '
                                    'represent genes and columns represent samples'))

    ##### modified protein abundance data table #####
    modified_protein_abundance_parser = subparsers.add_parser(
        'modified_protein_abundance',
        description=('Format a tab-separated data file as a '
                     'Biomedical Intelligence (BI) data table. '
                     'Table rows should specify samples and table columns should '
                     'specify gene-based modified protein abundance measurements (e.g. `KRAS P:T33,T64`).'),
    )
    modified_protein_abundance_parser.add_argument('input_tsv', type=str, help='Input data file (tab-separated)')
    modified_protein_abundance_parser.add_argument('samples_domain', type=str,
                                                   help='Domain of samples; e.g. your organization name')
    modified_protein_abundance_parser.add_argument('output_tbl', type=str, help='Output BI-formatted table file')
    modified_protein_abundance_parser.add_argument('--use-ensembl', action='store_true', default=False,
                                                   help=use_ensembl_help)
    modified_protein_abundance_parser.add_argument('--use-synonyms', action='store_true', default=False,
                                                   help=use_synonyms_help)
    modified_protein_abundance_parser.add_argument('--no-hgnc-match', action='store_true', default=False,
                                                   help='Skip matching gene names to HGNC names. Use with care')
    modified_protein_abundance_parser.add_argument('--map-to-human-orth', type=str, default=None,
                                                   help=map_to_human_help)
    modified_protein_abundance_parser.add_argument('--map-to-human-high-conf-only', action='store_true', default=False,
                                                   help=map_to_human_hconf_help)
    modified_protein_abundance_parser.add_argument('--transpose', action='store_true', default=False,
                                                   help=('Transpose prior to formatting; use if rows '
                                                         'represent features and columns represent samples'))
    modified_protein_abundance_parser.add_argument('--no-save-dropped', action='store_true', default=False,
                                                   help=no_save_dropped_help)
    modified_protein_abundance_parser.add_argument('--duplicate-features', default='first',
                                                   type=str, help=duplicates_ft_help)
    modified_protein_abundance_parser.add_argument('--map-to-human-orth-more', action='store_true', default=False,
                                                   help=map_to_human_orth_more_help)
    modified_protein_abundance_parser.add_argument('--map-to-human-orth-all', action='store_true', default=False,
                                                   help=map_to_human_orth_all_help)
    modified_protein_abundance_parser.add_argument('--map-to-human-orth-more-duplicate-genes', type=str, default=None,
                                                   help=map_to_human_orth_more_duplicate_genes_help)
    modified_protein_abundance_parser.add_argument('--map-to-human-expand-with-random-noise', action='store_true',
                                                   default=False, help=map_to_human_expand_with_random_noise_help)

    ##### numeric features data table #####
    numeric_features_parser = subparsers.add_parser(
        'numeric_features',
        description=('Format a tab-separated data file as a '
                     'Biomedical Intelligence (BI) data table. '
                     'Table rows should specify samples and table columns should '
                     'specify features.'),
    )
    numeric_features_parser.add_argument('input_tsv', type=str, help='Input data file (tab-separated)')
    numeric_features_parser.add_argument('samples_domain', type=str,
                                         help='Domain of samples; e.g. your organization name')
    numeric_features_parser.add_argument('features_domain', type=str,
                                         help='Domain of features; e.g. your organization name')
    numeric_features_parser.add_argument('output_tbl', type=str, help='Output BI-formatted table file')
    numeric_features_parser.add_argument('--transpose', action='store_true', default=False,
                                         help=('Transpose prior to formatting; use if rows '
                                               'represent features and columns represent samples'))
    numeric_features_parser.add_argument('--no-save-dropped', action='store_true', default=False,
                                         help=no_save_dropped_help)
    numeric_features_parser.add_argument('--duplicate-features', default='first', type=str, help=duplicates_ft_help)

    ##### sparse data table #####
    sparse_parser = subparsers.add_parser(
        'sparse',
        description=(
            'Format a matrix market file (https://math.nist.gov/MatrixMarket/'
            'formats.html) as a Biomedical Intelligence (BI) sparse data table. '
            'Rows should specify genes and columns should specify cells.'),
    )
    sparse_parser.add_argument(
        'input_mtx',
        type=str,
        help='Input matrix market file',
    )
    sparse_parser.add_argument(
        'genes',
        type=str,
        help='Input file with gene names',
    )
    sparse_parser.add_argument(
        'barcodes',
        type=str,
        help='Input file with barcodes/cell IDs',
    )
    sparse_parser.add_argument(
        'samples_domain',
        type=str,
        help='Domain of samples; e.g. your organization name',
    )
    sparse_parser.add_argument(
        'output_mtx',
        type=str,
        help='Output BI-formatted sparse matrix mtx file',
    )
    sparse_parser.add_argument(
        '--use-ensembl',
        action='store_true',
        default=False,
        help=use_ensembl_help
    )
    sparse_parser.add_argument(
        '--use-synonyms',
        action='store_true',
        default=False,
        help=use_synonyms_help,
    )
    sparse_parser.add_argument(
        '--no-hgnc-match',
        action='store_true',
        default=False,
        help='Skip matching gene names to HGNC names. Use with care.',
    )
    sparse_parser.add_argument(
        '--map-to-human-orth',
        type=str,
        default=None,
        help=map_to_human_help,
    )
    sparse_parser.add_argument(
        '--map-to-human-high-conf-only',
        action='store_true',
        default=False,
        help=map_to_human_hconf_help,
    )
    sparse_parser.add_argument(
        '--transpose',
        action='store_true',
        default=False,
        help=('Transpose prior to formatting; use if rows represent barcodes/cells and columns '
              'represent genes'),
    )
    sparse_parser.add_argument(
        '--counts',
        action='store_true',
        default=False,
        help=('Input mtx file contains count data. Output mtx file will contain integers.'),
    )
    sparse_parser.add_argument(
        '--precision',
        type=int,
        default=3,
        choices=range(0, 9),
        help=('Number of digits to include for non-integer data. Not applicable when --counts is '
              'used.'),
    )
    sparse_parser.add_argument(
        '--no-save-dropped',
        action='store_true',
        default=False,
        help=no_save_dropped_help
    )
    sparse_parser.add_argument(
        '--duplicate-genes',
        type=str,
        default='first',
        help=duplicates_help
    )
    sparse_parser.add_argument(
        '--map-to-human-orth-more',
        action='store_true',
        default=False,
        help=map_to_human_orth_more_help)
    sparse_parser.add_argument(
        '--map-to-human-orth-all',
        action='store_true',
        default=False,
        help=map_to_human_orth_all_help
    )
    sparse_parser.add_argument(
        '--map-to-human-orth-more-duplicate-genes',
        type=str,
        default=None,
        help=map_to_human_orth_more_duplicate_genes_help
    )
    sparse_parser.add_argument(
        '--map-to-human-expand-with-random-noise',
        action='store_true',
        default=False,
        help=map_to_human_expand_with_random_noise_help
    )

    ##### meta data table #####
    meta_parser = subparsers.add_parser(
        'metad',
        description=('Format a tab-separated metadata file as a '
                     'Biomedical Intelligence (BI) data table. '
                     'Table rows should specify samples and table columns should '
                     'specify metadata entities.'),
    )
    meta_parser.add_argument('input_tsv', type=str, help='Input metadata file (tab-separated)')
    meta_parser.add_argument('config', type=str, help='Columns configuration (*.yaml) file')
    meta_parser.add_argument('samples_domain', type=str,
                             help='Domain of samples; e.g. your organization name')
    meta_parser.add_argument('output_tbl', type=str, help='Output BI-formatted table file')

    ##### Add metadata to table #####
    addinfo_parser = subparsers.add_parser('addinfo',
                                           description='Add name, description, and other info to a tbl file.')
    addinfo_parser.add_argument('input_tbl', type=str, help='Input BI-formatted table file')
    addinfo_parser.add_argument('--table-name', type=str, default=None, help='Name for the data table.')
    addinfo_parser.add_argument('--table-desc', type=str, default=None, help='Description for the data table.')
    addinfo_parser.add_argument('--data-url', type=str, default=None, help='URL of the data or data source.')
    addinfo_parser.add_argument('--pub-url', type=str, default=None, help='URL of associated publication.')

    ##### Fusions data table #####
    fusion_parser = subparsers.add_parser(
        'fusions',
        description=('Format a tab-separated file with gene fusion data '
                     'as a Biomedical Intelligence (BI) data table'),
    )
    fusion_parser.add_argument(
        'input_tsv',
        type=str,
        help='Input data file (tab-separated)',
    )
    fusion_parser.add_argument(
        'samples_domain',
        type=str,
        help='Domain of samples; e.g. your organization name',
    )
    fusion_parser.add_argument(
        'output_tbl',
        type=str,
        help='Output BI-formatted table file',
    )
    fusion_parser.add_argument(
        '--transpose',
        action='store_true',
        default=False,
        help=('Transpose matrix when reading; use if rows represent fusions and columns represent '
              'samples.'),
    )
    fusion_parser.add_argument('--use-ensembl', action='store_true', default=False,
                               help=use_ensembl_help)
    fusion_parser.add_argument('--use-synonyms', action='store_true', default=False,
                               help=use_synonyms_help)
    fusion_parser.add_argument('--map-to-human-orth', type=str, default=None,
                               help=map_to_human_help)
    fusion_parser.add_argument('--map-to-human-high-conf-only', action='store_true', default=False,
                               help=map_to_human_hconf_help)
    fusion_parser.add_argument('--no-save-dropped', action='store_true', default=False,
                               help=no_save_dropped_help)
    fusion_parser.add_argument('--duplicate-features', default='first', type=str,
                               help='Features deduplication, use one of first, min, max; default: first')
    fusion_parser.add_argument('--dont-reorder-items', action='store_true', default=False,
                               help='Skip reordering / sorting fusion elements such that separate items G1__G2 '
                                    'and G2__G1 will be kept rather than merged into a single element G1__G2.')
    '''fusion_parser.add_argument('--map-to-human-orth-more', action='store_true', default=False,
                               help=map_to_human_orth_more_help)
    fusion_parser.add_argument('--map-to-human-orth-all', action='store_true', default=False,
                               help=map_to_human_orth_all_help)
    fusion_parser.add_argument('--map-to-human-orth-more-duplicate-genes', type=str, default=None,
                               help=map_to_human_orth_more_duplicate_genes_help)'''

    ##### RPPA data table #####
    rppa_parser = subparsers.add_parser(
        'rppa',
        description=('Format a tab-separated file with reverse phase protein array (RPPA) data '
                     'as a Biomedical Intelligence (BI) data table'),
    )
    rppa_parser.add_argument(
        'input_tsv',
        type=str,
        help='Input data file (tab-separated)',
    )
    rppa_parser.add_argument(
        'samples_domain',
        type=str,
        help='Domain of samples; e.g. your organization name',
    )
    rppa_parser.add_argument(
        'output_tbl',
        type=str,
        help='Output BI-formatted table file',
    )
    rppa_parser.add_argument(
        '--transpose',
        action='store_true',
        default=False,
        help=('Transpose matrix when reading; use if rows represent proteins and columns represent '
              'samples.'),
    )
    rppa_parser.add_argument('--use-synonyms', action='store_true', default=False,
                             help=use_synonyms_help)

    ##### Cell-type signatures #####
    cell_type_signatures_parser = subparsers.add_parser(
        'cell_type_signatures',
        description=('Format a tab-separated data file with cell-type specific '
                     'signatures as a Biomedical Intelligence (BI) data table'),
    )
    cell_type_signatures_parser.add_argument('input_tsv', type=str, help='Input data file (tab-separated)')
    cell_type_signatures_parser.add_argument('output_tbl', type=str, help='Output BI-formatted table file')
    cell_type_signatures_parser.add_argument('--use-ensembl', action='store_true', default=False,
                                             help=use_ensembl_help)
    cell_type_signatures_parser.add_argument('--use-synonyms', action='store_true', default=False,
                                             help=use_synonyms_help)
    cell_type_signatures_parser.add_argument('--transpose', action='store_true', default=False, help=(
        'Transpose matrix when reading; use if rows represent genes and columns represent samples.'),
    )
    cell_type_signatures_parser.add_argument('--no-save-dropped', action='store_true', default=False,
                                             help=no_save_dropped_help)
    cell_type_signatures_parser.add_argument('--duplicate-genes', default='first', type=str, help=duplicates_help)

    ##### Cell-type fractions #####
    cell_type_fractions_parser = subparsers.add_parser(
        'cell_type_fractions',
        description=('Format a tab-separated data file with cell-type fractions '
                     'as a Biomedical Intelligence (BI) data table'),
    )
    cell_type_fractions_parser.add_argument('input_tsv', type=str, help='Input data file (tab-separated)')
    cell_type_fractions_parser.add_argument('output_tbl', type=str, help='Output BI-formatted table file')
    cell_type_fractions_parser.add_argument('samples_domain', type=str,
                                             help='Domain of samples; e.g. your organization name')
    cell_type_fractions_parser.add_argument('--transpose', action='store_true', default=False, help=(
        'Transpose matrix when reading; use if rows represent cell types and columns represent samples.'))

    ##### QC plots #####
    qc_plots_parser = subparsers.add_parser(
        'qc_plots',
        description='Generate plot(s) based on the given table.',
    )
    qc_plots_parser.add_argument('mode', type=str,
                                 help='Type of input data: "numeric" or "binary". '
                                      'If "numeric" two plots are created: boxplot (one box per sample) '
                                      'and PCA plot (PC1 vs PC2). If "binary" a single bar plot '
                                      'with sums of rows (samples) is created.')
    qc_plots_parser.add_argument('input_table', type=str,
                                 help='Input file in tsv or a Biomedical Intelligence data table (tbl) format '
                                      '(rows corresponding to samples).')
    qc_plots_parser.add_argument('--title', type=str, default=None,
                                 help='Title of the plots.')
    qc_plots_parser.add_argument('--sample-labels-table', type=str, default=None,
                                 help='Table with samples metadata (rows corresponding to samples) in tsv or a '
                                      'Biomedical Intelligence data table (tbl) format.')
    qc_plots_parser.add_argument('--sample-labels-column', type=str, default=None,
                                 help='Column from sample labels table that should be used to color the plot(s)')
    qc_plots_parser.add_argument('--boxplot-sort', type=str, default='q3',
                                 help='Sort type of boxes on the boxplot, choose one of: q3 (third quartile), '
                                      'q1 (first quartile), median, mean. Default: q3')
    qc_plots_parser.add_argument('--outfile', type=str, default=None,
                                 help='Basename of the output plot(s), without extension. '
                                      'If not given it is inferred from the name of the input table.')

    ##### h5ad #####
    h5ad_parser = subparsers.add_parser(
        'h5ad',
        description='Format h5ad file to make it correctly interpreted by D4C single cell browser.',
    )
    h5ad_parser.add_argument('input_file', type=str, help='Input data file (in h5ad format)')
    h5ad_parser.add_argument('output_file', type=str, help='Output formatted h5ad file')
    h5ad_parser.add_argument('matrix_type', type=str,
                             help=('Type of gene expression matrix, one of: log2-transformed (default type '
                                   'returned by single cell app), logn-transformed, scaled, counts, other'))
    h5ad_parser.add_argument('--metadata', type=str, default=None,
                             help='Csv file with additional cells metadata.')
    h5ad_parser.add_argument('--unique-thresh', type=int, default=None,
                             help='Threshold of number of unique elements in the metadata column to treat it as '
                                  'a categorical rather than numeric.')
    h5ad_parser.add_argument('--use-ensembl', action='store_true', default=False,
                             help=use_ensembl_help)
    h5ad_parser.add_argument('--use-synonyms', action='store_true', default=False,
                             help=use_synonyms_help)
    h5ad_parser.add_argument('--no-hgnc-match', action='store_true', default=False,
                             help='Skip matching gene names to HGNC names. Use with care')
    h5ad_parser.add_argument('--map-to-human-orth', type=str, default=None,
                             help=map_to_human_help)
    h5ad_parser.add_argument('--map-to-human-high-conf-only', action='store_true', default=False,
                             help=map_to_human_hconf_help)
    h5ad_parser.add_argument('--no-save-dropped', action='store_true', default=False,
                             help=no_save_dropped_help)
    h5ad_parser.add_argument('--duplicate-genes', default='first', type=str, help=duplicates_help)
    h5ad_parser.add_argument('--map-to-human-orth-more', action='store_true', default=False,
                             help=map_to_human_orth_more_help)
    h5ad_parser.add_argument('--map-to-human-orth-all', action='store_true', default=False,
                             help=map_to_human_orth_all_help)
    h5ad_parser.add_argument('--map-to-human-orth-more-duplicate-genes', type=str, default=None,
                             help=map_to_human_orth_more_duplicate_genes_help)
    h5ad_parser.add_argument('--map-to-human-expand-with-random-noise', action='store_true', default=False,
                             help=map_to_human_expand_with_random_noise_help)

    ##### yaml #####
    yaml_parser = subparsers.add_parser(
        'yaml',
        description='Create yaml file based on given metadata tsv file, output files are: \n'
                    '[DATASET_ID].yaml - yaml file\n'
                    '[DATASET_ID]_metadata_changed.tsv - metadata with rewritten values, USE IT FOR FORMATTING\n'
                    '[DATASET_ID]_skipped.tsv - columns skipped during analysis',
        formatter_class=argparse.RawTextHelpFormatter
    )
    yaml_parser.add_argument('input_metadata',
                             metavar='FILE',
                             help='Input metadata file in tsv format.')

    # parse arguments
    args = p.parse_args()
    sys.stderr.write('\nApplication: {}\n'.format(args.application))

    if args.application == 'genes':
        genes.format_file(
            args.input_file,
            args.output_tbl,
            args.use_ensembl,
            args.use_synonyms,
            args.no_save_dropped,
            verbose=True,
        )
    elif args.application == 'genestats':
        genestats.format_file(
            args.input_tsv,
            args.output_tbl,
            args.use_ensembl,
            args.use_synonyms,
            args.modified_protein,
            args.map_to_human_orth,
            args.map_to_human_high_conf_only,
            args.no_save_dropped,
            args.duplicate_genes,
            args.duplicate_genes_p_value_column,
            verbose=True,
            map_to_human_orth_more=args.map_to_human_orth_more,
            map_to_human_orth_all=args.map_to_human_orth_all,
        )
    elif args.application == 'metad':
        metad.format_file(
            args.input_tsv,
            args.config,
            args.samples_domain,
            args.output_tbl,
            verbose=True,
        )
    elif args.application == 'sparse':
        sparse.format_file(
            args.input_mtx,
            args.genes,
            args.barcodes,
            args.samples_domain,
            args.output_mtx,
            args.use_ensembl,
            args.use_synonyms,
            args.no_hgnc_match,
            args.map_to_human_orth,
            args.map_to_human_high_conf_only,
            args.transpose,
            args.counts,
            args.precision,
            args.no_save_dropped,
            args.duplicate_genes,
            verbose=True,
            map_to_human_orth_more=args.map_to_human_orth_more,
            map_to_human_orth_all=args.map_to_human_orth_all,
            map_to_human_expand_with_random_noise=args.map_to_human_expand_with_random_noise,
            map_to_human_orth_more_duplicate_genes=args.map_to_human_orth_more_duplicate_genes
        )
    elif args.application == 'omics':
        omics.format_file(
            args.input_tsv,
            args.samples_domain,
            args.omic_type,
            args.output_tbl,
            args.use_ensembl,
            args.use_synonyms,
            args.no_hgnc_match,
            args.map_to_human_orth,
            args.map_to_human_high_conf_only,
            transpose=args.transpose,
            no_save_dropped=args.no_save_dropped,
            duplicate_genes=args.duplicate_genes,
            verbose=True,
            map_to_human_orth_more=args.map_to_human_orth_more,
            map_to_human_orth_all=args.map_to_human_orth_all,
            map_to_human_expand_with_random_noise=args.map_to_human_expand_with_random_noise,
            map_to_human_orth_more_duplicate_genes=args.map_to_human_orth_more_duplicate_genes
        )

    elif args.application == 'modified_protein_abundance':
        modified_protein_abundance.format_file(
            args.input_tsv,
            args.samples_domain,
            args.output_tbl,
            use_ensembl=args.use_ensembl,
            use_synonyms=args.use_synonyms,
            no_hgnc_match=args.no_hgnc_match,
            map_to_human_orth=args.map_to_human_orth,
            map_to_human_high_conf_only=args.map_to_human_high_conf_only,
            transpose=args.transpose,
            no_save_dropped=args.no_save_dropped,
            duplicate_features=args.duplicate_features,
            verbose=True,
            map_to_human_orth_more=args.map_to_human_orth_more,
            map_to_human_orth_all=args.map_to_human_orth_all,
            map_to_human_expand_with_random_noise=args.map_to_human_expand_with_random_noise,
            map_to_human_orth_more_duplicate_genes=args.map_to_human_orth_more_duplicate_genes
        )

    elif args.application == 'numeric_features':
        numeric_features.format_file(
            args.input_tsv,
            args.samples_domain,
            args.features_domain,
            args.output_tbl,
            transpose=args.transpose,
            duplicate_features=args.duplicate_features,
            verbose=True,
        )
    elif args.application == 'fusions':
        fusions.format_file(
            args.input_tsv,
            args.samples_domain,
            args.output_tbl,
            use_ensembl=args.use_ensembl,
            use_synonyms=args.use_synonyms,
            map_to_human_orth=args.map_to_human_orth,
            map_to_human_high_conf_only=args.map_to_human_high_conf_only,
            transpose=args.transpose,
            no_save_dropped=args.no_save_dropped,
            duplicate_features=args.duplicate_features,
            dont_reorder_items=args.dont_reorder_items,
            verbose=True,
            # map_to_human_orth_more=args.map_to_human_orth_more,
            # map_to_human_orth_all=args.map_to_human_orth_all,
        )
    elif args.application == 'rppa':
        rppa.format_file(
            args.input_tsv,
            args.samples_domain,
            args.output_tbl,
            use_synonyms=args.use_synonyms,
            transpose=args.transpose,
            verbose=True,
        )
    elif args.application == 'addinfo':
        add_info.add_table_info(
            input_tbl=args.input_tbl,
            table_name=args.table_name,
            table_desc=args.table_desc,
            data_url=args.data_url,
            pub_url=args.pub_url,
            verbose=True,
        )
    elif args.application == 'cell_type_signatures':
        cell_type_signatures.format_file(
            args.input_tsv,
            args.output_tbl,
            use_ensembl=args.use_ensembl,
            use_synonyms=args.use_synonyms,
            transpose=args.transpose,
            no_save_dropped=args.no_save_dropped,
            duplicate_genes=args.duplicate_genes,
            verbose=True,
        )
    elif args.application == 'cell_type_fractions':
        cell_type_fractions.format_file(
            args.input_tsv,
            args.output_tbl,
            args.samples_domain,
            transpose=args.transpose,
            verbose=True
        )
    elif args.application == 'qc_plots':
        qc_plots.run(
            args.mode,
            args.input_table,
            title=args.title,
            sample_labels_table=args.sample_labels_table,
            sample_labels_column=args.sample_labels_column,
            boxplot_sort=args.boxplot_sort,
            outfile=args.outfile
        )
    elif args.application == 'h5ad':
        h5ad.format_file(
            args.input_file,
            args.output_file,
            args.matrix_type,
            obs_metadata=args.metadata,
            unique_thresh=args.unique_thresh,
            use_ensembl=args.use_ensembl,
            use_synonyms=args.use_synonyms,
            no_hgnc_match=args.no_hgnc_match,
            duplicate_genes=args.duplicate_genes,
            verbose=True,
            no_save_dropped=args.no_save_dropped,
            map_to_human_orth=args.map_to_human_orth,
            map_to_human_high_conf_only=args.map_to_human_high_conf_only,
            map_to_human_orth_more=args.map_to_human_orth_more,
            map_to_human_orth_all=args.map_to_human_orth_all,
            map_to_human_expand_with_random_noise=args.map_to_human_expand_with_random_noise,
            map_to_human_orth_more_duplicate_genes=args.map_to_human_orth_more_duplicate_genes
        )
    elif args.application == 'yaml':
        yaml_tool.run(args.input_metadata)
    else:
        sys.stderr.write('\nUnknown application: {}\n'.format(args.application))


if __name__ == '__main__':
    main()
