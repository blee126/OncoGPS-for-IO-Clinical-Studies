import json
import sys
import pandas as pd

from bi_import_utils import commons

'''
Format omics matrix (tab separated) as BI data table.

Notes:
  1. Column headers should be unique and correspond to HGNC gene names.
  2. Row headers should be unique and correspond to sample identifiers.

Copyright 2017 Data4Cure, Inc. All rights reserved.
'''


def read(input_tsv, transpose=False, verbose=False):
    """Read tab-separated file with gene-level omics data.
    
    Parameters
    ----------
    input_tsv : str
        Path to input file containing gene-level omics data. Rows correspond to samples and columns
        correspond to genes.
    transpose : bool, optional
        Transpose matrix when reading; use if rows represent genes and columns represent samples.
    verbose : bool, optional
        If True, print logging information to stderr.
    
    Returns
    -------
    df : pandas.DataFrame
        Pandas dataframe containing gene-level omics data. Rows correspond to samples and columns
        correspond to genes.
    """
    if verbose:
        sys.stderr.write('\nReading data file {}\n'.format(input_tsv))
    df = pd.read_csv(input_tsv, sep='\t', header=0, index_col=0,
                     na_values='NA', low_memory=False)

    if transpose:
        # reverse pandas mechanism to ensure column uniqueness and transpose matrix
        df = commons.remove_col_duplicates_pandas(df).T

    if verbose:
        sys.stderr.write('\nData dimensions: {}\n'.format(df.shape))

    return df


def process(
    df,
    omic_type,
    use_ensembl=False,
    use_synonyms=True,
    no_hgnc_match=False,
    map_to_human_orth=None,
    map_to_human_high_conf_only=False,
    duplicate_genes='first',
    verbose=False,
    map_to_human_orth_more=False,
    map_to_human_orth_all=False,
    map_to_human_expand_with_random_noise=False,
    map_to_human_orth_more_duplicate_genes=None
):
    """Process dataframe with omics data to by dropping duplicate genes, converting gene names to
    HGNC, or dropping unknown genes.

    Parameters
    ----------
    df : pandas.DataFrame
        Pandas dataframe containing gene-level omics data. Rows correspond to samples and columns
        correspond to genes.
    omic_type : str
        Type of gene-level omics data, one of: somatic_mutation, copy_number, copy_gain, copy_loss,
        rna_expression, protein_expression, methylation, hypermethylation.
    use_ensembl : bool, optional
        If True, convert ENSEMBL ids (cols in the dataframe) to HGNC gene names.
    use_synonyms : bool, optional
        If True, try to match gene names in the dataframe to HGNC gene names using synonyms when
        possible.
    no_hgnc_match : bool, optional
        Skip matching gene names to HGNC names. It is generally recommended to match to HGNC.
    map_to_human_orth : bool, optional
        Map from non-human to human genes using 1-to-1 orthology relationships.
    map_to_human_high_conf_only : bool, optional
        When converting from non-human to human genes using the 1-to-1  orthology
        relationships, use only the high-confidence subset.
    duplicate_genes : str, optional
        Duplicate genes selection. Default: first occurrence is kept.
        Other options are min/mean/median/max value from duplicate genes.
    verbose : bool, optional
        If True, print logging information to stderr.
    map_to_human_orth_more : bool, optional
        If True, one2many and many2many orthology relationships where multiple human genes correspond
        to a mouse gene, will result in duplicating the data of said mouse gene into multiple
        (identical) columns in the output.
    map_to_human_orth_all : bool, optional
        If True, result in ignoring confidence (high-confidence / low-confidence) information
        when expanding data from a single mouse gene to multiple human genes, otherwise when both
        high- and low-confidence mappings exist for a given mouse gene, only the high-confidence subset will be used.
    map_to_human_expand_with_random_noise : bool, optional
        If True, when duplicating data from a single mouse gene across multiple human gene counterpart
        (see related settings --map-to-human-orth-more and --map-to-human-orth-all), add a small amount of random
        noise to avoid identically duplicated data in the result.
    
    Returns
    -------
    df : pandas.DataFrame
        Processed pandas dataframe containing gene-level omics data. Rows correspond to samples and
        columns correspond to genes.
    dropped_elements: pandas.DataFrame
        Pandas dataframe containing dropped genes and a reason for it. Rows correspond to genes and
        columns to various information.
    """

    binary_data_types = ['somatic_mutation', 'copy_number', 'copy_gain',
                         'copy_loss', 'methylation', 'hypermethylation']
    if omic_type in binary_data_types:
        if duplicate_genes not in ['first', 'min', 'max']:
            sys.stderr.write('\nWARNING: aggregating duplicate genes with {} with binary data. '
                             'Are you sure? Consider using "max" instead.\n'.format(duplicate_genes))
        if map_to_human_expand_with_random_noise:
            raise Exception('\nError: option "--mouse-to-human-extend-with-random-noise" is available only '
                            'for continuous data.')
        if map_to_human_orth_more_duplicate_genes not in [None, 'min', 'max']:
            raise Exception('\nError: for binary data option "--map-to-human-orth-more-duplicate-genes" can be '
                            'only min or max')
    if map_to_human_orth is not None:
        if omic_type == 'copy_number':
            raise Exception('\nError: the copy_number data type is not supported when mapping to human via orthology.')
        if map_to_human_orth_more_duplicate_genes is None:
            if omic_type in binary_data_types:
                map_to_human_orth_more_duplicate_genes = 'min'
            else:
                map_to_human_orth_more_duplicate_genes = 'mean'

    # Create deepcopy of input matrix to avoid changing input object
    df = df.copy(deep=True)

    # reverse pandas mechanism to ensure uniqueness of column names
    df = commons.remove_col_duplicates_pandas(df)

    # ensure uniqueness of samples
    if not df.index.is_unique:
        raise Exception("\nError: duplicate sample IDs. Please make sure your input has unique sample identifiers.")

    # create new dataframe for storing duplicates, not translated ids, etc.
    dropped_elements = pd.DataFrame(index=df.columns).assign(
        HGNC_symbol=df.columns, description=None)

    # remove duplicates: if exist in original data
    df, dropped_elements = commons.drop_duplicate_columns(
        df, dropped_elements, duplicate_genes=duplicate_genes, verbose=True)

    # converting ENSEMBL ids to HGNC gene names and remove duplicates
    if use_ensembl:
        # transpose DataFrame to genes x samples format
        df, dropped_elements = commons.translate_ensembl_ids_to_hgnc(df.T, dropped_elements,
                                                                     duplicate_genes=duplicate_genes,
                                                                     verbose=verbose)
        df = df.T  # return to sample x gene format

        if verbose:
            sys.stderr.write(
                '\nData dimensions after converting ENSEMBL IDs: {}\n'
                .format(df.shape)
            )

    # mouse -> human genes orthology mapping
    if map_to_human_orth is not None:
        df, dropped_elements = commons.match_genes_to_human_orth_cols(
            df, dropped_elements,
            map_to_human_orth,
            high_conf_orthology_only=map_to_human_high_conf_only,
            map_to_human_orth_more=map_to_human_orth_more,
            map_to_human_orth_all=map_to_human_orth_all,
            map_to_human_expand_with_random_noise=map_to_human_expand_with_random_noise
        )

        # remove duplicates: if introduced by orthology mapping
        df, dropped_elements = commons.drop_duplicate_columns(
            df, dropped_elements, duplicate_genes=map_to_human_orth_more_duplicate_genes, verbose=False)

    # prep, upper-case gene names
    if not no_hgnc_match:
        df.columns = [c.upper() for c in df.columns]
        dropped_elements.HGNC_symbol = [c.upper() if c else None for c in dropped_elements.HGNC_symbol]
        # remove duplicates: if introduced by upper casing
        df, dropped_elements = commons.drop_duplicate_columns(
            df, dropped_elements, duplicate_genes=duplicate_genes, verbose=True)

    # HGNC name matching & filtering
    # any duplicates that may arrise in this process are taken care of internally
    df, drop = commons.match_HGNC_names_cols(
        df,
        use_syn=use_ensembl or use_synonyms,
        skip=no_hgnc_match,
    )

    # annotate rows, which were translated to HGNC symbols, but didn't pass HGNC filtering
    mask_hgnc = dropped_elements.description.isnull() & dropped_elements.HGNC_symbol.isin(drop)
    dropped_elements.loc[mask_hgnc, 'description'] = 'HGNC conversion'

    # select rows, which were duplicated or weren't translated to HGNC symbols or didn't pass HGNC filtering (mask_hgnc)
    dropped_elements = dropped_elements.loc[~dropped_elements.description.isnull(), :]
    if not use_ensembl:
        # drop column with HGNC symbols since it's a duplicate of an index
        dropped_elements.drop('HGNC_symbol', axis=1, inplace=True)

    # notify user about number of dropped elements due to duplication reasons
    no_of_duplicated_elements = dropped_elements[dropped_elements.description == 'Duplicated'].shape[0]
    if duplicate_genes == 'first' and no_of_duplicated_elements > 0:
        sys.stderr.write(('\nNumber of dropped genes due to duplication: {}. Consider using '
                          '`duplicate_genes` option to aggregate them.\n'.format(no_of_duplicated_elements)))

    return df, dropped_elements


def write(df, omic_type, samples_domain, dropped_elements, output_tbl, no_save_dropped=False, verbose=False):
    """Write processed dataframe with gene-level omics data to BI tbl file.
    
    Parameters
    ----------
    df : pandas.DataFrame
        Processed pandas dataframe containing gene-level omics data. Rows correspond to samples and
        columns correspond to genes.
    omic_type : str
        Type of gene-level omics data, one of: somatic_mutation, copy_number, copy_gain, copy_loss,
        rna_expression, protein_expression, methylation, hypermethylation.
    samples_domain : str
        Domain of samples; e.g. your organization name.
    dropped_elements: pandas.DataFrame
        Pandas dataframe containing dropped genes and a reason for it. Rows correspond to genes and
        columns to various information.
    output_tbl: str
        Path to write tbl file to.
    no_save_dropped : bool, optional
        Skip saving dropped elements to additional file. (default = False)
    verbose : bool, optional
        If True, print logging information to stderr.
    """
    omic_to_column_format_func = {
        'somatic_mutation': commons.column_json_somatic_mutation,
        'copy_number': commons.column_json_copy_number,
        'copy_gain': commons.column_json_copy_gain,
        'copy_loss': commons.column_json_copy_loss,
        'rna_expression': commons.column_json_rna_abundance,
        'protein_expression': commons.column_json_protein_abundance,
        'methylation': commons.column_json_methylation,
        'hypermethylation': commons.column_json_hypermethylation,
        'gene_interference_CRISPRi': commons.column_json_gene_interference_CRISPRi,
        'gene_interference_RNAi': commons.column_json_gene_interference_RNAi,

    }

    if omic_type not in omic_to_column_format_func:
        raise ValueError('Unexpected omic_type: {}'.format(omic_type))

    column_json_func = omic_to_column_format_func[omic_type]
    row_json_func = commons.sample_row_json

    # reformat row/column headers
    df.index = [json.dumps(row_json_func(x, samples_domain), sort_keys=True) for x in df.index]
    df.columns = [json.dumps(column_json_func(x), sort_keys=True) for x in df.columns]

    # write table file
    commons.write_df_as_tbl(df, output_tbl)
    
    if verbose:
        sys.stderr.write('\nWrote data table (.tbl) file to: {}\n'.format(output_tbl))

    # Save dropped and aggregated elements to files
    if not no_save_dropped and not dropped_elements.empty:
        commons.write_dropped_aggregated_as_tsv(dropped_elements, output_tbl)


def format_file(
    input_tsv,
    samples_domain,
    omic_type,
    output_tbl,
    use_ensembl=False,
    use_synonyms=True,
    no_hgnc_match=False, 
    map_to_human_orth=None,
    map_to_human_high_conf_only=False,
    transpose=False,
    no_save_dropped=False,
    duplicate_genes='first',
    verbose=False,
    map_to_human_orth_more=False,
    map_to_human_orth_all=False,
    map_to_human_expand_with_random_noise=False,
    map_to_human_orth_more_duplicate_genes=None
):
    """Format data file containing omics data as a BI tbl file.
    
    Parameters
    ----------
    input_tsv : str
        Path to input tab-separated file with omics data. Rows correspond to samples and columns
        correspond to genes.
    samples_domain : str
        Domain of samples; e.g. your organization name.
    omic_type : str
        Type of gene-level omics data, one of: somatic_mutation, copy_number, copy_gain, copy_loss,
        rna_expression, protein_expression, methylation, hypermethylation.
    output_tbl: str
        Path to write tbl file to.
    use_ensembl : bool, optional
        If True, convert ENSEMBL ids (cols in the dataframe) to HGNC gene names.
    use_synonyms : bool, optional
        If True, try to match gene names in the dataframe to HGNC gene names using synonyms when
        possible.
    no_hgnc_match : bool, optional
        Skip matching gene names to HGNC names.
    map_to_human_orth : bool, optional
        Map from non-human to human genes using 1-to-1 orthology relationships.
    map_to_human_high_conf_only : bool, optional
        When converting from non-human to human genes using the 1-to-1  orthology
        relationships, use only the high-confidence subset.
    transpose : bool, optional
        Transpose matrix when reading; use if rows represent genes and columns represent samples.
    no_save_dropped : bool, optional
        Skip saving dropped elements to additional file. (default = False)
    duplicate_genes : str, optional
        Duplicate genes selection. Default: first occurrence is kept.
        Other options are min/mean/median/max value from duplicate genes.
    verbose : bool, optional
        If True, print logging information to stderr.
    map_to_human_orth_more : bool, optional
        If True, one2many and many2many orthology relationships where multiple human genes correspond
        to a mouse gene, will result in duplicating the data of said mouse gene into multiple
        (identical) columns in the output.
    map_to_human_orth_all : bool, optional
        If True, result in ignoring confidence (high-confidence / low-confidence) information
        when expanding data from a single mouse gene to multiple human genes, otherwise when both
        high- and low-confidence mappings exist for a given mouse gene, only the high-confidence subset will be used.
    map_to_human_expand_with_random_noise : bool, optional
        If True, when duplicating data from a single mouse gene across multiple human gene counterpart
        (see related settings --map-to-human-orth-more and --map-to-human-orth-all), add a small amount of random
        noise to avoid identically duplicated data in the result.
    """
    df = read(input_tsv, transpose=transpose, verbose=verbose)
    df, dropped_elements = process(
        df,
        omic_type,
        use_ensembl=use_ensembl,
        use_synonyms=use_synonyms,
        no_hgnc_match=no_hgnc_match,
        map_to_human_orth=map_to_human_orth,
        map_to_human_high_conf_only=map_to_human_high_conf_only,
        duplicate_genes=duplicate_genes,
        verbose=verbose,
        map_to_human_orth_more=map_to_human_orth_more,
        map_to_human_orth_all=map_to_human_orth_all,
        map_to_human_expand_with_random_noise=map_to_human_expand_with_random_noise,
        map_to_human_orth_more_duplicate_genes=map_to_human_orth_more_duplicate_genes
    )
    write(df, omic_type, samples_domain, dropped_elements, output_tbl, no_save_dropped, verbose)
