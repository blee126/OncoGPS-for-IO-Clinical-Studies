import copy
import json
import re
import sys
import pandas as pd

from bi_import_utils import ontology
from bi_import_utils import commons

'''
Format a gene list (line/space/comma separated) as BI data table.

Note: gene names should correspond to HGNC gene names.

Copyright 2017 Data4Cure, Inc. All rights reserved.
'''


def read(input_file, verbose=False):
    """Read file with genes. Split on commas and any whitespace including new lines.
    
    Parameters
    ----------
    input_file : str
        Path to input file.
    verbose : bool, optional
        If True, print logging information to stderr.
    
    Returns
    -------
    genes : list
        List of genes from the file (not processed in any way).
    """
    def split_genes_string(gs):
        """Splits on commas and any whitespace (incl. new lines)"""
        return [x for x in re.sub(r'\s', ',', gs).split(',') if x]

    if verbose:
        sys.stderr.write('\nReading input from {}\n'.format(input_file))
    with open(input_file, 'r') as f:
        genes = split_genes_string(f.read())

    return(genes)


def process(genes, use_ensembl=False, use_synonyms=True, verbose=False):
    """Process list of genes by converting gene names to HGNC and dropping unknown genes.
    
    Parameters
    ----------
    genes : list
        List of gene identifiers.
    use_ensembl : bool, optional
        If True, convert ENSEMBL ids to HGNC gene names.
    use_synonyms : bool, optional
        If True, try to match gene names in the dataframe to HGNC gene names using synonyms when
        possible.
    verbose : bool, optional
        If True, print logging information to stderr.
    
    Returns
    -------
    genes : list
        List of genes from the file converted to HGNC or dropped if not in HGNC.
    dropped_elements : pandas.DataFrame
        Pandas dataframe containing dropped genes and a reason for it. Rows correspond to genes and
        columns to various information.
    
    """
    # Create deepcopy of input list to avoid changing input object
    genes = copy.deepcopy(genes)

    # upper case gene names
    genes = [g.upper() for g in genes]

    # create new dataframe for storing duplicates, not translated ids, etc.
    dropped_elements = pd.DataFrame(index=genes).assign(HGNC_symbol=None if use_ensembl else genes, description=None)

    # converting ENSEMBL ids to HGNC gene names and remove duplicates
    if use_ensembl:
        genes, dropped_elements = commons.translate_ensembl_ids_to_hgnc(genes, dropped_elements)
        if verbose:
            sys.stderr.write('\nGene list after converting ensembl ids to HGNC symbol names): '
                             '{}\n'.format(len(genes)))
    else:
        # de-duplicate genes and if dropped, annotate reason for it
        deduplicated_genes = []
        for index, gene in enumerate(genes):
            if gene not in deduplicated_genes:
                deduplicated_genes.append(gene)
                dropped_elements.iat[index, 0] = gene
            else:
                dropped_elements.iat[index, 1] = 'Duplicated'
        genes = deduplicated_genes
        del deduplicated_genes

    if verbose:
        sys.stderr.write('\nGenes: {}\n'.format(len(genes)))

    genes = commons.match_HGNC_names(genes, use_syn=use_ensembl or use_synonyms)
    if verbose:
        sys.stderr.write('\nFinal gene list (HGNC matched, duplicates removed): '
                         '{}\n'.format(len(genes)))
    mask_hgnc = ~dropped_elements.HGNC_symbol.isin(genes) & dropped_elements.description.isnull()
    dropped_elements.loc[mask_hgnc, 'description'] = 'HGNC conversion'

    # select rows, which were duplicated or weren't translated to HGNC symbols or didn't pass HGNC filtering (mask_hgnc)
    dropped_elements = dropped_elements.loc[~dropped_elements.description.isnull(), :]
    if not use_ensembl:
        # drop column with HGNC symbols since it's a duplicate of an index
        dropped_elements.drop('HGNC_symbol', axis=1, inplace=True)

    return genes, dropped_elements


def write(genes, dropped_elements, output_tbl, no_save_dropped=False, verbose=False):
    """Write tbl genes file.
    
    Parameters
    ----------
    genes : list
        Path to input file.
    dropped_elements : pandas.DataFrame
        Pandas dataframe containing dropped genes and a reason for it. Rows correspond to genes and
        columns to various information.
    output_tbl: str
        Path to write tbl file to.
    no_save_dropped : bool, optional
        Skip saving dropped elements to additional file. (default = False)
    verbose : bool, optional
        If True, print logging information to stderr.
    """
    # single 'placeholder' entity measurment
    placeholder_em = {
        'label': 'gene_list',
        'data_type': ontology.NUMERIC,
        'entity': {
            'name': 'gene_list',
            'label': 'gene_list',
            'type': ontology.GENERIC_ENTITY_TYPE,
            'domain': {'name': 'gene_list'},
        },
    }

    with open(output_tbl, 'w') as f:
        f.write('\t' + json.dumps(placeholder_em, sort_keys=True) + '\n')
        for g in genes:
            g_ent = {
                'entity': {
                    'name': g,
                    'label': g,
                    'domain': copy.deepcopy(ontology.HGNC_DOMAIN),
                    'type': ontology.GENE_TYPE,
                },
                'label': g,
            }
            f.write(json.dumps(g_ent, sort_keys=True) + '\t' + '0' + '\n')
    if verbose:
        sys.stderr.write('\nWrote data table (.tbl) file to: {}\n'.format(output_tbl))

    # Save dropped and aggregated elements to files
    if not no_save_dropped and not dropped_elements.empty:
        commons.write_dropped_aggregated_as_tsv(dropped_elements, output_tbl)


def format_file(
    input_file,
    output_tbl,
    use_ensembl=False,
    use_synonyms=True,
    no_save_dropped=False,
    verbose=False,
):
    """Read file containing gene identifiers and write as BI tbl file.
    
    Parameters
    ----------
    input_file : str
        Path to input file with gene identifiers.
    output_tbl: str
        Path to write tbl file to.
    use_ensembl : bool, optional
        If True, convert ENSEMBL ids to HGNC gene names.
    use_synonyms : bool, optional
        If True, try to match gene names in the dataframe to HGNC gene names using synonyms when
        possible.
    no_save_dropped : bool, optional
        Skip saving dropped elements to additional file. (default = False)
    verbose : bool, optional
        If True, print logging information to stderr.
    
    Returns
    -------
    genes : list
        List of genes from the file (not processed in any way).
    """
    genes = read(input_file, verbose)
    genes, dropped_elements = process(genes, use_ensembl, use_synonyms, verbose)
    write(genes, dropped_elements, output_tbl, no_save_dropped, verbose)
