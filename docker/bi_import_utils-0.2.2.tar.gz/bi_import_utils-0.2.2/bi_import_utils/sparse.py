import csv
import io
import json
import pandas as pd
import os
import sys
import numpy as np
import scipy.io
import scipy.sparse
import itertools

from bi_import_utils import commons

'''
Format RNA-seq data in sparse matrix (matrix market format,
https://math.nist.gov/MatrixMarket/formats.html) as BI mtx file.

Notes:
  1. Row headers should be unique and correspond to HGNC gene names.
  2. Column headers should be unique and correspond to sample identifiers.

Copyright 2017 Data4Cure, Inc. All rights reserved.
'''


def read(
        input_mtx,
        genes,
        barcodes,
        counts=False,
        transpose=False,
        verbose=False,
):
    """Read matrix market (mtx) file with counts and files with the genes and cell barcodes
    corresponding to those counts.

    Parameters
    ----------
    input_mtx : str
        Path to input file matrix market (mtx) file with counts. Rows represent genes and columns
        represent barcodes/cells.
    genes : str
        Path to input file with genes that correspond to rows of sparse matrix.
    barcodes : str
        Path to input file with barcodes/identifiers that correspond to columns of sparse
        matrix.
    counts : bool, optional
        Input mtx file contains count data. Output mtx file will contain integers.
    transpose : bool, optional
        Transpose sparse matrix prior to formatting; use if rows represent barcodes/cells and
        columns represent genes.
    verbose : bool, optional
        If True, print logging information to stderr.

    Returns
    -------
    sm : scipy.sparse.coo.coo_matrix
        Sparse matrix with genes as rows and barcodes as columns.
    gene_names : list
        List of genes that correspond to the rows of the sparse matrix.
    cell_names : list
        List of barcodes that correspond to the columns of the sparse matrix.
    """
    if verbose:
        sys.stderr.write('\nReading data file\n<<< {} >>>\nwith genes\n<<< {} >>>\nand '
                         'cells\n<<< {} >>>\n'.format(
            input_mtx,
            genes,
            barcodes,
        ))

    # Read gene names
    with open(genes, 'r') as f:
        gene_names = [x.strip().split()[-1] for x in f.readlines()]

    # Read barcode names
    with open(barcodes, 'r') as f:
        cell_names = [x.strip() for x in f.readlines()]
        if len(cell_names) != len(set(cell_names)):
            raise Exception('Error: provided barcodes contain duplicates.')

    # Read sparse matrix into scipy coo sparse matrix object.
    sm = scipy.io.mmread(input_mtx)
    if transpose:
        sm = sm.T

    if not counts:
        # set dtype as float, so values won't be rounded
        sm = sm.astype('float32')

    assert sm.shape[0] == len(gene_names), 'Error: Number of genes does not match size of sparse matrix'
    assert sm.shape[1] == len(cell_names), 'Error: Number of barcodes does not match size of sparse matrix'

    if verbose:
        sys.stderr.write('\nFinished reading mtx file.\n')
        sys.stderr.write('\nData dimensions: {}\n'.format(sm.shape))

    return sm, gene_names, cell_names


def process(
        sm,
        gene_names,
        cell_names,
        map_to_human_orth=None,
        map_to_human_high_conf_only=False,
        use_ensembl=False,
        use_synonyms=True,
        no_hgnc_match=False,  # this should (almost) always be False
        duplicate_genes='first',
        verbose=False,
        map_to_human_orth_more=False,
        map_to_human_orth_all=False,
        map_to_human_expand_with_random_noise=False,
        map_to_human_orth_more_duplicate_genes=None
):
    """Process sparse matrix to by dropping duplicate genes, converting gene names to HGNC, or
    dropping unknown genes.

    Parameters
    ----------
    sm : scipy.sparse.coo.coo_matrix
        Sparse matrix with genes as rows and barcodes as columns.
    gene_names : list
        List of genes that correspond to the rows of the sparse matrix.
    cell_names : list
        List of barcodes that correspond to the columns of the sparse matrix.
    map_to_human_orth : bool, optional
        Map from non-human to human genes using 1-to-1 orthology relationships.
    map_to_human_high_conf_only : bool, optional
        When converting from non-human to human genes using the 1-to-1  orthology
        relationships, use only the high-confidence subset.
    use_ensembl : bool, optional
        If True, convert ENSEMBL ids (rows in the dataframe) to HGNC gene names.
    use_synonyms : bool, optional
        If True, try to match gene names in the dataframe to HGNC gene names using synonyms when
        possible.
    no_hgnc_match : bool, optional
        Skip matching gene names to HGNC names. It is generally recommended to match to HGNC.
    duplicate_genes : str, optional
        Duplicate genes selection. Default: first occurrence is kept.
        Other options are min/mean/median/max value from duplicate genes.
    verbose : bool, optional
        If True, print logging information to stderr.
    map_to_human_orth_more : bool, optional
        If True, one2many and many2many orthology relationships where multiple human genes correspond
        to a mouse gene, will result in duplicating the data of said mouse gene into multiple
        (identical) columns in the output.
    map_to_human_orth_all : bool, optional
        If True, result in ignoring confidence (high-confidence / low-confidence) information
        when expanding data from a single mouse gene to multiple human genes, otherwise when both
        high- and low-confidence mappings exist for a given mouse gene, only the high-confidence subset will be used.
    map_to_human_expand_with_random_noise : bool, optional
        If True, when duplicating data from a single mouse gene across multiple human gene counterpart
        (see related settings --map-to-human-orth-more and --map-to-human-orth-all), add a small amount of random
        noise to avoid identically duplicated data in the result.

    Returns
    -------
    sm : scipy.sparse.coo.coo_matrix
        Processed sparse matrix with genes as rows and barcodes as columns.
    gene_names : list
        List of genes that correspond to the rows of the processed sparse matrix.
    cell_names : list
        List of barcodes that correspond to the columns of the processed sparse matrix.
    dropped_elements : pandas.DataFrame
        Pandas dataframe containing dropped genes and a reason for it. Rows correspond to genes and
        columns to various information.
    """

    # IMPORTANT
    # on each step len(gene_names) == sm.shape[0]

    if not map_to_human_orth:
        # prep, upper-case gene names
        gene_names = [gene.upper() for gene in gene_names]
    gene_names = pd.Series(gene_names, index=gene_names)

    # create new dataframe for storing duplicates, not translated ids, etc.
    dropped_elements = pd.DataFrame(index=gene_names).assign(
        HGNC_symbol=gene_names, description=None)

    # remove duplicates
    gene_names, dropped_elements, sm = process_duplicates_sparse(
        gene_names, dropped_elements, sm, duplicate_genes=duplicate_genes, verbose=verbose)

    # converting ENSEMBL ids to HGNC gene names
    if use_ensembl:
        sys.stderr.write('\nConverting ENSEMBL ids to HGNC gene names...\n')

        gene_names, dropped_elements, sm = translate_ensembl_ids_to_hgnc_sparse(
            list(gene_names), dropped_elements, sm)

        # convert list to pandas series
        gene_names = pd.Series(gene_names, index=gene_names)

        # remove duplicates
        gene_names, dropped_elements, sm = process_duplicates_sparse(
            gene_names, dropped_elements, sm, duplicate_genes=duplicate_genes, verbose=verbose)

        if verbose:
            sys.stderr.write('\nNumber of genes after converting ENSEMBL ids to HGNC names: {}\n'.format(
                len(gene_names)))

    # mouse -> human genes orthology mapping
    if map_to_human_orth is not None:
        new_gene_names, converted_flag, genes_to_duplicate = commons.convert_genes_to_human_orth(
            gene_names,
            map_to_human_orth,
            high_conf_orthology_only=map_to_human_high_conf_only,
            map_to_human_orth_more=map_to_human_orth_more,
            map_to_human_orth_all=map_to_human_orth_all,
        )

        not_converted_flag = np.logical_not(converted_flag)

        # annotate unmapped genes
        not_converted_genes = gene_names.loc[not_converted_flag, ].index
        dropped_elements.loc[dropped_elements.HGNC_symbol.isin(not_converted_genes) &
                             dropped_elements.description.isnull(), 'description'] = 'Orthology mapping'

        # upper-case gene names, which have been converted
        upper_gene_names = [gene.upper() for gene, drop in zip(new_gene_names, not_converted_flag) if not drop]

        # update HGNC_symbol in dropped elements
        converted_genes = gene_names.loc[converted_flag, ].index
        dropped_elements.loc[dropped_elements.index.isin(converted_genes) &
                             dropped_elements.description.isnull(), 'HGNC_symbol'] = upper_gene_names

        duplicates = None
        duplicates_genes_names = []
        if genes_to_duplicate:
            duplicates_add_to_dropped = pd.DataFrame({'HGNC_symbol': [], 'description': []})
            for m_gene, h_genes in sorted(genes_to_duplicate.items(), key=lambda x: x[0]):
                h_genes = h_genes[1:]  # first new column will replace the old column (not need of matrix extension)
                new_cols = np.array([sm[gene_names.index.get_loc(m_gene)].toarray().flatten() for _ in h_genes])
                if map_to_human_expand_with_random_noise:
                    np.random.seed(0)
                    noise = np.random.normal(0, 1e-12, new_cols.shape)
                    non_zeros = (new_cols != 0)
                    new_cols[non_zeros] += noise[non_zeros]
                if duplicates is None:
                    duplicates = scipy.sparse.csr_matrix(new_cols)
                else:
                    duplicates = scipy.sparse.vstack((duplicates, scipy.sparse.csr_matrix(new_cols)))
                duplicates_genes_names += h_genes
                duplicates_add_to_dropped = duplicates_add_to_dropped.append(
                    pd.DataFrame({
                        'HGNC_symbol': h_genes,
                        'description': [None for _ in h_genes]},
                        index=[m_gene for _ in h_genes]))
            sys.stderr.write('\nMatrix extended by multi-mapped human orthologs: {} genes added\n'.format(duplicates.shape[0]))
            dropped_elements = pd.concat((dropped_elements, duplicates_add_to_dropped), axis=0)

        # remove unmapped genes
        sm = sm[converted_flag, :]

        # add duplicated genes
        if duplicates is not None:
            sm = scipy.sparse.vstack((sm, duplicates))

        # add new genes names
        upper_gene_names += [gene.upper() for gene in duplicates_genes_names]

        # update gene names
        gene_names = pd.Series(upper_gene_names, index=upper_gene_names)

        # remove duplicates
        gene_names, dropped_elements, sm = process_duplicates_sparse(
            gene_names, dropped_elements, sm, duplicate_genes=map_to_human_orth_more_duplicate_genes)

    help = sm.toarray()
    # HGNC name filtering/matching
    if not no_hgnc_match:
        gene_conv = commons.convert_to_HGNC_names(
            gene_names.index,
            use_syn=use_ensembl or use_synonyms,
            verbose=verbose,
        )
        not_conv = gene_conv[gene_conv.isnull()].index

        # remove unconverted genes
        gene_names = gene_names.loc[~gene_names.index.isin(not_conv),]
        if not scipy.sparse.isspmatrix_csr(sm):
            sm = sm.tocsr()
        sm = sm[np.where(~gene_conv.isnull())]

        # annotate unconverted genes
        dropped_elements.loc[dropped_elements.HGNC_symbol.isin(not_conv) &
                             dropped_elements.description.isnull(), 'description'] = 'HGNC conversion'
        if verbose:
            sys.stderr.write('\nNumber of genes after matching/filtering HGNC symbols: {}\n'.format(
                len(gene_names)))

        # remove duplicates
        gene_names, dropped_elements, sm = process_duplicates_sparse(
            gene_names, dropped_elements, sm, duplicate_genes=duplicate_genes)

    # select rows, which were duplicated or weren't translated to HGNC symbols or didn't pass HGNC filtering (mask_hgnc)
    dropped_elements = dropped_elements.loc[~dropped_elements.description.isnull(), :]
    if not use_ensembl:
        # drop column with HGNC symbols since it's a duplicate of an index
        dropped_elements.drop('HGNC_symbol', axis=1, inplace=True)

    # notify user about number of dropped elements due to duplication reasons
    no_of_duplicated_elements = dropped_elements[dropped_elements.description == 'Duplicated'].shape[0]
    if duplicate_genes == 'first' and no_of_duplicated_elements > 0:
        sys.stderr.write(('\nNumber of dropped genes due to duplication: {}. Consider using '
                          '`duplicate_genes` option to aggregate them.\n'.format(no_of_duplicated_elements)))

    if verbose:
        sys.stderr.write('\nFinished preprocessing.\n')

    return sm, list(gene_names), cell_names, dropped_elements


def write(
        sm,
        gene_names,
        cell_names,
        samples_domain,
        dropped_elements,
        output_mtx,
        counts=False,
        precision=3,
        no_save_dropped=False,
        verbose=False,
):
    """Write processed sparse matrix as BI sparse matrix.

    Parameters
    ----------
    sm : scipy.sparse.coo.coo_matrix
        Processed sparse matrix with genes as rows and barcodes as columns.
    gene_names : list
        List of genes that correspond to the rows of the processed sparse matrix.
    cell_names : list
        List of barcodes that correspond to the columns of the processed sparse matrix.
    dropped_elements : pandas.DataFrame
        Pandas dataframe containing dropped genes and a reason for it. Rows correspond to genes and
        columns to various information.
    samples_domain : str
        Domain of samples; e.g. your organization name.
    output_mtx : str
        Path to write mtx file to. Must have .mtx suffix.
    counts : bool
        If True, the data are counts and should be written as integers. If False, the data are
        assumed to be log2 TPM (or something similar) and will be written with precision specified
        by --precision.
    precision : int
        Number of digits to include for non-integer data. Not applicable when --counts is used.
    no_save_dropped : bool, optional
        Skip saving dropped elements to additional file. (default = False)
    verbose : bool, optional
        If True, print logging information to stderr.
    """
    msg = 'Error: Output mtx file must have mtx file suffix.'
    assert os.path.splitext(output_mtx)[1] == '.mtx', msg

    # NOTE: We can take an omic_type parameter in the future that would set the gene_json_func to
    # other functions to allow writing of sparse matrices for other data types.
    gene_json_func = commons.column_json_rna_abundance
    cell_json_func = commons.sample_row_json

    # reformat row/column headers
    cell_json = [json.dumps(cell_json_func(x, samples_domain), sort_keys=True) for x in cell_names]
    gene_json = [json.dumps(gene_json_func(x), sort_keys=True) for x in gene_names]

    # format with csvwriter
    if sys.version_info[0] < 3:
        output = io.BytesIO()
    else:
        output = io.StringIO()
    writer = csv.writer(output, delimiter=' ', quotechar='"')
    writer.writerow(gene_json)
    writer.writerow(cell_json)
    genes, cells = output.getvalue().strip('\n').split('\n')

    # write mtx file
    if verbose:
        sys.stderr.write('\nData dimensions: {}\n'.format(sm.shape))
        sys.stderr.write('\nWriting {}\n'.format(output_mtx))

    sm.eliminate_zeros()
    with open(output_mtx, 'w+') as writer_mtx:
        if counts:
            sm = sm.astype('int32').tocsr().sorted_indices().tocoo()
            writer_mtx.write("%%MatrixMarket matrix coordinate integer general\n")
        else:
            sm = sm.astype('float32').tocsr().sorted_indices().tocoo()
            writer_mtx.write("%%MatrixMarket matrix coordinate real general\n")

        # comments - genes and cells
        writer_mtx.write("% {}\n% {}\n".format(genes, cells))

        # sparse matrix shape (row, col, number of non-zero elements)
        writer_mtx.write("{} {} {}\n".format(sm.shape[0], sm.shape[1], sm.getnnz()))

        precision_format = None
        if not counts and precision:
            # Note that setting precision to something less than the input tsv will mean that an mtx and
            # tbl created from the same tsv will have different values which will make the results in
            # the single cell app different. Even small rounding throughout can make the UMAP/t-SNE
            # projections look quite different.
            precision_format = '{:.' + str(precision - 1) + 'e}'

        for row, col, val in zip(sm.row + 1, sm.col + 1, sm.data):
            if precision_format:
                val = precision_format.format(val)
            writer_mtx.write('{} {} {}\n'.format(str(row), str(col), str(val)))

    if verbose:
        sys.stderr.write('\nWrote data table (.tbl) file to: {}\n'.format(output_mtx))

    # Save dropped and aggregated elements to files
    if not no_save_dropped and not dropped_elements.empty:
        commons.write_dropped_aggregated_as_tsv(dropped_elements, output_mtx)


def format_file(
        input_mtx,
        genes,
        barcodes,
        samples_domain,
        output_mtx,
        use_ensembl=False,
        use_synonyms=True,
        no_hgnc_match=False,
        map_to_human_orth=None,
        map_to_human_high_conf_only=False,
        transpose=False,
        counts=False,
        precision=3,
        no_save_dropped=False,
        duplicate_genes='first',
        verbose=False,
        map_to_human_orth_more=False,
        map_to_human_orth_all=False,
        map_to_human_expand_with_random_noise=False,
        map_to_human_orth_more_duplicate_genes=None
):
    """Format matrix market file containing sparse RNA-seq counts as a BI sparse matrix file.

    Parameters
    ----------
    input_mtx : str
        Path to input file matrix market (mtx) file with counts.
    genes : str
        Path to input file with genes that correspond to rows of sparse matrix.
    barcodes : str
        Path to input file with barcodes/identifiers that correspond to columns of sparse
        matrix.
    samples_domain : str
        Domain of samples; e.g. your organization name.
    output_mtx: str
        Path to write mtx file to. Must have .mtx suffix.
    use_ensembl : bool, optional
        If True, convert ENSEMBL ids (rows in the dataframe) to HGNC gene names.
    use_synonyms : bool, optional
        If True, try to match gene names in the dataframe to HGNC gene names using synonyms when
        possible.
    no_hgnc_match : bool, optional
        Skip matching gene names to HGNC names. It is generally recommended to match to HGNC.
    map_to_human_orth : bool, optional
        Map from non-human to human genes using 1-to-1 orthology relationships.
    map_to_human_high_conf_only : bool, optional
        When converting from non-human to human genes using the 1-to-1  orthology
        relationships, use only the high-confidence subset.
    transpose : bool, optional
        Transpose sparse matrix prior to formatting; use if rows represent barcodes/cells and
        columns represent genes.
    counts : bool, optional
        Input mtx file contains count data. Output mtx file will contain integers.
    precision : int
        Number of digits to include for non-integer data. Not applicable when --counts is used.
    no_save_dropped : bool, optional
    duplicate_genes : str, optional
        Duplicate genes selection. Default: first occurrence is kept.
        Other options are min/mean/median/max value from duplicate genes.
    verbose : bool, optional
        If True, print logging information to stderr.
    map_to_human_orth_more : bool, optional
        If True, one2many and many2many orthology relationships where multiple human genes correspond
        to a mouse gene, will result in duplicating the data of said mouse gene into multiple
        (identical) columns in the output.
    map_to_human_orth_all : bool, optional
        If True, result in ignoring confidence (high-confidence / low-confidence) information
        when expanding data from a single mouse gene to multiple human genes, otherwise when both
        high- and low-confidence mappings exist for a given mouse gene, only the high-confidence subset will be used.
    map_to_human_expand_with_random_noise : bool, optional
        If True, when duplicating data from a single mouse gene across multiple human gene counterpart
        (see related settings --map-to-human-orth-more and --map-to-human-orth-all), add a small amount of random
        noise to avoid identically duplicated data in the result.
    """

    if counts:
        if map_to_human_expand_with_random_noise:
            raise Exception('\nError: option "--map-to-human-extend-with-random-noise" is available only '
                            'for continuous data.')
        if map_to_human_orth_more_duplicate_genes not in [None, 'min', 'max']:
            raise Exception('\nError: for counts data option "--map-to-human-orth-more-duplicate-genes" can be '
                            'only min or max')
    if map_to_human_orth is not None and map_to_human_orth_more_duplicate_genes is None:
        if counts:
            map_to_human_orth_more_duplicate_genes = 'min'
        else:
            map_to_human_orth_more_duplicate_genes = 'mean'

    sm, gene_names, cell_names = read(
        input_mtx,
        genes,
        barcodes,
        counts=counts,
        transpose=transpose,
        verbose=verbose,
    )
    if counts and any(np.squeeze(np.asarray(np.isnan(sm.tocsr()[sm.nonzero()])))):
        counts = False
        sm = sm.astype('float32')
        sys.stderr.write('\nWarning: input matrix contains NaNs, it will be saved as floats\n')

    sm, gene_names, cell_names, dropped_elements = process(
        sm,
        gene_names,
        cell_names,
        map_to_human_orth=map_to_human_orth,
        map_to_human_high_conf_only=map_to_human_high_conf_only,
        use_ensembl=use_ensembl,
        use_synonyms=use_synonyms,
        no_hgnc_match=no_hgnc_match,
        duplicate_genes=duplicate_genes,
        verbose=verbose,
        map_to_human_orth_more=map_to_human_orth_more,
        map_to_human_orth_all=map_to_human_orth_all,
        map_to_human_expand_with_random_noise=map_to_human_expand_with_random_noise,
        map_to_human_orth_more_duplicate_genes=map_to_human_orth_more_duplicate_genes
    )
    write(
        sm,
        gene_names,
        cell_names,
        samples_domain=samples_domain,
        dropped_elements=dropped_elements,
        output_mtx=output_mtx,
        no_save_dropped=no_save_dropped,
        counts=counts,
        verbose=verbose,
        precision=precision,
    )


def process_duplicates_sparse(gene_names, dropped_elements, sm, duplicate_genes='first', verbose=True):
    if verbose:
        sys.stderr.write('\nSearching for duplicate genes\n')
    # find duplicates
    duplicates_mask = gene_names.duplicated()
    duplicates = set(gene_names.loc[duplicates_mask].index)

    # leaving first row from duplicated ones is default behaviour and doesn't require any additional steps
    if duplicate_genes != 'first':
        if duplicate_genes not in ['min', 'max', 'mean', 'median']:
            raise Exception('Non-supported way of duplicate genes selection. Available: min, max, mean and median.')
        if not scipy.sparse.isspmatrix_coo(sm):
            sm = sm.tocoo()

        new_rows, new_cols, new_data, indices_to_remove = [], [], [], []
        for gene in duplicates:
            # get indices with gene
            duplicates_indices = np.where(gene_names == gene)[0]

            # index of row (gene), which stays in final matrix
            # duplicated occurrences of particular gene are removed
            index = duplicates_indices[0]
            if index in sm.row:
                # if values for particular row exists, then remove them
                indices_to_remove.extend(np.where(np.in1d(sm.row, index))[0])

            # compute new values, update only first occurrence since it's gonna stay
            if duplicate_genes in ['min', 'max']:
                new_values = getattr(sm.tocsr()[duplicates_indices, :], duplicate_genes)(axis=0)
                # min, max from scipy returns coo matrix
                new_data.extend(new_values.data)
                new_rows.extend([index] * len(new_values.data))
                new_cols.extend(new_values.col)
            else:
                if duplicate_genes == 'median':
                    # median is not supported natively be scipy
                    new_values = np.median(sm.tocsr()[duplicates_indices, :].toarray(), axis=0)
                else:
                    # mean from scipy returns numpy matrix
                    new_values = getattr(sm.tocsr()[duplicates_indices, :], duplicate_genes)(axis=0).A1
                new_data.extend(new_values)
                new_rows.extend([index] * len(new_values))
                new_cols.extend(range(len(new_values)))

        # ensure that updated elements are valid
        assert len(new_rows) == len(new_cols)
        assert len(new_cols) == len(new_data)

        # create new coo matrix
        sm = scipy.sparse.coo_matrix((np.hstack([np.delete(sm.data, indices_to_remove), new_data]),
                                      (np.hstack([np.delete(sm.row, indices_to_remove), new_rows]),
                                       np.hstack([np.delete(sm.col, indices_to_remove), new_cols]))),
                                     shape=sm.shape)

    # remove duplicates
    gene_names = gene_names.loc[~duplicates_mask,]

    # remove duplicated genes from sparse matrix
    if not scipy.sparse.isspmatrix_csr(sm):
        sm = sm.tocsr()
    sm = sm[np.where(~duplicates_mask)]

    # annotate duplicates
    dropped_mask = dropped_elements.HGNC_symbol.isin(duplicates) & \
                   dropped_elements.HGNC_symbol.duplicated() & \
                   dropped_elements.description.isnull()
    dropped_elements.loc[dropped_mask, 'description'] = 'Duplicated' if duplicate_genes == 'first' else 'Aggregated'
    if verbose:
        sys.stderr.write('\n{} {} duplicate genes\n'.format(
            'Removed' if duplicate_genes == 'first' else 'Aggregated',
            duplicates_mask.sum()
        ))

    return gene_names, dropped_elements, sm


def translate_ensembl_ids_to_hgnc_sparse(gene_names, dropped_elements, sm):
    # Read tsv file with annotated ids and convert it to dict {ensembl_id: hgnc_gene_name}
    annotation_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'data',
                                   'ENSEMBL_mapping.txt.gz')
    annotation = pd.read_csv(annotation_path, sep='\t', index_col=1,
                             header=0, compression='gzip').to_dict()['Approved Symbol']

    dropped_elements['HGNC_symbol'] = None
    converted_gene_names, converted_gene_indices = [], []
    for index, ensembl_id in enumerate(gene_names):
        # remove part after dot in ensembl ids and ensure it's upper case
        current_id = ensembl_id.split('.')[0].upper()

        # annotate id with hgnc gene names
        gene_name = annotation.get(current_id, None)
        if gene_name is not None:
            # save converted genes and their indices
            converted_gene_indices.append(index)
            converted_gene_names.append(gene_name)

            # annotate converted ensembl id
            dropped_elements.loc[ensembl_id, 'HGNC_symbol'] = gene_name
        else:
            # description must be null, so we don't overwrite already existing one
            dropped_elements.loc[dropped_elements.index.isin([ensembl_id]) &
                                 dropped_elements.description.isnull(), 'description'] = 'ENSEMBL conversion'

    # leave only converted genes
    if not scipy.sparse.isspmatrix_csr(sm):
        sm = sm.tocsr()
    sm = sm[converted_gene_indices, :]

    return converted_gene_names, dropped_elements, sm
