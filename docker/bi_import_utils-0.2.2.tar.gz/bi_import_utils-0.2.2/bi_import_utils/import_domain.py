import argparse
import glob
import json
import os
import sys

import pandas as pd

from bi_import_utils import ontology
from bi_import_utils import commons


def import_domain(gmt_fpath, domain_name, domain_fpath, descriptions=False, skip_HGNC_match=False):

    log_fpath = domain_fpath + '.log'

    # HGNC genes & synonyms
    hgnc = commons.read_HGNC()

    def match_genes(genes, t_name, log_f):
        genes_matched = commons.synonyms_match(genes, hgnc)
        genes_matched = set(genes_matched)
        if genes_matched != genes:
            log_f.write('HGNC matching modified genes in: {}\n'.format(t_name))
            log_f.write('\t{} -> {} genes\n'.format(len(genes), len(genes_matched)))
            log_f.write('\tOld-only: {}\n'.format(', '.join(set(genes) - set(genes_matched))))
            log_f.write('\tNew-only: {}\n'.format(', '.join(set(genes_matched) - set(genes))))
        return genes_matched

    # gmt gene sets
    gmt = {}
    descs = {}
    with open(gmt_fpath, 'r') as f:
        for line in f:
            gmt_line = line.rstrip().split('\t')
            if gmt_line[0] in gmt:
                sys.exit('\nDuplicate gene set name: {}. Quitting.\n'.format(gmt_line[0]))
            gmt[gmt_line[0]] = set([x for x in gmt_line[2:] if x])
            descs[gmt_line[0]] = gmt_line[1].strip()

    # gene sets
    if skip_HGNC_match:
        print('\nNOT matching gene names to HGNC. Use with care.')
        gene_sets = gmt
    else:
        print('\nMatching gene names to HGNC using synonyms...')
        gene_sets = {}
        with open(log_fpath, 'w') as log_f:
            for i, (t_name, t_genes) in enumerate(gmt.items()):
                if i % 100 == 0:
                    print('{} of {}'.format(i, len(gmt)))
                    sys.stdout.flush()
                t_genes_match = match_genes(t_genes, t_name, log_f)
                if t_genes_match:
                    gene_sets[t_name] = t_genes_match

    # print json.dumps(gene_sets, indent=2)
    print('\nNum. of gene sets: {}\n'.format(len(gene_sets)))

    # domain
    domain = {}
    for gs_name, gs in gene_sets.items():
        domain[gs_name] = {
            'label': gs_name,
            'name': gs_name,
            'description': '',
            'genes': list(set(gs)),
            'type': 'term',
            'domain': domain_name,
        }
        if descriptions and descs[gs_name]:
            domain[gs_name]['description'] = descs[gs_name]

    # write
    with open(domain_fpath, 'w') as f:
        for t_name, t_d in domain.items():
            f.write(json.dumps(t_d, sort_keys=True) + '\n')

def main():
    parser = argparse.ArgumentParser(
        description=('Convert gmt file into Data4Cure domain file.'),
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument(
        'gene_sets', 
        help=('gmt file with gene sets.'),
    )
    parser.add_argument(
        'domain_name',
        help=('Name for the new domain. If the name contains spaces, you can '
              'wrap it in quotes (e.g. "My New Domain")'),
    )
    parser.add_argument(
        'output_domain_file',
        help=('Output file for the new domain.'),
    )
    parser.add_argument(
        '--skip-HGNC-match',
        action='store_true',
        default=False,
        help='Skip matching gene names to HGNC. Use with caution.',
    )
    parser.add_argument(
        '--descriptions',
        action='store_true',
        default=False,
        help='Add description from the 2nd item in each row, if non-empty.',
    )

    args = parser.parse_args()

    gene_sets = args.gene_sets
    domain_name = args.domain_name
    output_domain_file = args.output_domain_file
    descriptions = args.descriptions
    skip_HGNC_match = args.skip_HGNC_match

    import_domain(gene_sets, domain_name, output_domain_file,
                  descriptions=descriptions, skip_HGNC_match=skip_HGNC_match)

if __name__ == '__main__':
    main()
