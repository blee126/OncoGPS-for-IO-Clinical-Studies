import collections
import json
import sys
import copy

import pandas as pd

from bi_import_utils import ontology
from bi_import_utils import commons

'''
Format a tab-separated data matrix with RPPA data as BI data table.

Copyright 2017 Data4Cure, Inc. All rights reserved.
'''


def read(input_tsv, transpose=False, verbose=False):
    """Read tab-separated file with RPPA data.
    
    Parameters
    ----------
    input_tsv : str
        Path to input file containing RPPA data. Rows correspond to samples and columns correspond
        to proteins.
    transpose : bool, optional
        Transpose matrix when reading; use if rows represent proteins and columns represent samples.
    verbose : bool, optional
        If True, print logging information to stderr.
    
    Returns
    -------
    df : pandas.DataFrame
        Pandas dataframe containing RPPA data. Rows correspond to samples and columns correspond to
        proteins.
    """
    if verbose:
        sys.stderr.write('\nReading data file {}\n'.format(input_tsv))
    df = pd.read_csv(input_tsv, sep='\t', header=0, index_col=0,
                     na_values='NA', low_memory=False)
    if transpose:
        df = df.T
    return(df)


def process(rppa_data, use_synonyms=True, verbose=False):
    """Process dataframe with RPPA data. Convert protein expression to gene-level measurements.
    
    Parameters
    ----------
    rppa_data : pandas.DataFrame
        Pandas dataframe containing RPPA data. Rows correspond to samples and columns correspond to
        proteins.
    verbose : bool, optional
        If True, print logging information to stderr.
    
    Returns
    -------
    exp : pandas.DataFrame
        Pandas dataframe containing protein expression per gene.
    """
    # Create deepcopy of input matrix to avoid changing input object
    rppa_data = rppa_data.copy(deep=True)
    # remove duplicates, if any
    if len(set(rppa_data.columns)) != len(rppa_data.columns):
        dups = [x for x, c in collections.Counter(rppa_data.columns).items() if c > 1]
        rppa_data.drop(dups, axis=1, inplace=True)
        if verbose:
            sys.stderr.write('\nRemoved {} duplicate columns.\n'.format(len(dups)))

    protein_to_gene = commons.read_protein_to_gene()
    synonyms = commons.read_protein_synonyms()

    # Replace protein name synonyms with our "accepted" names
    missing = set(rppa_data.columns) - set(protein_to_gene.keys())
    unknown = missing - set(synonyms.index)

    if unknown:
        sys.stderr.write('\nDropping {} unknown identifiers.\n'.format(len(unknown)))
        # print '\n'.join(unknown)

    rppa_data = rppa_data.drop(unknown, axis=1)
    rppa_data = rppa_data.rename(dict(synonyms['name']), axis=1)  # replaces only subset that IS a synonym, ignores rest

    # remove duplicates, if any
    if len(set(rppa_data.columns)) != len(rppa_data.columns):
        dups = [x for x, c in collections.Counter(rppa_data.columns).items() if c > 1]
        rppa_data.drop(dups, axis=1, inplace=True)
        if verbose:
            sys.stderr.write('\nRemoved {} duplicate columns.\n'.format(len(dups)))

    # Construct new matrix with genes as index
    expression = []
    for protein in rppa_data.columns:
        for gene in protein_to_gene[protein]:
            expression.append([gene] + list(rppa_data[protein]))
    exp = pd.DataFrame(expression, columns=['gene'] + list(rppa_data.index))
    exp = exp.groupby('gene').max().T

    if verbose:
        sys.stderr.write('\nData dimensions: {}\n'.format(rppa_data.shape))

    return(exp)


def write(rppa_data, samples_domain, output_tbl, verbose=False):
    """Write processed dataframe with RPPA data to BI tbl file.
    
    Parameters
    ----------
    rppa_data : pandas.DataFrame
        Pandas dataframe containing RPPA data that has been processed. Rows correspond to samples
        and columns correspond to protein expression per gene.
    samples_domain : str
        Domain of samples; e.g. your organization name.
    output_tbl: str
        Path to write tbl file to.
    verbose : bool, optional
        If True, print logging information to stderr.
    """
    def get_phospho_aa_list(x):
        # TODO: handle also modifications like 'FOXO3a_pS318_S321'
        # be sure it's always the case that after pXXX the following
        # are phosphorilations as well
        return([a[1:] for a in x.split('_') if a.startswith('p')])


    def get_mod_protein_phospho():
        return({
            'type': 'protein_modification',
            'details': {
                'type': 'phosphorylation',
            }
        })


    def mod_update(em):
        x = em['entity']['label']
        if '_p' in x:
            mod_phospho = get_mod_protein_phospho()
            p_aa = get_phospho_aa_list(x)
            mod_phospho['details']['phosphorylated_aa'] = p_aa
            em['modification'] = mod_phospho
        return(em)

    # def column_json(x):
    #     return(mod_update({
    #         'data_type': ontology.NUMERIC,
    #         'entity': {
    #             'name': x,
    #             'label': x,
    #             'type': 'protein',
    #             'domain': {'name': 'RPPA'},
    #         },
    #         'label': '{} ProteinAbundance'.format(x),
    #         'abundance': 'protein_abundance',
    #     }))
    
    def column_json_protein_abundance(g):
        return({
            'label': g + ' ' + ontology.ABUNDANCE_LABELS[ontology.PROTEIN_ABUNDANCE],
            'data_type': ontology.NUMERIC,
            'entity': {
                'domain': copy.deepcopy(ontology.HGNC_DOMAIN),
                'name': g,
                'label': g,
                'type': ontology.GENE_TYPE,
            },
            'abundance': ontology.PROTEIN_ABUNDANCE,
        })

    rppa_data.index = [json.dumps(commons.sample_row_json(x, samples_domain), sort_keys=True) for x in
                       rppa_data.index]
    rppa_data.columns = [json.dumps(column_json_protein_abundance(x), sort_keys=True) for x in rppa_data.columns]

    # write BI table
    commons.write_df_as_tbl(rppa_data, output_tbl)
    if verbose:
        sys.stderr.write('\nWrote data table (.tbl) file to: {}\n'.format(output_tbl))


def format_file(
    input_tsv,
    samples_domain,
    output_tbl,
    use_synonyms=True,
    transpose=False,
    verbose=False,
):
    """Read file containing RPPA data and write as BI tbl file.
    
    Parameters
    ----------
    input_tsv : str
        Path to input file containing RPPA data. Rows correspond to samples and columns correspond
        to proteins.
    samples_domain : str
        Domain of samples; e.g. your organization name.
    output_tbl: str
        Path to write tbl file to.
    use_synonyms : bool, optional
        If True, try to match protein names to protein names in the BI RPPA domain.
    transpose : bool, optional
        Transpose matrix when reading; use if rows represent proteins and columns represent samples.
    verbose : bool, optional
        If True, print logging information to stderr.
    """
    rppa_data = read(input_tsv, transpose, verbose)
    rppa_data = process(rppa_data, use_synonyms, verbose)
    write(rppa_data, samples_domain, output_tbl, verbose)
