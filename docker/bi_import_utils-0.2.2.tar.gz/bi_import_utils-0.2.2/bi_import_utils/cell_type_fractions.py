import json
import sys
import pandas as pd
import six

from bi_import_utils import commons

'''
Format a tab-separated data matrix with cell-type fractions as BI data table.

Copyright 2020 Data4Cure, Inc. All rights reserved.
'''


def read(input_tsv, transpose=False, verbose=False):
    """Read tab-separated file with cell-type fractions.
    
    Parameters
    ----------
    input_tsv : str
        Path to input file containing cell-type fractions. Rows should correspond to samples and
        columns should correspond to cell types.
    transpose : bool, optional
        Transpose matrix when reading; use if rows represent cell types and columns represent samples.
    verbose : bool, optional
        If True, print logging information to stderr.
    
    Returns
    -------
    fractions : pandas.DataFrame
        Pandas dataframe containing cell-type fractions. Rows correspond to samples and columns
        correspond to cell types.
        
    """
    if verbose:
        sys.stderr.write('\nReading input from {}\n'.format(input_tsv))

    fractions = pd.read_csv(input_tsv, sep='\t', header=0, index_col=0, na_values='NA',
                            low_memory=False)
    if transpose:
        fractions = fractions.T

    if verbose:
        sys.stderr.write('\nData dimensions: {}\n'.format(fractions.shape))

    return fractions


def write(fractions, samples_domain, output_tbl, verbose=False):
    """Write cell-type fractions as BI tbl file.
    
    Parameters
    ----------
    fractions : pandas.DataFrame
        Path to input file containing cell-type fractions. Rows should correspond to samples and
        columns should correspond to cell types.
    output_tbl: str
        Path to write tbl file to.
    samples_domain : str
        Domain of samples; e.g. your organization name.
    verbose : bool, optional
        If True, print logging information to stderr.
    """

    # format BI table
    def column_json_cell_type(x):
        x = six.text_type(x)
        return {
            'data_type': {
                'name': 'numeric',
                'type': 'numeric',
            },
            'entity': {
                'name': x,
                'label': x,
                'type': 'cell_type',
                'domain': {'name': 'Cell type'},
            },
            'label': x,
        }

    def row_json_sample(x, samples_domain='D4C'):
        x = six.text_type(x)
        return {
            'sample': {
                'source': samples_domain,
                'barcode': x,
                'subject': {'domain': samples_domain, 'domain_id': x}
            },
            'label': '{} {}'.format(samples_domain, x),
        }

    fractions.index = [json.dumps(row_json_sample(x, samples_domain=samples_domain),
                                  sort_keys=True) for x in fractions.index]
    fractions.columns = [json.dumps(column_json_cell_type(x), sort_keys=True) for x in fractions.columns]

    # write BI table
    commons.write_df_as_tbl(fractions, output_tbl)
    if verbose:
        sys.stderr.write('\nWrote data table (.tbl) file to: {}\n'.format(output_tbl))


def format_file(input_tsv, samples_domain, output_tbl, transpose=False, verbose=False):
    """Read file containing cell-type fractions and write as BI tbl file.
    
    Parameters
    ----------
    input_tsv : str
        Path to input file containing cell-type specific signatures.
    samples_domain : str
        Domain of samples; e.g. your organization name.
    output_tbl: str
        Path to write tbl file to.
    transpose : bool, optional
        Transpose matrix when reading; use if rows represent cell types and columns represent samples.
    verbose : bool, optional
        If True, print logging information to stderr.
    """
    fractions = read(input_tsv, transpose, verbose)
    write(fractions, samples_domain, output_tbl, verbose)
