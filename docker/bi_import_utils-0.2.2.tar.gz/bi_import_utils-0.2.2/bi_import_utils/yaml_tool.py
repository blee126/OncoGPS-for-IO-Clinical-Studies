import os
import sys
import pandas as pd
import json
import numpy as np
from natsort import natsorted

IDK = ['nan', 'null', 'none', '', 'na', '<na>', np.nan, 'unknown', 'not assigned', 'not given',
       'not available', 'not applicable', 'not available year']

YES_NO = ['yes', 'y', 'no', 'n']


def isfloat(value):
    try:
        float(value)
        return True
    except ValueError:
        return False


def yes_no(question, default_yes=True):
    if default_yes:
        yes_no_brackets = '([yes]/no)'
        default = 'yes'
    else:
        yes_no_brackets = '(yes/[no])'
        default = 'no'
    answer = 'WRONG'
    while answer not in YES_NO:
        answer = input('{} {}: '.format(question, yes_no_brackets))
        if answer and answer not in YES_NO:
            print('Given value "{}" is incorrect - please select one of: {}.'.format(answer, YES_NO))
        elif not answer:
            answer = default
    if answer in ['yes', 'y']:
        return True
    else:
        return False


def ask_about_value(question, possible_vals=None, default=None):
    ask_again = True
    while ask_again:
        answer = str(input('{}: '.format(question)))
        if not answer or answer.lower() == 'none':
            if default is not None:
                answer = default
                print('Value set to default "{}"'.format(answer))
                ask_again = False
            else:
                accept = yes_no('Value not given, no default is defined. Should this value be left empty?')
                if accept:
                    ask_again = False
                    if answer.lower() == 'none':
                        answer = ''
        elif possible_vals is not None and answer.lower() not in [el.lower() for el in possible_vals]:
            print('Given value "{}" is incorrect - please select one of: {}.'.format(answer, possible_vals))
        else:
            print('Value set to "{}"'.format(answer))
            if answer != default:
                ask_again = not yes_no('Do you accept it?')
            else:
                ask_again = False
    return answer


def add_suffix(col_json=None, suffix=None, disease=False):
    if suffix is not None:
        change_suffix = not yes_no('Suffix was set to "{}". Do you accept it?'.format(suffix))
        suffix_ask = 'Give new suffix'
    elif disease:
        change_suffix = yes_no('Do you want to add some additional information (e.g. "CD4+ T cells")?',
                               default_yes=False)
        suffix_ask = 'Give additional info about the disease'
    else:
        change_suffix = yes_no('Do you want to set suffix for values from this column?', default_yes=False)
        suffix_ask = 'Give suffix'
    if change_suffix:
        suffix = ask_about_value(suffix_ask, default=suffix)
        if disease:
            suffix = '({})'.format(suffix)
    if col_json is not None and suffix is not None:
        if 'measurement' not in col_json:
            col_json['measurement'] = {}
        col_json['measurement']['label_suffix'] = suffix
    if col_json is not None:
        return col_json
    else:
        return suffix


def get_new_order(num_values, org_pos):
    order = ask_about_value('Give new order of this value (number 1-{}/start/[end])'.format(num_values),
                       [str(el) for el in range(1, num_values + 1)] + ['start', 'end'], 'end')
    if order == 'start':
        new_pos = 0
    elif order.isnumeric():
        new_pos = int(order) - 1
    else:
        new_pos = org_pos
    return new_pos


def change_order_labels(uni, col, meta, data_type, change_order=False, change_label=False):
    num_rows = meta.shape[0]
    print('Order of {} factor levels of column "{}", by their labels: {}'.
          format(len(uni), col, uni))
    if change_order and not change_label:
        get_values = yes_no("Do you want to change factor levels order?", default_yes=False)
        if get_values:
            get_values = 'o'
        else:
            get_values = 'n'
    elif not change_order and change_label:
        get_values = yes_no("Do you want to change factor labels?", default_yes=False)
        if get_values:
            get_values = 'l'
        else:
            get_values = 'n'
    else:
        get_values = ask_about_value("Do you want to change factor levels order (o), labels (l), both (b) or "
                                     "[nothing]?", ['order', 'o', 'labels', 'l', 'both', 'b', 'nothing', 'n'],
                                     'nothing')
    change_order = False
    change_label = False
    num_values = len(uni)
    new_labels, new_uni = {}, [el for el in uni]
    if get_values in ['order', 'o', 'both', 'b']:
        change_order = True
    if get_values in ['labels', 'l', 'both', 'b']:
        change_label = True
    if change_order or change_label:
        for i, val in enumerate(uni):
            print('{}. Value "{}" ({:.2f}% of rows)'.
                  format(i + 1, val, meta[col].astype(str).value_counts().loc[val]/num_rows*100))
            if change_order:
                new_pos = get_new_order(num_values, i)
                del new_uni[new_pos]
                new_uni.insert(new_pos, val)
            if change_label:
                default = 'keep original'
                label = ask_about_value('Give new label of this value (or [keep original])', default=default)
                if label == default:
                    label = val
                new_labels[val] = label
        if change_order and change_label:
            print('New order of factor levels by their new labels: {}'.format([new_labels[el] for el in new_uni]))
        elif change_order:
            print('New order of factor levels: {}'.format(new_uni))
        elif change_label:
            print('New labels of factor levels: {}'.format(', '.join(['{} -> {}'.format(el, la) for el, la in
                                                                      new_labels.items()])))
    if new_labels:
        new_ordered_labels = [new_labels[el] for el in new_uni]
    else:
        new_ordered_labels = new_uni
    if data_type == 'character':
        levels = [{'value': el, 'label': el} for el in new_ordered_labels]
        col_rewrite = new_labels
    elif data_type == 'numeric':
        levels = [{'value': i, 'label': el} for i, el in enumerate(new_ordered_labels)]
        col_rewrite = {el: i for i, el in enumerate(new_uni)}
    else:
        raise Exception('WRONG type_type: {}'.format(data_type))
    return col_rewrite, levels


def get_proper_name(type_str):
    if type_str.lower() in ['factor', 'f']:
        return 'factor'
    elif type_str.lower() in ['numeric', 'n']:
        return 'numeric'
    elif type_str.lower() in ['character', 'c']:
        return 'character'
    else:
        raise ValueError


def get_type_name():

    type_name = ask_about_value("Select column type: [factor] (f) / numeric (n) / character (c)",
                                ['factor', 'f', 'numeric', 'n', 'character', 'c'], 'factor')
    type_name = get_proper_name(type_name)
    if type_name == 'factor':
        type_type = ask_about_value("Should the column levels be [numeric] (n) or character (c)? Labels of values "
                                    "will be assigned anyway", ['numeric', 'n', 'character', 'c'], 'numeric')
        type_type = get_proper_name(type_type)
    elif type_name == 'character':
        type_type = 'character'
    else:
        type_type = 'numeric'
    return type_name, type_type


def cell_type_col(uni):
    config = {
        'name': 'Published cell type',
        'data_type_type': 'character',
        'data_type_name': 'factor',
        'entity_type': 'generic_entity',
        'factor_levels': [{'value': '{}{}'.format(str(el)[0].upper(), str(el)[1:]),
                           'label': '{}{}'.format(str(el)[0].upper(), str(el)[1:])} for el in uni]
    }
    levels = {
        el: '{}{}'.format(str(el)[0].upper(), str(el)[1:]) for el in uni
    }
    return config, levels


def tissue_col(uni):
    config = {
        'name': 'Tissue',
        'data_type_type': 'character',
        'data_type_name': 'factor',
        'entity_type': 'generic_entity',
        'factor_levels': [{'value': '{}{}'.format(str(el)[0].upper(), str(el)[1:]),
                           'label': '{}{}'.format(str(el)[0].upper(), str(el)[1:])} for el in uni]
    }
    levels = {
        el: '{}{}'.format(str(el)[0].upper(), str(el)[1:]) for el in uni
    }
    return config, levels


def patient_col(uni):
    config = {
        'name': 'Patient Identifier',
        'data_type_type': 'character',
        'data_type_name': 'factor',
        'entity_type': 'generic_entity',
        'factor_levels': [{'value': el, 'label': el} for el in uni]
    }
    return config


def sample_col(uni):
    config = {
        'name': 'Sample',
        'data_type_type': 'character',
        'data_type_name': 'factor',
        'entity_type': 'generic_entity',
        'factor_levels': [{'value': el, 'label': el} for el in uni]
    }
    return config


def cluster_col(uni):
    config = {
        'name': 'Published cluster',
        'data_type_type': 'numeric',
        'data_type_name': 'factor',
        'entity_type': 'generic_entity',
        'factor_levels': [{'value': i,
                           'label': el} for i, el in enumerate(uni)]
    }
    levels = {
        el: i for i, el in enumerate(uni)
    }
    return config, levels


def phenotype_clinical(config):
    config['entity_type'] = 'phenotype'
    config['phenotype_info'] = {'domain': 'Clinical'}
    return config


def phenotype_pathology(config):
    config['entity_type'] = 'phenotype'
    config['phenotype_info'] = {'domain': 'Pathology'}
    return config


def age_column(uni, col, meta):
    if all([isfloat(str(el)) for el in uni]):
        if len(uni) < 50:
            type_name = ask_about_value('There is {} unique numeric values in this column. Should it be [factor] (f) '
                                        'or numeric (n)?'.format(len(uni)), ['factor', 'f', 'numeric', 'n'], 'factor')
            type_name = get_proper_name(type_name.lower())
        else:
            type_name = 'numeric'
    else:
        type_name = 'factor'
    if type_name == 'numeric':
        suffix = add_suffix()
        levels = None
        col_rewrite = {}
    elif type_name == 'factor':
        suffix = add_suffix()
        new_meta = meta.copy()
        if suffix is not None and all([suffix in el for el in uni]):
            labels = {el: el.strip(suffix) for el in uni}
            new_uni = [labels[el] for el in uni]
            new_meta[col].replace(labels, inplace=True)
        else:
            labels = {}
            new_uni = uni
        col_rewrite, levels = change_order_labels(new_uni, col, new_meta, 'numeric')
        if labels:
            revert_labels = {la: el for el, la in labels}
            col_rewrite = {revert_labels[el]: la for el, la in col_rewrite.items()}
    col_json = {
        'name': 'Age',
        'data_type_name': type_name,
        'data_type_type': 'numeric',
    }
    if suffix is not None:
        col_json['label_suffix'] = suffix
    if levels is not None:
        col_json['factor_levels'] = levels
    col_json = phenotype_clinical(col_json)
    return col_json, col_rewrite


def disease_column(uni, col, meta, new_cols, subtypes_col=False):
    col_json = {
        'data_type_name': 'factor',
        'data_type_type': 'numeric',
        'entity_type': 'health_condition'
    }
    if not subtypes_col:
        normal = ask_about_value('How control/normal value is named in this column? (if there is any)')
        levels = [{'value': 0, 'label': 'Healthy Control'}]
    else:
        normal = ''
        col_json['measurement'] = {'type': 'Subtypes'}
        name = ask_about_value('Give name of the entity disease')
        levels = []
    col_rewrite = {}
    if normal:
        col_rewrite[normal] = 0
        num_diseases = len(uni) - 1
    else:
        num_diseases = len(uni)
    if num_diseases > 1:
        new_uni, new_labels = [], {}
        if not subtypes_col:
            name = 'Disease'
        for i, subtype in enumerate([el for el in uni if el != normal]):
            print('Disease subtype named: {}'.format(subtype))
            default = 'keep original'
            if not subtypes_col:
                disease_name = ask_about_value('Give name of the entity disease (or [keep original])', default=default)
                if disease_name == default:
                    disease_name = subtype
                new_cols[subtype] = {
                    'values': [0 if el == normal else 1 if el == subtype else np.nan for el in
                               meta[col].values.flatten()],
                    'json': {
                        'name': disease_name,
                        'data_type_name': 'factor',
                        'data_type_type': 'numeric',
                        'factor_levels': [
                            {'value': 0, 'label': 'Healthy Control'},
                            {'value': 1, 'label': disease_name}
                        ],
                        'entity_type': 'health_condition'
                    }
                }
            else:
                disease_name = ask_about_value('Give name of the disease subtype (or [keep original])', default=default)
            if disease_name == default:
                disease_name = subtype
            new_labels[subtype] = disease_name
            new_uni.append(disease_name)
        new_uni = natsorted(new_uni)
        _, levels = change_order_labels(new_uni, col, meta[[col]].replace(new_labels), col_json['data_type_type'],
                                        change_order=True)
        new_labels_revert = {la: el for el, la in new_labels.items()}
        if not normal:
            levels = [{'value': el['value'] + 1, 'label': el['label']} for el in levels]
        col_rewrite = {**col_rewrite, **{new_labels_revert[el['label']]: el['value'] for el in levels}}
    else:
        disease = [el for el in uni if el != normal][0]
        name = ask_about_value('Give name of the entity disease')
        levels += [{'value': 1, 'label': name}]
        col_rewrite[disease] = 1
    col_json['name'] = name
    col_json['factor_levels'] = levels
    col_json = add_suffix(col_json, disease=True)
    return col_json, col_rewrite, new_cols


def treatment_column(uni, col, meta):
    ask_again = True
    while ask_again:
        treatment_type = ask_about_value(
            'Select treatment type: [drug] / drug resistance (resist) / CRISPRi / RNAi / intervention / response '
            '/ environmental condition exposure (env)',
            ['drug', 'drug resistance', 'resistance', 'resist', 'CRISPRi', 'crispri', 'RNAi', 'rnai', 'intervention',
             'response', 'environmental condition exposure', 'env'],
            'drug')
        if treatment_type in ['drug resistance', 'resistance', 'resist'] and len(uni) > 2:
            print('Drug resistance column must take not more than 2 unique values (corresponding '
                  'to presence and lack of resistance).')
            ask_again = yes_no('Do you want to change treatment type?', default_yes=False)
        else:
            ask_again = False

    col_json = {
        'data_type_name': 'factor',
        'data_type_type': 'numeric'
    }

    def add_info(col_json, suffix):
        add_info = yes_no('Do you want to add treatment information?', default_yes=False)
        attrs = {}
        while add_info:
            info_key = ask_about_value('Give name of the attribute (e.g. time, dose)')
            info_val = ask_about_value('Give value of the attribute (e.g. 8h, 4 weeks, 25 mg/kg)')
            print('You defined the attribute "{}: {}"'.format(info_key, info_val))
            accept_info = yes_no('Do you accept it?')
            if accept_info:
                attrs[info_key] = info_val
            add_info = yes_no('Do you want to add another attribute?', default_yes=False)
        if attrs:
            col_json['measurement']['attrs'] = {col_json['measurement']['type']: attrs}
            suffix = '{}, {}'.format(suffix, ', '.join(attrs.values()))
        return col_json, suffix

    col_rewrite, levels = {}, []
    user_rewrite = True
    if treatment_type.lower() in ['drug', 'crispri', 'rnai']:
        col_json['measurement'] = {'type': 'drug_treatment'}
        suffix = 'Treatment'
        if treatment_type == 'drug':
            old_control = ask_about_value('Which label corresponds to a control group? (if there is any)', uni)
            new_labels, new_uni = {}, []
            if old_control and old_control in uni:
                default = 'keep original'
                new_control = ask_about_value('Give new label of the control group (or [keep original])',
                                              default=default)
                if new_control == default:
                    new_control = old_control
                treated = [el for el in uni if el != old_control]
                new_labels[old_control] = new_control
                new_uni.append(new_control)
            else:
                treated = uni
            col_json['name'] = ask_about_value('Give main drug name (column name)').upper()
            for el in treated:
                if len(treated) > 1:
                    print('Original value: "{}"'.format(el))
                    ask = 'Give new label of this value (or [keep original])'
                    default = 'keep original'
                else:
                    ask = 'Give new label indicating the drug use (or [use drug name])'
                    default = 'use drug name'
                drug_name = ask_about_value(ask, default=default)
                if drug_name == default:
                    if default == 'keep original':
                        drug_name = el
                    else:
                        drug_name = col_json['name']
                new_labels[el] = drug_name
                new_uni.append(drug_name)
            col_json['entity_type'] = 'drug'
            _, levels = change_order_labels(new_uni, col, meta[[col]].replace(new_labels),
                                            col_json['data_type_type'], change_order=True)
            col_json['factor_levels'] = levels
            new_labels_revert = {la: el for el, la in new_labels.items()}
            col_rewrite = {new_labels_revert[el['label']]: el['value'] for el in levels}
            col_json, suffix = add_info(col_json, suffix)
            user_rewrite = False

        if treatment_type.lower() == 'crispri':
            col_json['name'] = ask_about_value('Give CRISPRi name')
            col_json['entity_type'] = 'CRISPRi'
        if treatment_type.lower() == 'rnai':
            col_json['name'] = ask_about_value('Give RNAi name')
            col_json['entity_type'] = 'RNAi'

    elif treatment_type == 'intervention':
        col_json['name'] = ask_about_value('Give intervention name')
        col_json['entity_type'] = 'intervention'
        col_json['measurement'] = {'type': 'intervention_treatment'}
        col_json, suffix = add_info(col_json, 'Treatment')

    elif treatment_type in ['environmental condition exposure', 'env']:
        col_json['name'] = ask_about_value('Give environmental condition name')
        col_json['entity_type'] = 'environmental_condition'
        col_json['measurement'] = {'type': 'environmental_condition_exposure'}
        col_json, suffix = add_info(col_json, 'Exposure')

    elif treatment_type == 'response':
        drug_or_int = ask_about_value('This column is concerned with [drug] (d) or intervention (i) response?',
                                      ['drug', 'd', 'intervention', 'i'], 'drug')
        if drug_or_int.lower() in ['drug', 'd']:
            col_json['name'] = ask_about_value('Give drug name').upper()
            col_json['entity_type'] = 'drug'
            col_json['measurement'] = {'type': 'drug_response'}
        else:
            col_json['name'] = ask_about_value('Give intervention name')
            col_json['entity_type'] = 'intervention'
            col_json['measurement'] = {'type': 'intervention_response'}
        ask_again = True
        while ask_again:
            response_type = ask_about_value('The response is numeric (n) or categorical (c)?',
                                            ['numeric', 'n', 'categorical', 'c'])
            response_type = get_proper_name(response_type.lower())
            if response_type == 'numeric' and not all([isfloat(el) for el in uni]):
                print('Not all values in column "{}" are numeric: {}. Please change response type.'.format(col, uni))
            else:
                ask_again = False
        suffix = 'Response'
        if response_type == 'numeric':
            col_json['data_type_name'] = 'numeric'
            possible_types = ['minus_auc', 'auc', 'activity_area', 'minus_log_gi50', 'minus_gi50', 'minus_log_ic50',
                              'minus_ic50', 'minus_ATARiS_score', 'minus_DEMETER_score', 'minus_CERES_score']
            user_rewrite = False
        else:
            possible_types = ['binary', 'best_overall']
            possible_vals = ['Progressive disease', 'PD', 'Stable disease', 'SD', 'Partial response', 'PR',
                             'Complete response', 'CR']
        ask_again = True
        while ask_again:
            response_subtype = ask_about_value('Select response type (possible values are: {})'.
                                               format(', '.join(possible_types)), possible_types)
            if response_subtype == 'best_overall' and not all([el.lower() in possible_vals for el in uni]):
                print('Response of type "best overall" must take only given values: {}'.
                      format(', '.join(possible_vals)))
                ask_again = yes_no('Do you want to change response type?', default_yes=False)
            elif response_subtype == 'binary' and len(uni) > 2:
                print('Response of type "binary" must take not more than 2 unique values (corresponding '
                      'to presence and lack of response).')
                ask_again = yes_no('Do you want to change response type?', default_yes=False)
            else:
                ask_again = False
        col_json['measurement']['attrs'] = {col_json['measurement']['type']: {'type': response_subtype}}
        if response_subtype == 'best_overall':
            col_rewrite, levels = {}, []
            if not all([el.lower() in possible_vals for el in uni]) or len(uni) > 4:
                ask = True
            else:
                ask = False
            possible_vals_mapping = {
                el: i for i, el in enumerate([el for el in possible_vals if len(el) > 2])
            }
            for el in uni:
                if ask:
                    val = ask_about_value('What response does the value "{}" correspond to (select one of {})?'.
                                          format(el, possible_vals), possible_vals)
                else:
                    val = el
                if val:
                    new_val = possible_vals_mapping[val]
                    levels.append({'value': new_val, 'label': val})
                else:
                    new_val = np.nan
                col_rewrite[val] = new_val
            col_json['factor_levels'] = levels
            user_rewrite = False
        elif response_subtype == 'binary':
            for i, val in enumerate(['No Response', 'Response']):
                if val in uni:
                    org_val = val
                else:
                    org_val = ask_about_value('What label in the column corresponds to "{}"?'.format(val), uni)
                if org_val:
                    col_rewrite[org_val] = i
                    levels.append({'value': i, 'label': val})
            col_json['factor_levels'] = levels
            user_rewrite = False

    elif treatment_type in ['drug resistance', 'resistance', 'resist']:
        col_json['name'] = ask_about_value('Give drug name').upper()
        col_json['entity_type'] = 'drug'
        col_json['measurement'] = {'type': 'drug_resistance',
                                   'attrs': {'drug_resistance': {'type': 'binary'}}}
        suffix = 'Resistance'

        for i, val in enumerate(['Non-Resistant', 'Resistant']):
            if val in uni:
                org_val = val
            else:
                org_val = ask_about_value('What label in the column corresponds to "{}"?'.format(val), uni)
            if org_val:
                col_rewrite[org_val] = i
                levels.append({'value': i, 'label': val})
        user_rewrite = False
        col_json['factor_levels'] = levels

    else:
        raise Exception('Wrong type of treatment')

    add_suffix(col_json, suffix)

    if user_rewrite:
        col_rewrite, col_json['factor_levels'] = change_order_labels(uni, col, meta, col_json['data_type_type'])

    return col_json, col_rewrite


def get_str_value_counts(meta, col, uni=None, num_rows=None, only_not_one=False):
    if num_rows is not None:
        num_rows = meta.shape[0]
    meta_value_counts = meta[col].astype(str).value_counts()
    if uni is None:
        uni = [str(el) for el in meta[col].dropna().unique()]
        uni = natsorted(uni)
    if only_not_one:
        uni = [el for el in uni if meta_value_counts[el] > 1]
    str_value_counts = []
    for val in uni[:10]:
        str_value_counts.append('"{}" ({:.2f}% of rows)'.format(val, meta_value_counts[val] / num_rows * 100))
    result_str = ', '.join(str_value_counts)
    if len(uni) > 10:
        result_str += '...'
    return result_str


def process_column(meta, col, num_rows):
    uni = list(meta[col].dropna().unique())
    uni = natsorted(uni)
    remove, reason = False, ''
    column_str = get_str_value_counts(meta, col, uni=uni, num_rows=num_rows)
    if len(uni) == 0:
        remove = yes_no('Column "{}" is full of NaNs. Do you want to skip this column?'.format(col))
        reason = 'Only NaNs'
    elif len(uni) == 1:
        remove = yes_no('Column "{}" has only 1 not-NaN unique value: {}. Do you want to skip this column?'
                        .format(col, get_str_value_counts(meta, col, num_rows=num_rows)))
        reason = 'Only 1 not-NaN unique value: "{}"'.format(uni[0])
    elif len(uni) < num_rows:
        print('Column "{}", has {} unique values: {}'.format(col, len(uni), column_str))
    else:
        remove = yes_no('Column "{}" has unique value for each row ({}/{} NaNs): {}. Do you want to skip this column?'.
                        format(col, sum(np.array(meta[col].values) == np.nan), num_rows, column_str))
        reason = 'Unique value for each row'
    if remove:
        general = 'skip'
    else:
        possible_groups = ['Cell type', 'Cell line', 'Cell ID', 'Barcode', 'Tissue', 'Patient ID', 'Individual ID',
                           'Race', 'Sex', 'Age', 'Disease', 'Disease subtype', 'Cluster', 'Sample', 'Treatment',
                           'Genotype', 'INDEX', 'SKIP', '[OTHER]']
        general = ask_about_value('Select column type:\n{}\n'.format(
            '\n'.join(['({}) {}'.format(i+1, el) for i, el in enumerate(possible_groups)])),
            possible_groups + ['OTHER'] + [str(i) for i in range(1, len(possible_groups)+1)])
        if general.isnumeric():
            general = possible_groups[int(general)-1].lower()
        else:
            general = general.lower()
        if general == 'skip':
            reason = 'Skipped manually'
    col_rewrite, col_json, new_cols, skip_cols = {}, {}, {}, {}
    suffix, levels = None, None
    if general == 'cell type':
        name = 'Published cell type'
        type_name = 'factor'
        type_type = 'character'
        group = 'cell_type'
        general = 'Cell Type'
    elif general == 'cell line':
        name = 'Cell line'
        type_name = 'factor'
        type_type = 'character'
        group = 'cell_line'
    elif general == 'tissue':
        name = 'Tissue'
        type_name = 'factor'
        type_type = 'character'
        group = 'cell_type'
        general = 'Tissue'
    elif general == 'cell id':
        name = 'Cell Identifier'
        type_name = 'character'
        type_type = 'character'
        group = 'generic'
    elif general == 'barcode':
        name = 'Barcode'
        type_name = 'character'
        type_type = 'character'
        group = 'generic'
    elif general == 'patient id':
        name = 'Patient Identifier'
        type_name = 'factor'
        type_type = 'character'
        group = 'generic'
    elif general == 'individual id':
        name = 'Individual Identifier'
        type_name = 'factor'
        type_type = 'character'
        group = 'generic'
    elif general == 'race':
        name = 'Race'
        type_name = 'factor'
        type_type = 'numeric'
        group = 'clinical'
    elif general == 'cluster':
        name = 'Published cluster'
        type_name = 'factor'
        type_type = 'numeric'
        group = 'generic'
    elif general == 'sample':
        name = 'Sample'
        type_name = 'factor'
        type_type = 'character'
        group = 'generic'
    elif general == 'genotype':
        name = ask_about_value('Give name of this column')
        type_name = 'factor'
        type_type = 'numeric'
        suffix = ask_about_value('Give measurement suffix (e.g. Fusion, Mutation, Presence)')
        group = 'generic'
    elif general == 'sex':
        col_json = phenotype_clinical({
            'name': 'Sex',
            'data_type_name': 'factor',
            'data_type_type': 'character',
            'factor_levels': [{'value': 'M', 'label': 'Male'},
                              {'value': 'F', 'label': 'Female'}]
        })
        if any([el.lower() in ['m', 'male'] for el in uni]):
            male_rewrite = {
                el: 'M' for el in [la for la in uni if la.lower() in ['m', 'male']]
            }
        else:
            val = ask_about_value('Give label of "Male" from the input metadata (if there is any)')
            if val:
                male_rewrite = {val: 'M'}
            else:
                male_rewrite = {}
        if any([el.lower() in ['f', 'female'] for el in uni]):
            female_rewrite = {
                el: 'F' for el in [la for la in uni if la.lower() in ['f', 'female']]
            }
        else:
            val = ask_about_value('Give label of "Female" from the input metadata (if there is any)')
            if val:
                female_rewrite = {val: 'F'}
            else:
                female_rewrite = {}
        col_rewrite = {**male_rewrite, **female_rewrite}
        return col_json, col_rewrite, new_cols, skip_cols
    elif general == 'age':
        col_json, col_rewrite = age_column(uni, col, meta)
        return col_json, col_rewrite, new_cols, skip_cols
    elif general == 'disease':
        col_json, col_rewrite, new_cols = disease_column(uni, col, meta, new_cols)
        return col_json, col_rewrite, new_cols, skip_cols
    elif general == 'disease subtype':
        col_json, col_rewrite, new_cols = disease_column(uni, col, meta, new_cols, subtypes_col=True)
        return col_json, col_rewrite, new_cols, skip_cols
    elif general == 'treatment':
        col_json, col_rewrite = treatment_column(uni, col, meta)
        return col_json, col_rewrite, new_cols, skip_cols
    elif general == 'index':
        skip_cols[col] = 'index'
        return col_json, col_rewrite, new_cols, skip_cols
    elif general == 'skip':
        skip_cols[col] = reason
        return col_json, col_rewrite, new_cols, skip_cols
    else:
        group = ask_about_value('Select group of this column: clinical (c) / pathology (p) / [generic] (g)',
                                ['clinical', 'c', 'pathology', 'p', 'generic', 'g'], 'generic')
        default = 'keep original'
        name = ask_about_value('Give name of this column (or [keep original])', default=default)
        if name == default:
            name = col
        type_name, type_type = get_type_name()
    col_json = {
        'name': name,
        'data_type_name': type_name,
        'data_type_type': type_type,
    }
    if suffix is not None:
        col_json["measurement"] = {"label_suffix": suffix}
    if levels is not None:
        col_json['factor_levels'] = levels

    if type_name == 'factor':
        col_rewrite, col_json['factor_levels'] = change_order_labels(uni, col, meta, col_json['data_type_type'])
    elif type_name == 'numeric':
        assert all([isfloat(str(el)) for el in uni if str(el).lower() not in IDK]), \
            'Not all values in "{}" column are numeric'.format(col)
    if group.lower() in ['generic', 'g']:
        col_json["entity_type"] = "generic_entity"
    elif group.lower() in ['clinical', 'c']:
        col_json = phenotype_clinical(col_json)
    elif group.lower() in ['pathology', 'p']:
        col_json = phenotype_pathology(col_json)
    elif group == 'cell_type':
        col_json["entity_type"] = 'cell_type'
        col_json["cell_type_info"] = {"domain": general}
    elif group == 'cell_line':
        col_json["entity_type"] = 'cell_line'
    else:
        raise Exception('WRONG name of the group: {}'.format(group))
    return col_json, col_rewrite, new_cols, skip_cols


def run(infile, outdir=None):
    meta = pd.read_csv(infile, sep='\t')
    print('\nMetadata loaded from {}'.format(infile))
    meta = meta.apply(lambda col: [str(el) if str(el).lower() not in IDK else np.nan for el in col])
    num_rows = meta.shape[0]
    first_column = meta.columns[0]
    set_index, save_with_index = False, True
    first_unique = meta[first_column].dropna().unique()
    if len(first_unique) == meta.shape[0]:
        set_index = True
    else:
        num_repeated = sum(meta[first_column].dropna().value_counts() > 1)
        num_nans = sum(meta[first_column].isna())
        print('WARNING: first column of a metadata should contains cells IDs or barcodes. '
              'In a given file first column "{}" contains {} repeated value(s): {}'.
              format(first_column, num_repeated, get_str_value_counts(meta, first_column, num_rows=num_rows,
                                                                      only_not_one=True)))
        if num_nans > 0:
            w = ask_about_value('Do you want to treat this column as metadata (m) or [exit] (e)? It cannot be set as '
                                'index because contains {} NaN value(s).'.format(num_nans),
                                ['metadata', 'm', 'exit', 'e'], 'exit')
        else:
            w = ask_about_value('Do you want to set this column as table index (i), treat it as metadata (m) or '
                                '[exit] (e)?', ['index', 'i', 'metadata', 'm', 'exit', 'e'], 'exit')
        if w in ['index', 'i']:
            set_index = True
        elif w in ['metadata', 'm']:
            save_with_index = False
        else:
            sys.exit()
    if set_index:
        meta = meta.set_index(first_column)
        meta.rename_axis(None, axis=0, inplace=True)
        print('Column "{}" has been set as metadata index'.format(first_column))
    indir, dataset_id = os.path.split(infile)
    dataset_id = dataset_id.replace('_metadata', '').replace('.tsv', '')
    print('Dataset ID derived from file name: "{}"'.format(dataset_id))

    columns_to_add = {}
    columns_to_skip = {}
    columns_jsons = {}
    columns_rewrite = {}
    set_as_index = None
    print('Input dataset has {} columns: {}\n'.format(meta.shape[1], list(meta.columns)))
    for i, col in enumerate(meta.columns):
        print('{} column: "{}"'.format(i+1, col))
        columns_jsons[col], columns_rewrite[col], new_cols, skip_cols = process_column(meta, col, num_rows)
        for new_col, val in new_cols.items():
            columns_to_add[new_col] = val['values']
            columns_jsons[new_col] = val['json']
        if col in skip_cols and skip_cols[col] == 'index':
            del skip_cols[col]
            del columns_jsons[col]
            set_as_index = col
            print('Column "{}" has been set as metadata index\n'.format(col))
        elif col not in skip_cols:
            print('Column "{}" has been proceeded. It was renamed to "{}" and defined as {} - {}.\n'.
                  format(col, columns_jsons[col]['name'], columns_jsons[col]['data_type_name'],
                         columns_jsons[col]['data_type_type']))
        else:
            del columns_jsons[col]
            print('Column "{}" has been skipped.\n'.format(col))
        columns_to_skip = {**columns_to_skip, **skip_cols}

    if set_as_index is not None:
        meta = meta.set_index(set_as_index)
        meta.rename_axis(None, axis=0, inplace=True)
        save_with_index = True

    if not columns_jsons and columns_to_skip:
        print('No columns left in the metadata. Choose which column save to avoid empty metadata file.')
        col = ask_about_value('Which column should be kept', list(columns_to_skip.keys()))
        columns_jsons[col], columns_rewrite[col], new_cols, skip_cols = process_column(meta, col, num_rows)
        del columns_to_skip[col]

    if outdir is None:
        outdir = indir
    desc_file = os.path.join(outdir, '{}_skipped.txt'.format(dataset_id))
    with open(desc_file, 'w') as f:
        f.write('\n'.join(['{}\t{}'.format(el, la) for el, la in columns_to_skip.items()]))
    print('Names of skipped columns saved to {}'.format(desc_file))

    meta = pd.concat([meta, pd.DataFrame(columns_to_add, index=meta.index)], axis=1)
    meta.drop(list(columns_to_skip.keys()), axis=1, inplace=True)
    meta.replace(IDK, np.nan, inplace=True)
    for col, to_replace in columns_rewrite.items():
        if to_replace:
            print('Replacing values in "{}" column: {} -> {}'.
                  format(col, list(to_replace.keys()), list(to_replace.values())))
            meta[col] = meta[col].astype(str).replace(to_replace)
    if dataset_id == 'metadata':
        new_meta_file = os.path.join(outdir, 'metadata_changed.tsv')
    else:
        new_meta_file = os.path.join(outdir, '{}_metadata_changed.tsv'.format(dataset_id))
    meta.to_csv(new_meta_file, index=save_with_index, sep='\t')
    print('New metadata file saved to {}'.format(new_meta_file))

    yaml_file = os.path.join(outdir, '{}.yaml'.format(dataset_id))
    with open(yaml_file, 'w') as f:
        json.dump(columns_jsons, f, indent=2)
    print('Yaml file written to ', yaml_file)
    return columns_jsons
