import json
import sys
import copy
import pandas as pd

from bi_import_utils import ontology
from bi_import_utils import commons
from bi_import_utils import modified_protein_abundance

'''
Format a tab-separated data matrix with gene expression statistics as BI data table.

Note: gene names should correspond to HGNC gene names.

Copyright 2017 Data4Cure, Inc. All rights reserved.
'''

_col_domain = 'Gene Expression Statistics'  # Expose as parameter if becomes useful


def read(input_tsv, verbose=False):
    """Read tab-separated file with gene-level statistics.
    
    Parameters
    ----------
    input_tsv : str
        Path to input file containing gene-level statistics. Rows should correspond to genes and
        columns should correspond to statistics.
    verbose : bool, optional
        If True, print logging information to stderr.
    
    Returns
    -------
    gene_stats : pandas.DataFrame
        Pandas dataframe containing gene-level statistics. Rows correspond to genes and columns
        correspond to statistics.
        
    """
    if verbose:
        sys.stderr.write('\nReading input from {}\n'.format(input_tsv))
    gene_stats = pd.read_csv(input_tsv, sep='\t', header=0, index_col=0, na_values='NA',
                             low_memory=False)
    return gene_stats


def process(gene_stats,
            use_ensembl=False,
            use_synonyms=True,
            modified_protein=False,
            map_to_human_orth=None,
            map_to_human_high_conf_only=False,
            duplicate_genes='best',
            duplicate_genes_p_value_column=None,
            verbose=False,
            map_to_human_orth_more=False,
            map_to_human_orth_all=False,
            ):
    """Process dataframe with gene-level statistics.
    
    Parameters
    ----------
    gene_stats : pandas.DataFrame
        Pandas dataframe containing gene-level statistics. Rows correspond to genes and columns
        correspond to statistics.
    use_ensembl : bool, optional
        If True, convert ENSEMBL ids (rows in the dataframe) to HGNC gene names.
    use_synonyms : bool, optional
        If True, try to match gene names in the dataframe to HGNC gene names using synonyms when
        possible.
    modified_protein : bool
        If True, rows correspond to gene-based modified proteins (e.g. `KRAS P:T33,T64`)
    duplicate_genes : str, optional
        Deduplication of duplicate genes, use one of best, first; default: best.
        When "best" is used, the most significant (lowest p-value) duplicated gene
        will be selected (see --duplicate-genes-p-value-column). When "first" is used,
        the first occurrence of a duplicated gene will be selected.
    duplicate_genes_p_value_column: str
        The label of the p-value column. Required when --duplicate-genes is set to best.
    map_to_human_orth : bool, optional
        Map from non-human to human genes using 1-to-1 orthology relationships.
    map_to_human_high_conf_only : bool, optional
        When converting from non-human to human genes using the 1-to-1  orthology
        relationships, use only the high-confidence subset.
    verbose : bool, optional
        If True, print logging information to stderr.
    map_to_human_orth_more : bool, optional
        If True, one2many and many2many orthology relationships where multiple human genes correspond
        to a mouse gene, will result in duplicating the data of said mouse gene into multiple
        (identical) columns in the output.
    map_to_human_orth_all : bool, optional
        If True, result in ignoring confidence (high-confidence / low-confidence) information
        when expanding data from a single mouse gene to multiple human genes, otherwise when both
        high- and low-confidence mappings exist for a given mouse gene, only the high-confidence subset will be used.
    
    Returns
    -------
    gene_stats : pandas.DataFrame
        Pandas dataframe containing gene-level statistics where gene names have been converted to
        HGNC or dropped if not known. Rows correspond to genes and columns correspond to statistics.
    dropped_elements: pandas.DataFrame
        Pandas dataframe containing dropped genes and a reason for it. Rows correspond to genes and
        columns to various information.
    """
    # Create deepcopy of input matrix to avoid changing input object
    if duplicate_genes not in ['first', 'best']:
        raise Exception('\nUnsupported duplicate genes selection. Use one of: first or best.\n')

    gene_stats = gene_stats.copy(deep=True)
    sys.stderr.write('\nData dimensions: {}\n'.format(gene_stats.shape))

    # prep, upper-case gene names
    if not map_to_human_orth:
        if modified_protein:
            # upper case only the prefix (up to space) of the rows as that is the gene name;
            # the suffix, if there, can have things like 'P:T33,T64' which we do not touch
            gene_stats.index = [commons.upper_case_prefix(x, sep=' ') for x in gene_stats.index]
        else:
            gene_stats.index = [c.upper() for c in gene_stats.index]

    # create new dataframe for storing duplicates, not translated ids, etc.
    dropped_elements = pd.DataFrame(index=gene_stats.index).assign(
        HGNC_symbol=gene_stats.index, description=None)

    # remove duplicates, if any
    gene_stats, dropped_elements = process_duplicates_genestats(
        gene_stats,
        duplicate_genes,
        dropped_elements=dropped_elements,
        pvalue_column=duplicate_genes_p_value_column,
        verbose=verbose)

    if verbose:
        sys.stderr.write('\nData dimensions after {} of duplicates: {}\n'.format(
            'removal' if duplicate_genes == 'first' else 'aggregation',
            gene_stats.shape,
        ))

    # converting ENSEMBL ids to HGNC gene names and remove duplicates
    if use_ensembl:
        gene_stats, dropped_elements = commons.translate_ensembl_ids_to_hgnc(
            gene_stats,
            dropped_elements,
            modified_protein=modified_protein,
            gene_prefix_sep=' ')

        if verbose:
            sys.stderr.write('\nData dimension after converting ENSEMBL ids to HGNC gene_names: {}\n'.format(
                gene_stats.shape))

    # mouse -> human genes orthology mapping
    if map_to_human_orth is not None:
        gene_stats, dropped_elements = commons.match_genes_to_human_orth_cols(
            gene_stats.T, # transpose to stats x genes format
            dropped_elements,
            map_to_human_orth,
            high_conf_orthology_only=map_to_human_high_conf_only,
            gene_prefix_sep=' ' if modified_protein else None,  # match only on part of feature name prior to space
            map_to_human_orth_more=map_to_human_orth_more,
            map_to_human_orth_all=map_to_human_orth_all,
        )

        # transpose to genes x stats format
        gene_stats = gene_stats.T

        # remove duplicates: if introduced by orthology mapping
        gene_stats, dropped_elements = process_duplicates_genestats(
            gene_stats,
            duplicate_genes,
            dropped_elements=dropped_elements,
            pvalue_column=duplicate_genes_p_value_column,
            verbose=verbose)

    # RR HERE

    # HGNC name filtering/matching
    if modified_protein:
        # specialized version
        gene_stats, drop = modified_protein_abundance._match_HGNC_names_cols(
            gene_stats,
            use_syn=use_ensembl or use_synonyms,
            use_rows=True,
        )
    else:
        # standard version
        gene_stats, drop = commons.match_HGNC_names_cols(
            gene_stats,
            use_syn=use_ensembl or use_synonyms,
            use_rows=True,
        )

    # annotate rows, which were translated to HGNC symbols, but didn't pass HGNC filtering
    mask_hgnc = dropped_elements.description.isnull() & dropped_elements.HGNC_symbol.isin(drop)
    dropped_elements.loc[mask_hgnc, 'description'] = 'HGNC conversion'

    # select rows, which were dropped
    dropped_elements = dropped_elements.loc[~dropped_elements.description.isnull(), :]
    if not use_ensembl:
        # drop column with HGNC symbols since it's a duplicate of an index
        dropped_elements.drop('HGNC_symbol', axis=1, inplace=True)

    return gene_stats, dropped_elements


def write(gene_stats, dropped_elements, output_tbl, modified_protein=False, no_save_dropped=False, verbose=False):
    """Write processed dataframe with gene-level statistics to BI tbl file.

    Parameters
    ----------
    gene_stats : pandas.DataFrame
        Pandas dataframe containing gene-level statistics that has been processed to conform to BI
        gene names. Rows correspond to genes and columns correspond to statistics.
    dropped_elements : pandas.DataFrame
        Pandas dataframe containing dropped genes and a reason for it. Rows correspond to genes and
        columns to various information.
    output_tbl: str
        Path to write tbl file to.
    no_save_dropped : bool, optional
        Skip saving dropped elements to additional file. (default = False)
    verbose : bool, optional
        If True, print logging information to stderr.
    """

    # format BI table
    def column_json(x):
        return commons.column_json_generic_numeric(x, _col_domain)

    def row_json_gene(x):
        return {
            'entity': {
                'name': x,
                'label': x,
                'domain': copy.deepcopy(ontology.HGNC_DOMAIN),
                'type': ontology.GENE_TYPE,
            },
            'label': x,
        }

    def row_json_modified_protein(x):
        d = commons.column_json_gene_modified_protein_abundance(x)
        return commons.without_data_type(d)

    # TODO: remove this
    # TODO: remove this
    # def column_json(x):
    #     return {
    #         'data_type': ontology.NUMERIC,
    #         'entity': {
    #             'name': x,
    #             'label': x,
    #             'type': ontology.GENERIC_ENTITY_TYPE,
    #             'domain': {'name': _col_domain},
    #         },
    #         'label': x,
    #     }
    # TODO: remove this
    # TODO: remove this

    row_json_func = row_json_gene
    if modified_protein:
        row_json_func = row_json_modified_protein

    gene_stats.index = [json.dumps(row_json_func(x), sort_keys=True) for x in gene_stats.index]
    gene_stats.columns = [json.dumps(column_json(x), sort_keys=True) for x in gene_stats.columns]

    # write BI table
    commons.write_df_as_tbl(gene_stats, output_tbl)
    if verbose:
        sys.stderr.write('\nWrote data table (.tbl) file to: {}\n'.format(output_tbl))

    # Save dropped and aggregated elements to files
    if not no_save_dropped and not dropped_elements.empty:
        commons.write_dropped_aggregated_as_tsv(dropped_elements, output_tbl)


def format_file(
        input_tsv,
        output_tbl,
        use_ensembl=False,
        use_synonyms=True,
        modified_protein=False,
        map_to_human_orth=None,
        map_to_human_high_conf_only=False,
        no_save_dropped=False,
        duplicate_genes='best',
        duplicate_genes_p_value_column=None,
        verbose=False,
        map_to_human_orth_more=False,
        map_to_human_orth_all=False,
):
    """Read file containing gene-level statistics and write as BI tbl file.

    Parameters
    ----------
    input_tsv : str
        Path to input file containing gene-level statistics.
    output_tbl: str
        Path to write tbl file to.
    use_ensembl : bool, optional
        If True, convert ENSEMBL ids (rows in the dataframe) to HGNC gene names.
    use_synonyms : bool, optional
        If True, try to match gene names in the dataframe to HGNC gene names using synonyms when
        possible.
    modified_protein : bool
        If True, rows correspond to gene-based modified proteins (e.g. `KRAS P:T33,T64`)
    map_to_human_orth : bool, optional
        Map from non-human to human genes using 1-to-1 orthology relationships.
    map_to_human_high_conf_only : bool, optional
        When converting from non-human to human genes using the 1-to-1  orthology
        relationships, use only the high-confidence subset.
    duplicate_genes : str, optional
        Deduplication of duplicate genes, use one of best, first; default: best.
        When "best" is used, the most significant (lowest p-value) duplicated gene
        will be selected (see --duplicate-genes-p-value-column). When "first" is used,
        the first occurrence of a duplicated gene will be selected.
    duplicate_genes_p_value_column: str
        The label of the p-value column. Required when --duplicate-genes is set to best.
    no_save_dropped : bool, optional
        Skip saving dropped elements to additional file. (default = False)
    verbose : bool, optional
        If True, print logging information to stderr.
    map_to_human_orth_more : bool, optional
        If True, one2many and many2many orthology relationships where multiple human genes correspond
        to a mouse gene, will result in duplicating the data of said mouse gene into multiple
        (identical) columns in the output.
    map_to_human_orth_all : bool, optional
        If True, result in ignoring confidence (high-confidence / low-confidence) information
        when expanding data from a single mouse gene to multiple human genes, otherwise when both
        high- and low-confidence mappings exist for a given mouse gene, only the high-confidence subset will be used.
    """
    gene_stats = read(input_tsv, verbose)
    gene_stats, dropped_elements = process(
        gene_stats,
        use_ensembl,
        use_synonyms,
        modified_protein,
        map_to_human_orth,
        map_to_human_high_conf_only,
        duplicate_genes,
        duplicate_genes_p_value_column,
        verbose,
        map_to_human_orth_more=map_to_human_orth_more,
        map_to_human_orth_all=map_to_human_orth_all,
    )
    write(gene_stats, dropped_elements, output_tbl, modified_protein, no_save_dropped, verbose)


def process_duplicates_genestats(df, duplicate_genes, dropped_elements=None, pvalue_column=None, verbose=True):
    # find row-wise duplicates and remove them
    duplicates_mask = df.index.duplicated()
    duplicates = df.loc[duplicates_mask, :].index
    if duplicates_mask.sum() > 0:
        if duplicate_genes == 'best':
            if pvalue_column is None:
                raise Exception('\nWhen --duplicate-genes is set to "best", p-value column must be specified '
                                '(see --duplicate-genes-p-value-column)\n')
            for gene in set(df.loc[duplicates_mask].index):
                # get best (=min p-value) for current duplicated values gene/feature
                updated_values = df.loc[gene][df.loc[gene][pvalue_column] == df.loc[gene][pvalue_column].min()]
                # update values
                df.loc[gene, updated_values.columns] = updated_values.iloc[0].values
        # remove duplicated rows, leave the first one with updated values
        df = df.loc[~duplicates_mask, :]

    if dropped_elements is not None and not dropped_elements.empty:
        dropped_mask = dropped_elements.HGNC_symbol.isin(duplicates) & \
                       dropped_elements.HGNC_symbol.duplicated() & \
                       dropped_elements.description.isnull()
        description = 'Duplicated' if duplicate_genes == 'first' else 'Aggregated'
        dropped_elements.loc[dropped_mask, 'description'] = description
        if verbose:
            sys.stderr.write('\n{} {} duplicated rows.\n'.format(
                'Removed' if duplicate_genes == 'first' else 'Aggregated',
                duplicates_mask.sum())
            )
    return df, dropped_elements
