import sys
import os
import json
import csv
import pandas as pd
import numpy as np
from os.path import join
from collections import defaultdict


def add_columns_from(df, df_add):
    print('add_columns_from::df: {}'.format(df.shape))
    print('add_columns_from::df_add: {}'.format(df_add.shape))

    df_index_orig = list(df.index)  # save original

    # translate to a shared index (needed if rows are not same type,
    # e.g. sample/clinical); then switch back to original before writing
    df_index_ids = [row_header_to_id(x) for x in df.index]
    df_add_index_ids = [row_header_to_id(x) for x in df_add.index]

    df.index = df_index_ids
    df_add.index = df_add_index_ids

    for c in df_add.columns:
        assert c not in df.columns
        # adds columns values for rows which are shared,
        # sets NAs to rows that are only in 'df'
        df.loc[:, c] = df_add[c]

    print('add_columns_from::added columns: {}'.format(df.shape))
    df.index = df_index_orig
    return df


def row_header_to_id(x):
    d = json.loads(x)
    return d['label']


def main(main_tbl, add_tbl, out_tbl):
    df = read_tbl_df(main_tbl)
    df_add = read_tbl_df(add_tbl)
    df = add_columns_from(df, df_add)
    write_tbl(df, out_tbl, read_tbl_header(main_tbl))


def read_tbl_df(fpath):
    return pd.read_csv(fpath, sep='\t', index_col=0, comment='#')


def read_tbl_header(fpath):
    with open(fpath, 'r') as f:
        header_line = next(f)
        if header_line.startswith('#'):
            return json.loads(header_line[1:])
    return None


def write_tbl(df, tbl_f, header_dict=None):
    na_rep = 'NA'
    with open(tbl_f, 'w') as f:
        if header_dict:
            f.write('#' + json.dumps(header_dict, sort_keys=True) + '\n')
        f.write('\t' + '\t'.join(df.columns) + '\n')
        df.to_csv(f, sep='\t', header=None, mode='a', na_rep=na_rep,
                  quoting=csv.QUOTE_NONE, quotechar='')


if __name__ == '__main__':
    if len(sys.argv) != 4:
        sys.exit('Usage: add_to_tbl.py <main.tbl> <add.tbl> <out.tbl>')

    main_tbl, add_tbl, out_tbl = sys.argv[1], sys.argv[2], sys.argv[3]
    main(main_tbl, add_tbl, out_tbl)
