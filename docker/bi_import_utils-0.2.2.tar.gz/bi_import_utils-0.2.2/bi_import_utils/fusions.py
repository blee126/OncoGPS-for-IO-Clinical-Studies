import os
import json
import sys

import pandas as pd
import numpy as np

from bi_import_utils import commons

'''
Format a tab-separated data matrix with gene fusion data as BI data table.

Copyright 2017 Data4Cure, Inc. All rights reserved.
'''


def read(input_tsv, transpose=False, verbose=False):
    """Read tab-separated file with gene fusion data.
    
    Parameters
    ----------
    input_tsv : str
        Path to input file containing gene fusion data. Rows correspond to samples and columns
        correspond to gene fusions. Columns names should be two genes connected with with two
        underscores (e.g.  BCR__ABL1).
    transpose : bool, optional
        Transpose matrix when reading; use if rows represent fusions and columns represent samples.
    verbose : bool, optional
        If True, print logging information to stderr.
    
    Returns
    -------
    df : pandas.DataFrame
        Pandas dataframe containing fusion data. Rows correspond to samples and columns correspond
        to fusions.
    """
    if verbose:
        sys.stderr.write('\nReading data file {}\n'.format(input_tsv))
    df = pd.read_csv(input_tsv, sep='\t', header=0, index_col=0,
                     na_values='NA', low_memory=False)
    if transpose:
        # reverse pandas mechanism to ensure column uniqueness and transpose matrix
        df = commons.remove_col_duplicates_pandas(df).T

    if verbose:
        sys.stderr.write('\nData dimensions: {}\n'.format(df.shape))

    return df


def process(fusion_data, use_ensembl=False, use_synonyms=True, duplicate_features='first',
            map_to_human_orth=False, map_to_human_high_conf_only=False,
            dont_reorder_items=False, verbose=True,
            #map_to_human_orth_more=False, map_to_human_orth_all=False
            ):
    """Process dataframe with fusion data. Convert gene names to HGNC and remove genes that are not
    in HGNC.
    
    Parameters
    ----------
    fusion_data : pandas.DataFrame
        Pandas dataframe containing fusion data. Rows correspond to samples and columns correspond
        to fusions.
    use_ensembl : bool, optional
        If True, convert ENSEMBL ids (cols in the dataframe) to HGNC gene names.
    use_synonyms : bool, optional
        If True, try to match gene names in the dataframe to HGNC gene names using synonyms when
        possible.
    map_to_human_orth : bool, optional
        Map from non-human to human genes using 1-to-1 orthology relationships.
    map_to_human_high_conf_only : bool, optional
        When converting from non-human to human genes using the 1-to-1  orthology
        relationships, use only the high-confidence subset.
    duplicate_features : str, optional
        Duplicate features selection. Default: first occurrence is kept.
        Other options are min and max value from duplicate features.
    dont_reorder_items : bool, optional
        Skip reordering / sorting fusion elements. such that separate items G1__G2, G2__G1 will
        be kept rather than merged into a single element G1__G2.
    verbose : bool, optional
        If True, print logging information to stderr.

    Returns
    -------
    fusion_data : pandas.DataFrame
        Pandas dataframe containing fusion data where gene names have been converted or dropped as
        needed.
    """
    # Create deepcopy of input matrix to avoid changing input object
    fusion_data = fusion_data.copy(deep=True)

    if duplicate_features not in ['first', 'min', 'max']:
        raise Exception('\nUnsupported duplicate features selection for binary data. Use one of: '
                        'first, min or max.\n'.format(duplicate_features))
    # reverse pandas mechanism to ensure uniqueness of column names
    fusion_data = commons.remove_col_duplicates_pandas(fusion_data)

    # ensure that samples are unique
    if not fusion_data.index.is_unique:
        raise Exception("\nError: duplicate sample IDs. Please make sure your input has unique sample identifiers.")

    # do not sort genes in fusions (G1__G2)
    if not dont_reorder_items:
        fusion_data.columns = ['__'.join(sorted(x.split('__'))) for x in fusion_data.columns]

    if not map_to_human_orth:
        # don't uppercase gene names in case of mouse genes
        fusion_data.columns = [fusion.upper() for fusion in fusion_data.columns]

    dropped_elements = pd.DataFrame(index=fusion_data.columns).assign(
        HGNC_symbol=fusion_data.columns, description=None)

    fusion_data, dropped_elements = commons.drop_duplicate_columns(
        fusion_data, dropped_elements, duplicate_genes=duplicate_features, verbose=True)

    # convert ENSEMBL ids to HGNC gene names
    if use_ensembl:
        fusion_data, dropped_elements = _ensembl_conversion(
            fusion_data, dropped_elements, verbose=True)

        # set HGNC_symbol as None, since it hasn't been converted
        dropped_elements.loc[~dropped_elements.description.isnull() & \
                             dropped_elements.description.str.match('ENSEMBL conversion'), 'HGNC_symbol'] = None

        # remove duplicates
        fusion_data, dropped_elements = commons.drop_duplicate_columns(
            fusion_data, dropped_elements, duplicate_genes=duplicate_features, verbose=True)

    # mouse human orthology mapping
    if map_to_human_orth is not None:
        fusion_data, dropped_elements = _map_to_human_orth_mapping(
            fusion_data, dropped_elements, map_to_human_orth, high_conf_orthology_only=map_to_human_high_conf_only,
            map_to_human_orth_more=False, map_to_human_orth_all=False
        )

        # do not sort genes in fusions (G1__G2)
        if not dont_reorder_items:
            fusion_data.columns = ['__'.join(sorted(x.split('__'))) for x in fusion_data.columns]

        # remove duplicates
        fusion_data, dropped_elements = commons.drop_duplicate_columns(
            fusion_data, dropped_elements, duplicate_genes=duplicate_features, verbose=True)

    # HGNC mapping
    fusion_data, dropped_elements = _hgnc_mapping(fusion_data, dropped_elements, use_synonyms=use_synonyms)

    fusion_data, dropped_elements = commons.drop_duplicate_columns(
        fusion_data, dropped_elements, duplicate_genes=duplicate_features, verbose=True)

    if verbose:
        sys.stderr.write('\nData dimensions: {}\n'.format(fusion_data.shape))

    # select rows, which were duplicated or weren't translated to HGNC symbols or didn't pass HGNC filtering (mask_hgnc)
    dropped_elements = dropped_elements.loc[~dropped_elements.description.isnull(), :]
    if not use_ensembl:
        # drop column with HGNC symbols since it's a duplicate of an index
        dropped_elements.drop('HGNC_symbol', axis=1, inplace=True)

    # notify user about number of dropped elements due to duplication reasons
    no_of_duplicated_elements = dropped_elements[dropped_elements.description == 'Duplicated'].shape[0]
    if duplicate_features == 'first' and no_of_duplicated_elements > 0:
        sys.stderr.write(('\nNumber of dropped features due to duplication: {}. Consider using '
                          '`duplicate_features` option to aggregate them.\n'.format(no_of_duplicated_elements)))

    return fusion_data, dropped_elements


def write(fusion_data, dropped_elements, samples_domain, output_tbl, no_save_dropped=False, verbose=False):
    """Write processed dataframe with gene fusion data to BI tbl file.
    
    Parameters
    ----------
    fusion_data : pandas.DataFrame
        Pandas dataframe containing fusion data that has been processed. Rows correspond to samples
        and columns correspond to fusions.
    dropped_elements: pandas.DataFrame
        Pandas dataframe containing dropped genes and a reason for it. Rows correspond to genes and
        columns to various information.
    samples_domain : str
        Domain of samples; e.g. your organization name.
    output_tbl: str
        Path to write tbl file to.
    no_save_dropped : bool, optional
        Skip saving dropped elements to additional file. (default = False)
    verbose : bool, optional
        If True, print logging information to stderr.
    """
    # Create deepcopy of input matrix to avoid changing input object
    fusion_data = fusion_data.copy(deep=True)
    # reformat row/column headers
    fusion_data.index = [json.dumps(commons.sample_row_json(x, samples_domain), sort_keys=True) for x in
                         fusion_data.index]
    fusion_data.columns = [json.dumps(commons.column_json_fusion(x), sort_keys=True) for x in fusion_data.columns]

    # write BI table
    commons.write_df_as_tbl(fusion_data, output_tbl)
    if verbose:
        sys.stderr.write('\nWrote data table (.tbl) file to: {}\n'.format(output_tbl))

    # Save dropped and aggregated elements to files
    if not no_save_dropped and not dropped_elements.empty:
        commons.write_dropped_aggregated_as_tsv(dropped_elements, output_tbl)


def format_file(
        input_tsv,
        samples_domain,
        output_tbl,
        use_ensembl=False,
        use_synonyms=True,
        map_to_human_orth=False,
        map_to_human_high_conf_only=False,
        transpose=False,
        no_save_dropped=False,
        duplicate_features='first',
        dont_reorder_items=False,
        verbose=True,
        # map_to_human_orth_more=False,
        # map_to_human_orth_all=False
):
    """Read file containing gene fusion data and write as BI tbl file.
    
    Parameters
    ----------
    input_tsv : str
        Path to input file containing fusion data. Rows correspond to samples and columns correspond
        to fusions.
    samples_domain : str
        Domain of samples; e.g. your organization name.
    output_tbl: str
        Path to write tbl file to.
    use_ensembl : bool, optional
        If True, convert ENSEMBL ids (cols in the dataframe) to HGNC gene names.
    use_synonyms : bool, optional
        If True, try to match gene names in the dataframe to HGNC gene names using synonyms when
        possible.
    no_hgnc_match : bool, optional
        Skip matching gene names to HGNC names.
    map_to_human_orth : bool, optional
        Map from non-human to human genes using 1-to-1 orthology relationships.
    map_to_human_high_conf_only : bool, optional
        When converting from non-human to human genes using the 1-to-1  orthology
        relationships, use only the high-confidence subset.
    transpose : bool, optional
        Transpose matrix when reading; use if rows represent fusions and columns represent samples.
    no_save_dropped : bool, optional
        Skip saving dropped elements to additional file. (default = False)
    duplicate_features : str, optional
        Duplicate features selection. Default: first occurrence is kept.
        Other options are min and max value from duplicate features.
    dont_reorder_items : bool, optional
        Skip reordering / sorting fusion elements. such that separate items G1__G2, G2__G1 will
        be kept rather than merged into a single element G1__G2.
    verbose : bool, optional
        If True, print logging information to stderr.
    """
    fusion_data = read(input_tsv, transpose, verbose)
    fusion_data, dropped_elements = process(
        fusion_data,
        use_ensembl=use_ensembl,
        use_synonyms=use_synonyms,
        map_to_human_orth=map_to_human_orth,
        map_to_human_high_conf_only=map_to_human_high_conf_only,
        duplicate_features=duplicate_features,
        dont_reorder_items=dont_reorder_items,
        verbose=verbose,
        # map_to_human_orth_more=map_to_human_orth_more,
        # map_to_human_orth_all=map_to_human_orth_all
    )
    write(fusion_data, dropped_elements, samples_domain, output_tbl, no_save_dropped, verbose)


def separate_genes(fusion_data):
    # split fusions (gene1__gene2 -> gene1, gene2)
    genes = np.array([fusion.split('__') for fusion in fusion_data.columns])
    return genes[:, 0], genes[:, 1]


def perform_mapping(fusion_data, dropped_elements, first_genes_converted, first_genes_converted_flag,
                    second_genes_converted, second_genes_converted_flag, info, verbose=True):
    # Keep gene fusion if
    # * both genes were converted, e.g. ALK__EML4
    # * one gene was converted and the other is N/A from the beginning (hasn't been converted)
    genes_to_keep = (first_genes_converted_flag & second_genes_converted_flag)
    fusion_data = fusion_data.loc[:, genes_to_keep].round(0)

    # new column names
    fusion_hgnc = ['{}__{}'.format(first_genes_converted[index], second_genes_converted[index]) \
                   for index, keep in enumerate(genes_to_keep) if keep]

    # annotate new changes to dropped elements matrix
    dropped_elements.loc[~dropped_elements.HGNC_symbol.isin(fusion_data.columns) & \
                         dropped_elements.description.isnull(), 'description'] = info
    dropped_elements.loc[dropped_elements.HGNC_symbol.isin(fusion_data.columns) & \
                         dropped_elements.description.isnull(), 'HGNC_symbol'] = fusion_hgnc
    fusion_data.columns = fusion_hgnc

    if verbose:
        sys.stderr.write('\nData dimensions after {}: {}\n'.format(info, fusion_data.shape))

    return fusion_data, dropped_elements


def _ensembl_mapping(gene_names):
    # Read tsv file with annotated ids and convert it to dict {ensembl_id: hgnc_gene_name}
    annotation_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'data',
                                   'ENSEMBL_mapping.txt.gz')
    annotation = pd.read_csv(annotation_path, sep='\t', index_col=1,
                             header=0, compression='gzip').to_dict()['Approved Symbol']

    converted_gene_names, converted_genes_flag = [], []
    for index, ensembl_id in enumerate(gene_names):
        # remove part after dot in ensembl ids and ensure it's upper case
        current_id = ensembl_id.split('.')[0].upper()

        # annotate id with hgnc gene names
        gene_name = annotation.get(current_id, None)
        # allow for user input N/A
        if not gene_name and current_id.upper() == 'N/A':
            gene_name = 'N/A'
        converted_genes_flag.append(gene_name is not None)
        converted_gene_names.append(gene_name)

    return converted_gene_names, converted_genes_flag


def _ensembl_conversion(fusion_data, dropped_elements, verbose=True):
    # split fusions
    first_genes, second_genes = separate_genes(fusion_data)

    # Ensembl mapping
    first_genes_converted, first_genes_converted_flag = _ensembl_mapping(first_genes)
    second_genes_converted, second_genes_converted_flag = _ensembl_mapping(second_genes)

    # convert list of TRUE/FALSE to pd.Series so we can use logical operators like & or |
    first_genes_converted_flag = pd.Series(first_genes_converted_flag, index=fusion_data.columns)
    second_genes_converted_flag = pd.Series(second_genes_converted_flag, index=fusion_data.columns)

    return perform_mapping(fusion_data, dropped_elements,
                           first_genes_converted, first_genes_converted_flag,
                           second_genes_converted, second_genes_converted_flag,
                           info='ENSEMBL conversion', verbose=verbose)


def _map_to_human_orth_mapping(fusion_data, dropped_elements, species, high_conf_orthology_only=False, verbose=True,
                              map_to_human_orth_more=False, map_to_human_orth_all=False):
    # split column names -> gene1__gene2
    first_genes, second_genes = separate_genes(fusion_data)

    # mouse human orthology mapping
    first_genes_converted, first_genes_converted_flag, _ = commons.convert_genes_to_human_orth(
        first_genes, species, high_conf_orthology_only=high_conf_orthology_only, map_to_human_orth_more=map_to_human_orth_more,
        map_to_human_orth_all=map_to_human_orth_all, accept_na=True)
    second_genes_converted, second_genes_converted_flag, _ = commons.convert_genes_to_human_orth(
        second_genes, species, high_conf_orthology_only=high_conf_orthology_only, map_to_human_orth_more=map_to_human_orth_more,
        map_to_human_orth_all=map_to_human_orth_all, accept_na=True)

    '''if first_to_duplicate or second_to_duplicate:
        duplicates = None
        new_cols_names = []
        duplicates_add_to_dropped = pd.DataFrame({'HGNC_symbol': [], 'description': []})
        for first, first_converted, second, second_converted in zip(
                first_genes,
                first_genes_converted,
                second_genes,
                second_genes_converted):
            if first_converted is None or second_converted is None:
                continue
            if first in first_to_duplicate and second not in second_to_duplicate:
                new_names = ['{}__{}'.format(el, second_converted) for el in first_to_duplicate[first]]
            elif first not in first_to_duplicate and second in second_to_duplicate:
                new_names = ['{}__{}'.format(first_converted, el) for el in second_to_duplicate[second]]
            elif first in first_to_duplicate and second in second_to_duplicate:
                new_names = []
                for f_gene in first_to_duplicate[first]:
                    new_names += ['{}__{}'.format(f_gene, el) for el in second_to_duplicate[second]]
            else:
                continue
            if len(new_names) > 1:  # first new column will replace the old column (not need of matrix extension)
                new_names = new_names[1:]
                new_cols_names += new_names
                new_cols = np.array(
                    [fusion_data['{}__{}'.format(first, second)].copy() for _ in new_names])
                duplicates_add_to_dropped = duplicates_add_to_dropped.append(pd.DataFrame({
                    'HGNC_symbol': new_names,
                    'description': [None for _ in new_names]},
                    index=['{}__{}'.format(first, second) for _ in new_names]))
                if duplicates is None:
                    duplicates = new_cols.copy()
                else:
                    duplicates = np.vstack((duplicates, new_cols))
        duplicates = pd.DataFrame(duplicates.T, index=fusion_data.index, columns=new_cols_names)
        fusion_data = pd.concat((fusion_data, duplicates), axis=1)
        dropped_elements = pd.concat((dropped_elements, duplicates_add_to_dropped), axis=0)
        new_first, new_second = map(list, zip(*[el.split('__') for el in new_cols_names]))
        first_genes = np.append(first_genes, new_first)
        first_genes_converted += new_first
        second_genes = np.append(second_genes, new_second)
        second_genes_converted += new_second
        sys.stderr.write(
                '\nMatrix extended by multi-mapped human orthologs: {} genes added\n'.format(duplicates.shape[1]))'''

    # Ensure converted genes are upper-cased and change nan values to None
    # Allow for user input NA values
    first_genes_converted = process_conversion(first_genes, first_genes_converted, fusion_data)
    second_genes_converted = process_conversion(second_genes, second_genes_converted, fusion_data)

    # Flags denoting, which genes have been mapped to our HGNC ontology
    first_genes_converted_flag = ~first_genes_converted.isnull().values
    second_genes_converted_flag = ~second_genes_converted.isnull().values

    return perform_mapping(fusion_data, dropped_elements, first_genes_converted, first_genes_converted_flag,
                           second_genes_converted, second_genes_converted_flag,
                           info='Orthology mapping', verbose=verbose)


def _hgnc_mapping(fusion_data, dropped_elements, use_synonyms=True, verbose=True):
    # split fusions
    first_genes, second_genes = separate_genes(fusion_data)

    # HGNC mapping
    first_genes_converted = commons.convert_to_HGNC_names(first_genes, use_syn=use_synonyms, verbose=verbose)
    second_genes_converted = commons.convert_to_HGNC_names(second_genes, use_syn=use_synonyms, verbose=verbose)

    # Ensure converted genes are upper-cased and change nan values to None
    # Allow for user input NA values
    first_genes_converted = process_conversion(first_genes, first_genes_converted, fusion_data)
    second_genes_converted = process_conversion(second_genes, second_genes_converted, fusion_data)

    # Flags denoting, which genes have been mapped to our HGNC ontology
    first_genes_converted_flag = ~first_genes_converted.isnull().values
    second_genes_converted_flag = ~second_genes_converted.isnull().values

    return perform_mapping(fusion_data, dropped_elements, first_genes_converted, first_genes_converted_flag,
                           second_genes_converted, second_genes_converted_flag,
                           info='HGNC conversion', verbose=verbose)


def process_conversion(genes_orig, genes_converted, fusion_data):
    # ensure that new gene name is upper-case and change nan to None
    genes_converted = pd.Series(genes_converted).where(pd.notnull(genes_converted), None).str.upper()
    output = []
    for gene_orig, gene_converted in zip(genes_orig, genes_converted):
        # genes was not converted, but it's user input - N/A
        if not gene_converted and gene_orig.upper() == 'N/A':
            output.append('N/A')
        else:
            output.append(gene_converted)
    return pd.Series(output, index=fusion_data.columns)

