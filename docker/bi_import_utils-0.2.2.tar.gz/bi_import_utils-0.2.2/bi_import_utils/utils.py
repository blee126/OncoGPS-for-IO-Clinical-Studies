#!/usr/bin/env
import sys
import argparse

from bi_import_utils import genes_to_hgnc

'''
Biomedical Intelligence utilities.

Copyright 2020 Data4Cure, Inc. All rights reserved.
'''


def main():
    use_ensembl_help = 'Convert ENSEMBL ids to HGNC gene names'
    use_synonyms_help = ('Match gene names on synonyms & translate back to the '
                         'HGNC name, where possible')
    map_to_human_help = ('Map non-human genes to human gene names using 1-to-1 '
                         'orthology relationships. Specify a species, one of: mouse, rat.')
    map_to_human_hconf_help = ('Of the 1-to-1 non-human to human orthology relationships, '
                               'use only the high-confidence subset')
    map_to_human_orth_more_help = ('If set, orthology relationships other than 1-to-1 (one->many, many->one, '
                                   'many->many) will be used: relationships where a single non-human gene is mapped '
                                   'to multiple human genes will results in duplicating the data associated with '
                                   'the non-human gene, relationships where multiple non-human genes are mapped to a '
                                   'single human gene will result in merging the data associated with the non-human '
                                   'genes (by default using mean, see --map-to-human-orth-more-duplicate-genes '
                                   'parameter). Note that by default, if a non-human gene has both high-and '
                                   'low-confidence human orthologues, only the high-confidence subset is used.')
    map_to_human_orth_all_help = ('The same as --map-to-human-orth-more, but additionally using low-confidence '
                                  'orthology relationships when both high- and low-confidence relationships exist.')

    # parent parser
    p = argparse.ArgumentParser(description=('Utilities.'))
    # sub-command parsers and options
    subparsers = p.add_subparsers(dest='application')

    ##### genes to HGNC conversion #####
    genes_to_hgnc_parser = subparsers.add_parser(
        'genes_to_hgnc', description=('Convert gene identifiers to HGNC symbol.'),
    )
    genes_to_hgnc_parser.add_argument('input_file', type=str,
                                      help='Input gene-list file (line/comma/space separated)')
    genes_to_hgnc_parser.add_argument('output_file', type=str, help='Output file with converted gene identifiers')
    genes_to_hgnc_parser.add_argument('--use-ensembl', action='store_true', default=False,
                                      help=use_ensembl_help)
    genes_to_hgnc_parser.add_argument('--use-synonyms', action='store_true', default=False,
                                      help=use_synonyms_help)
    genes_to_hgnc_parser.add_argument('--map-to-human-orth', type=str, default=None,
                                      help=map_to_human_help)
    genes_to_hgnc_parser.add_argument('--map-to-human-high-conf-only', action='store_true', default=False,
                                      help=map_to_human_hconf_help)
    genes_to_hgnc_parser.add_argument('--map-to-human-orth-more', action='store_true', default=False,
                                      help=map_to_human_orth_more_help)
    genes_to_hgnc_parser.add_argument('--map-to-human-orth-all', action='store_true', default=False,
                                      help=map_to_human_orth_all_help)

    # parse arguments
    args = p.parse_args()
    sys.stderr.write('\nApplication: {}\n'.format(args.application))

    if args.application == 'genes_to_hgnc':
        genes_to_hgnc.format_file(
            args.input_file,
            args.output_file,
            args.use_ensembl,
            args.use_synonyms,
            args.map_to_human_orth,
            args.map_to_human_high_conf_only,
            verbose=True,
            map_to_human_orth_more=args.map_to_human_orth_more,
            map_to_human_orth_all=args.map_to_human_orth_all
        )
    else:
        sys.stderr.write('\nUnknown application: {}\n'.format(args.application))


if __name__ == '__main__':
    main()
