import os
import sys
import csv
import gzip
import json
import re
import six
import copy
from collections import defaultdict, Counter
import pandas as pd
import numpy as np

from bi_import_utils import ontology

ensembl_annotation_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'data', 'ENSEMBL_mapping.txt.gz')


def check_orth_dict(species, m2h_d):
    """
    Check number of non-human genes connected to human genes,
    select only highly-confident subset of non-human genes if it is available.
    """

    path = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'data')
    if species == 'mouse':
        orth_f = os.path.join(path, 'human2mouse_hom_BioMart.tsv.gz')
        orth_conf_col = 'Mouse orthology confidence [0 low, 1 high]'
        orth_type_col = 'Mouse homology type'
        orth_type_col_d4c = 'Mouse homology type D4C'
        mm_gene_col = 'Mouse associated gene name'
        hs_gene_col = 'Associated Gene Name'
    elif species == 'rat':
        orth_f = os.path.join(path, 'human2rat_hom_BioMart.tsv.gz')
        orth_conf_col = 'Rat orthology confidence [0 low, 1 high]'
        orth_type_col = 'Rat homology type'
        orth_type_col_d4c = 'Rat homology type D4C'
        mm_gene_col = 'Rat gene name'
        hs_gene_col = 'Gene name'
    else:
        raise Exception('\nError: species (pass through "--mouse-to-human-orth") should be one of: mouse, rat.\n')
    hs_mm_orth = pd.read_csv(orth_f, sep='\t', index_col=0, header=0, compression='gzip')
    hs_mm_orth = hs_mm_orth.loc[:, [mm_gene_col, orth_type_col, orth_type_col_d4c, orth_conf_col, hs_gene_col]]

    hgenes_counter = Counter([la for el in m2h_d.values() for la in el])  # key: human gene, value: how many time it was assigned to some non-human gene
    for h_gene in [el for el, la in hgenes_counter.items() if la > 1]:
        m_genes = [(row[mm_gene_col], row[orth_conf_col])
                   for _, row in hs_mm_orth[hs_mm_orth[hs_gene_col] == h_gene].iterrows()
                   if row[mm_gene_col] in m2h_d and h_gene in m2h_d[row[mm_gene_col]]]
        len_m_genes = len(m_genes)
        m_genes = set(m_genes)
        '''if len_m_genes - len(m_genes) > 0:
            print('{} m_genes repeated for {}'.format(len_m_genes - len(m_genes), h_gene))'''
        if len(set([el[0] for el in m_genes])) < len(m_genes):
            # Case when one non-human gene is assigned twice to the same human gene with different confidence.
            # In such cases usually ENSEMBL IDs differ that's why it is not treated as an error
            c = Counter([el[0] for el in m_genes])
            dif_conf_m_genes = [el for el, la in c.items() if la > 1]
            '''print('\nWARNING: for h_gene {} these m_genes have different confidence: {}\n'.
                 format(h_gene, ', '.join(dif_conf_m_genes)))'''
            for el in dif_conf_m_genes:
                m_genes.remove((el, 0))  # remove repetition with low confidence
        low_conf_genes = [el[0] for el in m_genes if el[1] == 0]
        # if there is a subset of highly confident non-human genes assigned to the given human gene remove
        # assignment of this human gene to the rest of low-confident non-human genes
        if len(low_conf_genes) < len(m_genes):
            for m_gene in low_conf_genes:
                if len(m2h_d[m_gene]) == 1:
                    assert m2h_d[m_gene][0] == h_gene
                    del m2h_d[m_gene]
                else:
                    m2h_d[m_gene] = [el for el in m2h_d[m_gene] if el != h_gene]
    return m2h_d


def read_predefined_orth_dict(species='mouse', high_conf_orthology_only=False, input_genes=None,
                              map_to_human_orth_more=False, map_to_human_orth_all=False):
    if species not in ['mouse', 'rat']:
        raise Exception('\nError: species (pass through "--mouse-to-human-orth") should be one of: mouse, rat.\n')
    if high_conf_orthology_only:
        if map_to_human_orth_more or map_to_human_orth_all:
            name = '-more-high-conf'
        else:
            name = '-high-conf'
    elif map_to_human_orth_all:
        name = '-all'
    elif map_to_human_orth_more:
        name = '-more'
    else:
        name = ''
    file = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'data',
                        'human2{}_predefined_orth{}.json.gz'.format(species, name))
    with gzip.open(file, 'r') as fin:
        m2h_d = json.loads(fin.read().decode('utf-8'))
    if input_genes is not None:
        m2h_d = {m_gene: h_genes for m_gene, h_genes in m2h_d.items() if m_gene in input_genes}
    if map_to_human_orth_more and not map_to_human_orth_all:
        m2h_d = check_orth_dict(species, m2h_d)
    return m2h_d


def match_genes_to_human_orth_cols(df, dropped_elements,
                                   species,
                                   high_conf_orthology_only=False,
                                   gene_prefix_sep=None,
                                   map_to_human_orth_more=False,
                                   map_to_human_orth_all=False,
                                   map_to_human_expand_with_random_noise=False):
    sys.stderr.write('\nMatching {}-to-human gene names...\n'.format(species))
    if gene_prefix_sep is not None:
        if any([c.count(gene_prefix_sep) != 1 for c in df.columns]):
            sys.exit('\nExpecting gene-separator "{}" to appear exactly once in feature/gene name.\n'.format(
                gene_prefix_sep))
        input_genes = [c.split(gene_prefix_sep)[0] for c in df.columns]
    else:
        input_genes = df.columns

    m2h_d = read_predefined_orth_dict(
        species=species,
        high_conf_orthology_only=high_conf_orthology_only,
        input_genes=input_genes,
        map_to_human_orth_more=map_to_human_orth_more,
        map_to_human_orth_all=map_to_human_orth_all
    )

    def convert_mouse_to_human(df_h, m2h_d, dropped_elements, map_to_human_expand_with_random_noise):
        to_keep, new_colnames, to_drop, to_duplicate = [], [], [], {}
        for c in df_h.columns:
            c_use = c
            if gene_prefix_sep:
                c_use = c.split(gene_prefix_sep)[0]

            if c_use in m2h_d:
                to_keep.append(c)
                if gene_prefix_sep:
                    new_cols = ['{} {}'.format(el, c.split(gene_prefix_sep)[1]) for el in m2h_d[c_use]]
                else:
                    new_cols = m2h_d[c_use]
                new_colnames.append(new_cols[0])
                if len(new_cols) > 1:
                    to_duplicate[c] = new_cols[1:]
            else:
                to_drop.append(c)

        # map orthologs and update hgnc symbols in dropped elements
        dropped_elements.loc[dropped_elements.HGNC_symbol.isin(to_keep) &
                             ~dropped_elements.HGNC_symbol.duplicated() &
                             dropped_elements.description.isnull(), 'HGNC_symbol'] = new_colnames

        # annotate unmapped orthologs
        dropped_elements.loc[dropped_elements.HGNC_symbol.isin(to_drop) &
                             ~dropped_elements.HGNC_symbol.duplicated() &
                             dropped_elements.description.isnull(), 'description'] = 'Orthology mapping'

        df_h = df_h.loc[:, to_keep]  # select
        if to_duplicate:
            sys.stderr.write('\nMatrix dimension after selection of mapped genes: {}\n'.format(df_h.shape))
            import numpy as np
            duplicates = None
            new_genes = []
            duplicates_add_to_dropped = pd.DataFrame({'HGNC_symbol': [], 'description': []})
            for m_gene, h_genes in sorted(to_duplicate.items(), key=lambda x: x[0]):
                new_genes += h_genes
                new_cols = np.array([df_h[m_gene].copy() for _ in h_genes])
                if duplicates is None:
                    duplicates = new_cols.copy()
                else:
                    duplicates = np.vstack((duplicates, new_cols))
                duplicates_add_to_dropped = duplicates_add_to_dropped.append(pd.DataFrame({
                    'HGNC_symbol': h_genes,
                    'description': [None for _ in h_genes]},
                    index=[m_gene for _ in h_genes]))
            if map_to_human_expand_with_random_noise:
                np.random.seed(0)
                noise = np.random.normal(0, 1e-12, duplicates.shape)
                non_zeros = (duplicates != 0)
                duplicates[non_zeros] += noise[non_zeros]
            duplicates = pd.DataFrame(duplicates.T, index=df_h.index, columns=new_genes)
            new_colnames += list(duplicates.columns)
            df_h = pd.concat((df_h, duplicates), axis=1)
            dropped_elements = pd.concat((dropped_elements, duplicates_add_to_dropped), axis=0)
            sys.stderr.write('\nMatrix extended by multi-mapped human orthologs: {} genes added\n'.format(duplicates.shape[1]))
        df_h.columns = new_colnames  # rename

        return df_h, dropped_elements

    df, dropped_elements = convert_mouse_to_human(df, m2h_d, dropped_elements, map_to_human_expand_with_random_noise)
    sys.stderr.write('\nMatrix dimension after orthologs mapping: {}\n'.format(df.shape))
    return df, dropped_elements


def convert_genes_to_human_orth(gene_names, species, high_conf_orthology_only=False,
                                map_to_human_orth_more=False, map_to_human_orth_all=False, accept_na=False,
                                return_mapping_as_dict=False, verbose=True):
    """
    This function converts a list of mouse genes to their human orthologues. For
    genes that don't have orthologues, the gene name is unchanged. An array is
    returned that indicates which genes have not been converted.
    """

    if verbose:
        sys.stderr.write('\nMatching {}-to-human gene names...\n'.format(species))

    m2h_d = read_predefined_orth_dict(
        species=species,
        high_conf_orthology_only=high_conf_orthology_only,
        input_genes=gene_names,
        map_to_human_orth_more=map_to_human_orth_more,
        map_to_human_orth_all=map_to_human_orth_all
    )

    converted_genes = []
    converted_genes_flag = []
    to_duplicate = {}
    mapping = {}
    for gene in gene_names:
        if gene in m2h_d:
            new_gene = m2h_d[gene][0]
            if len(m2h_d[gene]) > 1:
                to_duplicate[gene] = m2h_d[gene]
        elif gene == 'N/A' and accept_na:
            new_gene = 'N/A'
        else:
            new_gene = None
        converted_genes.append(new_gene)
        converted_genes_flag.append(new_gene is not None)

        # alternatively, mapping as single dict
        if return_mapping_as_dict:
            if gene in m2h_d:
                mapping[gene] = m2h_d[gene]
            else:
                mapping[gene] = None

    if verbose:
        sys.stderr.write('\nNumber of matched genes: {}\n'.format(sum(converted_genes_flag)))

    # alternatively, mapping as single dict
    if return_mapping_as_dict:
        return mapping

    return converted_genes, np.array(converted_genes_flag), to_duplicate


def read_protein_synonyms():
    fn = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'data', 'protein_synonyms.tsv')
    return (pd.read_table(fn).set_index('synonym'))


def read_protein_to_gene():
    fn = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'data', 'protein_to_gene.json')
    return (json.load(open(fn)))


def read_HGNC():
    hgnc_f = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'data', 'HGNC_genes.txt.gz')
    # read HGNC names & synonyms (as sets)
    hgnc = {}
    with gzip.open(hgnc_f, 'rt') as f:
        for line in f:
            name, syns = line.rstrip().split('\t')
            hgnc[name] = set([s.upper() for s in json.loads(syns)])

    # Temporary solution to add in MT genes.
    with gzip.open(hgnc_f.replace('.txt.gz', '_additional.txt.gz'), 'rt') as f:
        for line in f:
            name, syns = line.rstrip().split('\t')
            if name not in hgnc:
                hgnc[name] = set(json.loads(syns))

    # drop non-upper-case names which exist as upper-case
    # this takes care of potential case-duplicates in the data file
    # which may cause dropping genes unecessarily due to suprious `unsafe` synonyms
    drop = []
    for g, s in hgnc.items():
        gu = g.upper()
        if gu != g and gu in hgnc:
            drop.append(g)
    for g in drop:
        del hgnc[g]

    return hgnc


def make_all_genes_dict(hgnc):
    # map gene names (HGNC & non-HGNC) to HGNC primary name
    hgnc_primary = set(hgnc.keys())
    all_genes = defaultdict(set)
    for name, synonyms in hgnc.items():
        all_genes[name].add(name)
        for s in synonyms:
            # only allow synonyms that do not interfer with primary names
            if s not in hgnc_primary:
                all_genes[s].add(name)
    return all_genes


def match_HGNC_names_cols(df, use_syn=False, use_rows=False, skip=False):
    if skip:
        return df, []

    hgnc = read_HGNC()

    # match & filter
    if use_syn:
        # try synonyms match, translated to HGNC primary names
        # sys.stderr.write('\nMatching gene names to HGNC using synonyms...\n')
        df, drop = synonyms_match_cols(df, hgnc, use_rows=use_rows, return_drop=True)
    else:
        # columns matching HGNC primary names
        # sys.stderr.write('\nMatching gene names to HGNC...\n')
        if use_rows:
            drop = list(set(df.index) - set(hgnc.keys()))
            df = df.loc[list(set(df.index) & set(hgnc.keys())), :]
        else:
            drop = list(set(df.columns) - set(hgnc.keys()))
            df = df.loc[:, list(set(df.columns) & set(hgnc.keys()))]

    sys.stderr.write('\nData dimensions after matching to HGNC names: {}\n'.format(df.shape))

    return df, drop


def convert_to_HGNC_names(gene_names, use_syn=False, verbose=False):
    """Convert list of gene names to HGNC or indicate that the gene name couldn't be converted.

    Parameters
    ----------
    gene_names : list-like
        Iterable of gene names to convert.
    use_syn : bool, optional
        Use gene name synonyms when converting to HGNC gene names.

    Returns
    -------
    conv : pandas.Series
        Pandas series whose index are the genes from gene_names and whose values are the
        corresponding HGNC gene symbols. If a gene from gene_names could not be converted, the value
        will be null.
    """
    import numpy as np
    hgnc = read_HGNC()

    gene_names = copy.deepcopy(gene_names)

    # Set a placeholder for `None` values which result in error in the below call
    # to `synonyms_match_cols(...)`; the placeholder fails to convert and results
    # in a null in the returned pd.Series, similarly to other inputs that fail to
    # converst
    gene_names = ['NONE-NOT-A-GENE' if pd.isnull(g) else g for g in gene_names]

    # Make fake dataframe for functions below
    df = pd.DataFrame(columns=list(gene_names))

    # match & filter
    if use_syn:
        # try synonyms match, translated to HGNC primary names
        if verbose:
            sys.stderr.write('\nMatching gene names to HGNC using synonyms...\n')
        df, drop = synonyms_match_cols(
            df,
            hgnc,
            drop_missing=False,
            return_drop=True,
        )
        new_gene_names = list(df.columns)
        not_converted = [x in drop for x in new_gene_names]
    else:
        # columns matching HGNC primary names
        if verbose:
            sys.stderr.write('\nMatching gene names to HGNC...\n')
        new_gene_names = []
        not_converted = []
        for gene in gene_names:
            new_gene_names.append(gene)
            if gene in hgnc.keys():
                not_converted.append(False)
            else:
                not_converted.append(True)

    if verbose:
        sys.stderr.write('\nMatched {} genes to HGNC names\n'.format(len(gene_names) - sum(not_converted)))

    conv = pd.DataFrame(
        {'converted_id': new_gene_names, 'convert_failed': not_converted},
        index=gene_names,
    )
    conv.loc[conv['convert_failed'] == True, 'converted_id'] = np.nan
    conv = conv['converted_id']

    # undo the placeholder set above; results in NaN index values for
    # items where input was equal to NaN/None
    conv.index = [None if x == 'NONE-NOT-A-GENE' else x for x in conv.index]

    return conv


def synonyms_match_cols(
        df,
        hgnc,
        use_rows=False,
        drop_missing=True,
        return_drop=False,
):
    hgnc_primary = set(hgnc.keys())
    all_genes = make_all_genes_dict(hgnc)
    drop, rename = set(), {}

    if use_rows:
        df_genes = set(df.index)
    else:
        df_genes = set(df.columns)

    # match dataframe genes
    for g in df_genes:
        match = match_gname(g, all_genes, hgnc_primary)
        if match:
            if match != g:
                # needs renaming
                if match in df_genes:
                    # match already exists as column;
                    # renaming to it will cause duplicates; drop.
                    drop.add(g)
                elif match in rename.values():
                    # match previously encountered for other column;
                    # renaming to it will cause duplicates; drop.
                    drop.add(g)
                else:
                    # okay to rename
                    rename[g] = match
        else:
            # column cannot be matched, drop
            drop.add(g)

    # do it
    if drop and drop_missing:
        if use_rows:
            df = df.drop(drop, axis=0)
        else:
            df = df.drop(drop, axis=1)
    if rename:
        if use_rows:
            df = df.rename(index=rename)
        else:
            df = df.rename(columns=rename)

    if return_drop:
        return (df, drop)
    else:
        return (df)


def match_HGNC_names(genes, use_syn=False):
    # read HGNC names & synonym sets
    hgnc = read_HGNC()

    # match & filter
    if use_syn:
        # try synonyms match, translated to HGNC primary names
        sys.stderr.write('\nMatching gene names to HGNC using synonyms...\n')
        genes = synonyms_match(genes, hgnc)
    else:
        # columns matching HGNC primary names
        sys.stderr.write('\nMatching gene names to HGNC...\n')
        genes = [gene for gene in genes if gene in hgnc.keys()]

    sys.stderr.write('\nMatched genes: {}\n'.format(len(genes)))
    return (genes)


def synonyms_match(genes, hgnc):
    hgnc_primary = set(hgnc.keys())
    all_genes = make_all_genes_dict(hgnc)

    # match using synonyms
    genes_final = []
    for g in genes:
        match = match_gname(g, all_genes, hgnc_primary)
        if match and match not in genes_final:
            genes_final.append(match)

    return genes_final


def match_gname(n, all_genes, hgnc_primary):
    ''' match given name to HGNC name, using synonyms if safe. '''
    n = n.upper()
    if n not in all_genes:
        n = n.replace('-', '')  # try without dash

    if n in hgnc_primary:
        return (n)  # HGNC name
    elif n in all_genes and len(all_genes[n]) == 1:
        # non-HGNC, but a 'safe' synonym (i.e., of exactly one HGNC name)
        return (list(all_genes[n])[0].upper())
    else:
        return (None)


def process_duplicates(df, mask, duplicate_genes):
    # leaving first row from duplicated ones is default behaviour and doesn't require any additional steps
    if duplicate_genes == 'first':
        return df
    # sanity check that given duplicate genes selection is supported by pandas
    if duplicate_genes not in ['min', 'max', 'mean', 'median']:
        raise Exception('Non-supported way of duplicate genes selection. Available: min, max, mean and median.')
    # firstly copy df to prevent pandas SettingwithCopyWarning
    dfc = df.copy()
    for gene in set(dfc.loc[mask].index):
        # get min/max/median/mean of columns(samples), non-numeric columns are skipped
        aggregated_values = getattr(df.loc[gene], duplicate_genes)()
        # update values
        dfc.loc[gene, aggregated_values.index] = aggregated_values.values

    return dfc


def drop_duplicate_columns(df, dropped_elements=None, duplicate_genes='first', verbose=True):
    # find column duplicates
    duplicates_mask_cols = df.columns.duplicated()
    duplicates = df.loc[:, duplicates_mask_cols].columns
    if duplicates_mask_cols.sum() > 0:
        if duplicate_genes != 'first':
            # transpose to genes x samples format
            df = df.T

            # create new, row-wise duplicates mask
            duplicates_mask_rows = df.index.duplicated()
            df = process_duplicates(df, duplicates_mask_rows, duplicate_genes)

            # transpose back to samples x genes format
            df = df.T

        # remove duplicates
        df = df.loc[:, ~duplicates_mask_cols]
        # annotate duplicates
        # conditions: get dropped genes, exclude first occurence of duplicates and rows with description
        dropped_mask = dropped_elements.HGNC_symbol.isin(duplicates) & \
                       dropped_elements.HGNC_symbol.duplicated() & \
                       dropped_elements.description.isnull()
        description = 'Duplicated' if duplicate_genes == 'first' else 'Aggregated'
        dropped_elements.loc[dropped_mask, 'description'] = description
        if verbose:
            sys.stderr.write('\n{} {} duplicated columns.\n'.format(
                'Removed' if duplicate_genes == 'first' else 'Aggregated',
                duplicates_mask_cols.sum())
            )
    if verbose:
        sys.stderr.write('\nData dimensions after {} of duplicates: {}\n'.format(
            'removal' if duplicate_genes == 'first' else 'aggregation',
            df.shape,
        ))
    return df, dropped_elements


def drop_duplicate_rows(df, dropped_elements=None, column_name=None,
                        duplicate_genes='first', verbose=True):
    # find duplicates in particular column
    if column_name is not None:
        if column_name in df.columns:
            duplicates_mask = df.duplicated(column_name)
            duplicates = df.loc[duplicates_mask, :].index
            if duplicates_mask.sum() > 0:
                # process duplicates (e.g. get mean of values)
                df = process_duplicates(df, duplicates_mask, duplicate_genes)
                # leave the first one with updated values
                df = df.drop_duplicates(column_name)
        else:
            raise (Exception('Given column_name: {} does not exist in DataFrame.'.format(column_name)))
    else:
        # find row-wise duplicates and remove them
        duplicates_mask = df.index.duplicated()
        duplicates = df.loc[duplicates_mask, :].index
        if duplicates_mask.sum() > 0:
            # process duplicates (e.g. get mean of values)
            df = process_duplicates(df, duplicates_mask, duplicate_genes)

            # remove duplicated rows, leave the first one with updated values
            df = df.loc[~duplicates_mask, :]

    # annotate duplicates
    # conditions: get dropped genes, exclude first occurence of duplicates and rows with description
    if dropped_elements is not None and not dropped_elements.empty:
        dropped_mask = dropped_elements.HGNC_symbol.isin(duplicates) & \
                       dropped_elements.HGNC_symbol.duplicated() & \
                       dropped_elements.description.isnull()
        description = 'Duplicated' if duplicate_genes == 'first' else 'Aggregated'
        dropped_elements.loc[dropped_mask, 'description'] = description
        if verbose:
            sys.stderr.write('\n{} {} duplicated rows.\n'.format(
                'Removed' if duplicate_genes == 'first' else 'Aggregated',
                duplicates_mask.sum())
            )
    sys.stderr.write('\nData dimensions after {} of duplicates: {}\n'.format(
        'removal' if duplicate_genes == 'first' else 'aggregation',
        df.shape,
    ))
    return df, dropped_elements


def without_data_type(d):
    res = copy.deepcopy(d)
    if 'data_type' in res:
        del res['data_type']
    return res


def upper_case_prefix(x, sep=' '):
    x_arr = x.split(sep)
    return ' '.join([x_arr[0].upper()] + x_arr[1:])


def column_json_gene_modified_protein_abundance(x):
    mod_sep = ','
    mod_type_sep = '|'
    gene_sep = ' '

    x_arr = x.split(gene_sep)
    if len(x_arr) == 1:
        g, mods = x_arr[0], None # no modificaitons
    elif len(x_arr) == 2:
        g, mods = x_arr[0], x_arr[1]
    else:
        sys.exit('\nUnexpected format of modified-protein gene column: {}\n'.format(x))

    em = {
        # 'label': SET BELOW,
        'data_type': ontology.NUMERIC,
        'entity': {
            'domain': copy.deepcopy(ontology.HGNC_DOMAIN),
            'name': g,
            'label': g,
            'type': ontology.GENE_TYPE,
        },
        'abundance': ontology.PROTEIN_ABUNDANCE,
    }

    em_label = g  # updated below

    if mods:
        mods_arr = mods.split(mod_type_sep)
        mods_d = {}
        for mod in mods_arr:
            if mod.startswith('P:'):
                # phosphorylation
                mods_d['ppa'] = mod[2:].split(mod_sep)
            if mod.startswith('PS:'):
                # peptide sequence
                mods_d['psq'] = mod[3:].split(mod_sep)
            if mod.startswith('UPID:'):
                # uniprot ID
                mods_d['upid'] = mod[5:].split(mod_sep)

            # others? ...

        em['modification'] = {'type': 'protein_modification'}

        if mods_d.get('ppa') and len(mods_d) == 1:
            # only phosphorylation
            em['modification']['details'] = {'type': 'phosphorylation'}
        elif mods_d:
            # any modification
            em['modification']['details'] = {'type': 'generic_protein'}

        if mods_d.get('upid'):
            em['modification']['details']['uniprot_id'] = mods_d['upid']
            em_label += ' UniProt {}'.format(' '.join(mods_d['upid']))
        if mods_d.get('ppa'):
            em['modification']['details']['phosphorylated_aa'] = mods_d['ppa']
            em_label += ' Phosphorylation {}'.format(' '.join(mods_d['ppa']))
        if mods_d.get('psq'):
            em['modification']['details']['peptide_sequence'] = mods_d['psq']
            em_label += ' Peptide {}'.format(' '.join(mods_d['psq']))

    # finally, add the abundance portion of the label
    em_label += ' {}'.format(ontology.ABUNDANCE_LABELS['protein_abundance'])

    em['label'] = em_label

    return em


def column_json_generic_numeric(x, domain_name):
    return ({
        'label': x,
        'data_type': ontology.NUMERIC,
        'entity': {
            'domain': {'name': domain_name},
            'name': x,
            'label': x,
            'type': ontology.GENERIC_ENTITY_TYPE,
        },
    })


def column_json_fusion(g):
    return ({
        'label': g + ' ' + ontology.MODIFICATION_LABELS['fusion'],
        'data_type': ontology.FUSION_FACTOR,
        'entity': {
            'domain': ontology.GENE_FUSION,
            'name': g,
            'label': g,
            'type': ontology.FUSION_TYPE,
        },
    })


def column_json_somatic_mutation(g):
    return ({
        'label': g + ' ' + ontology.MODIFICATION_LABELS['somatic_mutation'],
        'data_type': ontology.MUTATION_FACTOR,
        'entity': {
            'domain': copy.deepcopy(ontology.HGNC_DOMAIN),
            'name': g,
            'label': g,
            'type': ontology.GENE_TYPE,
        },
        'modification': ontology.SOMATIC_MUTATION,
    })


def column_json_copy_number(g):
    return ({
        'label': g + ' ' + ontology.ABUNDANCE_LABELS['gene_abundance'],
        'data_type': ontology.CNV_FACTOR,
        'entity': {
            'domain': copy.deepcopy(ontology.HGNC_DOMAIN),
            'name': g,
            'label': g,
            'type': ontology.GENE_TYPE,
        },
        'abundance': ontology.GENE_ABUNDANCE,
    })


def column_json_copy_gain(g):
    return ({
        'label': g + ' ' + ontology.ABUNDANCE_LABELS['gene_copy_gain'],
        'data_type': ontology.CNV_GAIN_FACTOR,
        'entity': {
            'domain': copy.deepcopy(ontology.HGNC_DOMAIN),
            'name': g,
            'label': g,
            'type': ontology.GENE_TYPE,
        },
        'abundance': ontology.GENE_COPY_GAIN,
    })


def column_json_copy_loss(g):
    return ({
        'label': g + ' ' + ontology.ABUNDANCE_LABELS['gene_copy_loss'],
        'data_type': ontology.CNV_LOSS_FACTOR,
        'entity': {
            'domain': copy.deepcopy(ontology.HGNC_DOMAIN),
            'name': g,
            'label': g,
            'type': ontology.GENE_TYPE,
        },
        'abundance': ontology.GENE_COPY_LOSS,
    })


def column_json_methylation(g):
    return ({
        'label': g + ' ' + ontology.MODIFICATION_LABELS['methylation'],
        'data_type': ontology.NUMERIC,
        'entity': {
            'domain': copy.deepcopy(ontology.HGNC_DOMAIN),
            'name': g,
            'label': g,
            'type': ontology.GENE_TYPE,
        },
        'modification': ontology.METHYLATION,
    })


def column_json_hypermethylation(g):
    return ({
        'label': g + ' ' + ontology.MODIFICATION_LABELS['hypermethylation'],
        'data_type': ontology.HYPERMETHYLATION_FACTOR,
        'entity': {
            'domain': copy.deepcopy(ontology.HGNC_DOMAIN),
            'name': g,
            'label': g,
            'type': ontology.GENE_TYPE,
        },
        'modification': ontology.HYPERMETHYLATION,
    })


def column_json_rna_abundance(g):
    return ({
        'label': g + ' ' + ontology.ABUNDANCE_LABELS['rna_abundance'],
        'data_type': ontology.NUMERIC,
        'entity': {
            'domain': copy.deepcopy(ontology.HGNC_DOMAIN),
            'name': g,
            'label': g,
            'type': ontology.GENE_TYPE,
        },
        'abundance': ontology.RNA_ABUNDANCE,
    })


def column_json_protein_abundance(g):
    return ({
        'label': g + ' ' + ontology.ABUNDANCE_LABELS['protein_abundance'],
        'data_type': ontology.NUMERIC,
        'entity': {
            'domain': copy.deepcopy(ontology.HGNC_DOMAIN),
            'name': g,
            'label': g,
            'type': ontology.GENE_TYPE,
        },
        'abundance': ontology.PROTEIN_ABUNDANCE,
    })


def column_json_gene_interference_CRISPRi(g):
    return ({
        'label': g + ' ' + ontology.INTERFERENCE_LABELS['CRISPRi'],
        'data_type': ontology.NUMERIC,
        'entity': {
            'domain': copy.deepcopy(ontology.HGNC_DOMAIN),
            'name': g,
            'label': g,
            'type': ontology.GENE_TYPE,
        },
        'interference': ontology.GENE_INTERFERENCE_CRISPRi,
    })


def column_json_gene_interference_RNAi(g):
    return ({
        'label': g + ' ' + ontology.INTERFERENCE_LABELS['RNAi'],
        'data_type': ontology.NUMERIC,
        'entity': {
            'domain': copy.deepcopy(ontology.HGNC_DOMAIN),
            'name': g,
            'label': g,
            'type': ontology.GENE_TYPE,
        },
        'interference': ontology.GENE_INTERFERENCE_RNAi,
    })


def sample_row_json(smp_id, smps_domain):
    smp_id = six.text_type(smp_id)
    return ({
        'sample': {
            'subject': {
                'domain': smps_domain,
                'domain_id': smp_id,
            },
            'source': smps_domain,
            'barcode': smp_id,
        },
        'label': '{} {}'.format(smps_domain, smp_id),
    })


def mtdata_config_yml(df, cln_yml,
                      skip_cols=None, levels_dict=None, censored_cols=None,
                      non_factor_char=None, non_generic_types=None,
                      drug_resp_cols=None, drug_treat_cols=None,
                      phenotype_clinical_cols=None, phenotype_pathology_cols=None,
                      cell_type_tissue_cols=None, cell_line_cols=None,
                      gene_somatic_mutation_cols=None):
    """Utility for preparing a metadata configuration YAML given Pandas Dataframe and
    per-column specifications of data type and additional variable metadata.

    Parameters
    ----------
    df : Pandas Dataframe
        Dataframe with metadata for which a configuration YAML will be created.
    cln_yml : string
        The desired file path for writing the configuration YAML.

    Returns
    -------
    df_mod : Pandas Dataframe
        Dataframe with values modified as per the specification and matching to config YAML.
    config: A dictionary containing the YAML configuration.
    """
    import numpy as np
    df_mod = df.copy(deep=True)

    def set_character_factor(d, vals):
        d['data_type_name'] = 'factor'
        d['data_type_type'] = 'character'
        d['levels'] = [{'value': x, 'label': str(x)} for x in vals]

    def set_numeric(d):
        d['data_type_name'] = 'numeric'
        d['data_type_type'] = 'numeric'

    def set_character(d):
        d['data_type_name'] = 'character'
        d['data_type_type'] = 'character'

    def assert_minimal_measurement(d, etype):
        minimal_meas_allowed_keys = set(['custom_attrs', 'label_suffix', 'label_prefix'])
        if not set(d.keys()).issubset(minimal_meas_allowed_keys):
            msg = ('Only "label_prefix", "label_suffix", and "custom_attrs" are '
                   'allowed on {} measurement'.format(etype))
            raise ValueError(msg)

    if skip_cols:
        skip_cols = set(skip_cols)
    else:
        skip_cols = set()

    config = {}
    for c in df_mod.columns:
        is_factor = False
        if c in skip_cols:
            continue

        etype = 'generic_entity'
        if non_generic_types and c in non_generic_types:
            etype = non_generic_types[c]

        config[c] = {
            'name': c,
            'entity_type': etype,
        }

        if df_mod[c].dtype in (np.float64, np.int64):
            set_numeric(config[c])

        elif df_mod[c].dtype == object:
            if non_factor_char and c in non_factor_char:
                set_character(config[c])
            else:
                is_factor = True
                set_character_factor(config[c], df_mod[c].dropna().unique())
                # take care of custom factors
                if levels_dict:
                    if c in levels_dict:
                        config[c]['data_type_type'] = 'numeric'

                        config[c]['levels'] = [
                            {'value': v, 'label': str(k)}
                            for k, v in levels_dict[c].items()
                        ]

                        col_vals = set(df_mod[c].dropna())
                        assert col_vals.issubset(set(levels_dict[c].keys())), col_vals
                        df_mod = df_mod.replace({c: levels_dict[c]})
                        col_vals = set(df_mod[c].dropna())
                        assert col_vals.issubset(set(levels_dict[c].values()))
        else:
            assert False, 'column {}, data_type: {}'.format(c, df_mod[c].dtype)

        print(c)
        print(json.dumps(config[c], indent=2, sort_keys=True))
        if is_factor:
            print(df_mod[c].value_counts())
        print('')

    # setup specialized (non-generic) column specs
    if drug_resp_cols:
        for dr_name, dr in drug_resp_cols.items():
            assert dr_name in config
            config[dr_name]['name'] = dr['drug_name']
            config[dr_name]['entity_type'] = 'drug'
            assert 'measurement' in dr, 'Expecting measurement for Drug Response'
            config[dr_name]['measurement'] = dr['measurement']

    if drug_treat_cols:
        for dr_name, dr in drug_treat_cols.items():
            assert dr_name in config
            config[dr_name]['name'] = dr['drug_name']
            config[dr_name]['entity_type'] = 'drug'
            assert 'measurement' in dr, 'Expecting measurement for Drug Treatment'
            config[dr_name]['measurement'] = dr['measurement']

    if phenotype_clinical_cols:
        for pc_name, pc in phenotype_clinical_cols.items():
            assert pc_name in config
            if 'name' in pc:  # allow overwriting entity
                config[pc_name]['name'] = pc['name']
            config[pc_name]['entity_type'] = 'phenotype'
            config[pc_name]['phenotype_info'] = {'domain': 'Clinical'}
            if 'measurement' in pc:
                assert_minimal_measurement(pc['measurement'], 'phenotype')
                config[pc_name]['measurement'] = pc['measurement']

    if phenotype_pathology_cols:
        for pp_name, pp in phenotype_pathology_cols.items():
            assert pp_name in config
            if 'name' in pp:  # allow overwriting entity
                config[pp_name]['name'] = pp['name']
            config[pp_name]['entity_type'] = 'phenotype'
            config[pp_name]['phenotype_info'] = {'domain': 'Pathology'}
            if 'measurement' in pp:
                assert_minimal_measurement(pp['measurement'], 'phenotype')
                config[pp_name]['measurement'] = pp['measurement']

    if cell_type_tissue_cols:
        for ct_name, ct in cell_type_tissue_cols.items():
            assert ct_name in config
            if 'name' in ct:  # allow overwriting entity
                config[ct_name]['name'] = ct['name']
            config[ct_name]['entity_type'] = 'cell_type'
            config[ct_name]['cell_type_info'] = {'domain': 'Tissue'}
            if 'measurement' in ct:
                assert_minimal_measurement(ct['measurement'], 'cell_type')
                config[ct_name]['measurement'] = ct['measurement']

    if cell_line_cols:
        for cl_name, cl in cell_line_cols.items():
            assert cl_name in config
            config[ct_name]['entity_type'] = 'cell_line'

    if censored_cols:
        for cc_name, cc in censored_cols.items():
            # remove underlying columns
            assert cc['time_col'] in config
            del config[cc['time_col']]
            assert cc['event_col'] in config
            del config[cc['event_col']]
            assert cc['time_unit'] in ('day', 'week', 'month', 'year')
            config[cc_name] = {
                'name': 'Survival',  # entity preset in this case
                'data_type_name': 'censored',
                'data_type_type': 'json',
                'entity_type': 'phenotype',
                # 'survival': cc['survival'],  # legacy
                'composite_column': True,
                'censored_time_column': cc['time_col'],
                'censored_time_unit': cc['time_unit'],
                'censored_event_column': cc['event_col'],
                'censored_event_values': cc['censored_event_values'],
                'measurement': cc['measurement'],
            }

    if gene_somatic_mutation_cols:
        for gc_name, gc in gene_somatic_mutation_cols.items():
            assert gc_name in config
            config[gc_name]['somatic_mutation'] = True
            config[gc_name]['entity_type'] = 'gene'

    with open(cln_yml, 'w') as f:
        json.dump(config, f, indent=2)

    return df_mod, config


def mtdata_df_examine(df):
    for c in df.columns:
        print('\n{} -- {}'.format(c, df[c].dtype))
        if len(df[c].unique()) < 0.15 * len(df):
            print(df[c].value_counts(dropna=False).sort_index())
        else:
            print(df[c].iloc[0:5].tolist())


def ensembl_ids_to_gene_symbols(l):
    """Translate list of ENSEMBL IDs to gene names.

    Parameters
    ----------
    l: list of ENSEMBL IDs.

    Returns
    -------
    genes: list of gene symbols corresponding to input ENSEMBL IDs or None where no
           match was found.

    """

    # Read tsv file with annotated ids and convert it to dict {ensembl_id: hgnc_gene_name}
    annotation = pd.read_csv(
        ensembl_annotation_path, sep='\t', index_col=1, header=0, compression='gzip',
    ).to_dict()['Approved Symbol']

    gene_names = []
    for ensembl_id in l:
        # remove part after dot in ensembl ids and ensure it's upper case
        current_id = ensembl_id.split('.')[0].upper()
        # annotate id with hgnc gene names
        gene_name = annotation.get(current_id, None)
        gene_names.append(gene_name)

    return gene_names


def translate_ensembl_ids_to_hgnc(data, dropped_elements, duplicate_genes='first',
                                  modified_protein=False, gene_prefix_sep=' ', verbose=True):
    """Translate ENSEMBL ids to HGNC gene names.

    Parameters
    ----------
    data: pandas.DataFrame/list
        Pandas dataframe with rows corresponding to ENSEMBL ids and columns to samples or
        list with ensembl ids.
    dropped_elements: pandas.DataFrame
        Pandas dataframe containing dropped genes and a reason for it. Rows correspond to genes and
        columns to various information.
    duplicate_genes : str, optional
        Duplicate genes selection. Default: first occurrence is kept.
        Other options are min/mean/median/max value from duplicate genes.
    modified_protein: bool
        Flag denoting whether modified_protein tool is used.
    gene_prefix_sep: str
        Separator between gene and features in phopshoprotein tool.

    Returns
    -------
    data: pandas.DataFrame/list
        Pandas dataframe with rows corresponding to HGNC gene names and columns to samples or
        list with ensembl ids
    dropped_elements: pandas.DataFrame
        Pandas dataframe containing dropped genes and a reason for it. Rows correspond to genes and
        columns to various information.

    """

    # Read tsv file with annotated ids and convert it to dict {ensembl_id: hgnc_gene_name}
    annotation = pd.read_csv(
        ensembl_annotation_path, sep='\t', index_col=1, header=0, compression='gzip',
    ).to_dict()['Approved Symbol']

    dropped_elements['HGNC_symbol'] = None

    if modified_protein:
        # modified_protein tool
        gene_names = []
        for row in data.index:
            if gene_prefix_sep:
                if row.count(gene_prefix_sep) != 1:
                    sys.exit('\nExpecting gene-separator "{}" to appear exactly once in feature/gene name.\n'.format(
                        gene_prefix_sep))
            # get ensembl id
            ensembl_id = row.split(gene_prefix_sep)[0]

            # remove part after dot in ensembl ids and ensure upper case
            ensembl_id = ensembl_id.split('.')[0].upper()

            gene_names.append(annotation.get(ensembl_id, None))

        data['gene_name'] = gene_names

        # remove not translated ensembl ids from data
        data = data.loc[~data['gene_name'].isnull(), :]

        # add description for ids that were not translated
        dropped_elements.loc[~dropped_elements.index.isin(data.index) &
                             dropped_elements.description.isnull(), 'description'] = 'ENSEMBL conversion'

        # annotate ensembl ids with hgnc symbol in dropped_elements df
        dropped_elements.loc[data.index, 'HGNC_symbol'] = data['gene_name']

        def prepare_new_indices(df, gene_colname):
            # prepare new index for data
            new_indices = []
            for index, row in df.iterrows():
                gene = row[gene_colname]
                features = index.split(gene_prefix_sep)[1]
                new_index = '{}{}{}'.format(gene, gene_prefix_sep, features)
                new_indices.append(new_index)
            return new_indices

        # set new index and remove column with gene names
        data.index = prepare_new_indices(data, 'gene_name')
        data = data.drop('gene_name', axis=1)

        # update hgnc symbols in dropped elements
        dropped_elements['HGNC_symbol'] = prepare_new_indices(dropped_elements, 'HGNC_symbol')

        # drop duplicated rows
        data, dropped_elements = drop_duplicate_rows(
            data, dropped_elements=dropped_elements,
            duplicate_genes=duplicate_genes, verbose=verbose)

        return data, dropped_elements

    elif isinstance(data, pd.DataFrame):
        # tools: cell type signatures, omics, genestats
        gene_names = []

        for ensembl_id in data.index:
            # remove part after dot in ensembl ids and ensure upper case
            current_id = ensembl_id.split('.')[0].upper()

            # annotate ensembl id with corresponding HGNC gene name
            gene_names.append(annotation.get(current_id, None))

        data['gene_name'] = gene_names

        # remove not translated ensembl ids from data
        data = data.loc[~data['gene_name'].isnull(), :]

        # add description for ids that were not translated
        dropped_elements.loc[~dropped_elements.index.isin(data.index) &
                             dropped_elements.description.isnull(), 'description'] = 'ENSEMBL conversion'

        # annotate ensembl ids with hgnc symbol in dropped_elements df
        dropped_elements.loc[data.index, 'HGNC_symbol'] = data['gene_name']

        # set HGNC gene names as index
        data.set_index('gene_name', inplace=True)

        # drop duplicated gene_names
        data, dropped_elements = drop_duplicate_rows(
            data, dropped_elements=dropped_elements,
            duplicate_genes=duplicate_genes, verbose=verbose)

        return data, dropped_elements

    elif isinstance(data, list):
        # genes tool
        gene_names = []
        for index, ensembl_id in enumerate(data):
            # remove part after dot in ensembl ids and ensure it's upper case
            current_id = ensembl_id.split('.')[0].upper()

            # annotate id with hgnc gene names
            gene_name = annotation.get(current_id, None)
            if gene_name:
                #  making gene_names list of unique elements
                if gene_name not in gene_names:
                    gene_names.append(gene_name)
                    dropped_elements.iat[index, 0] = gene_name
                else:
                    dropped_elements.iat[index, 1] = 'Duplicated'
            else:
                dropped_elements.iat[index, 1] = 'ENSEMBL conversion'
        return gene_names, dropped_elements
    else:
        raise Exception('Unsupported data type. Use pandas DataFrame or list.')


def write_dropped_aggregated_as_tsv(df, outf, verbose=True):
    df.index.name = 'ID'
    if outf.endswith(('.tbl', '.mtx', '.h5ad')):
        # remove file extension
        outf = '.'.join(outf.strip().split('.')[:-1])
    dropped_file, aggregated_file = outf, outf
    if not dropped_file.endswith('.dropped.tsv'):
        dropped_file += '.dropped.tsv'
    if not aggregated_file.endswith('.aggregated.tsv'):
        aggregated_file += '.aggregated.tsv'
    # separate dropped and aggregated elements
    aggregated_mask = df.description == 'Aggregated'
    aggregated = df.loc[aggregated_mask, :]
    dropped = df.loc[~aggregated_mask, :]

    if not dropped.empty:
        dropped.sort_index().to_csv(dropped_file, sep='\t')
        if verbose:
            sys.stderr.write(
                '\nWrote dropped elements (.tsv) file to: {} ({} elements)\n'.format(
                    dropped_file, dropped.shape[0])
            )

    if not aggregated.empty:
        # count duplicates of particular gene/feature
        aggregated_counter = pd.DataFrame(aggregated.index.value_counts() + 1)
        aggregated_counter.index.name = 'ID'
        aggregated_counter.columns = ['counter']
        aggregated_counter.sort_index().to_csv(aggregated_file, sep='\t')
        if verbose:
            sys.stderr.write(
                '\nWrote aggregated elements (.tsv) file to: {} ({} elements)\n'.format(
                    aggregated_file, aggregated_counter.counter.sum() - aggregated_counter.shape[0])
            )


def remove_col_duplicates_pandas(df):
    """If duplicates in column names exists, then pandas adds '.[0-9]' to make them unique.
    e.g. [GENE, GENE, GENE] -> [GENE, GENE.1, GENE.2]
    This function reverse this process.

    Parameters
    ----------
    df: pandas.DataFrame

    Returns
    -------
    df: pandas.DataFrame
        Pandas dataframe with column names without pandas modification.

    """
    new_colnames = []
    for col in df.columns:
        # find '.[0-9]', e.g '.1' in column name
        match = re.search(string=col, pattern='\.[0-9]+$')
        new_col = col
        if match:
            # ensure that id (without pandas modification) exists in df and if so, overwrite it
            if col[:match.start()] in df.columns:
                new_col = col[:match.start()]
        new_colnames.append(new_col)

    # set new colnames
    df.columns = new_colnames

    return df


def write_df_as_tbl(df, outf, meta_d=None):
    with open(outf, 'w') as f:
        if meta_d:
            f.write('#{}\n'.format(json.dumps(meta_d)))
        f.write('\t' + '\t'.join(df.columns) + '\n')
        df.to_csv(f, sep='\t', quoting=csv.QUOTE_NONE, quotechar='',
                  header=None, mode='a', na_rep='NA')


def simplify_tbl_df(df_orig):
    df = df_orig.copy(deep=True)
    df.index = [json.loads(x)['sample']['barcode'] for x in df.index]
    df.columns = [json.loads(c)['entity']['label'] for c in df.columns]
    return df


def verify_mut_and_mut_info(df_mut, df_mut_info=None, df_mut_info_fmt=None):
    ''' Verify that the binary and JSON (somatic) mutation data agree '''
    assert df_mut_info is not None or df_mut_info_fmt is not None, '\nNothing to verify'

    if df_mut_info is not None:
        # verify unformatted version (should have identical dimension)
        assert (df_mut.index == df_mut_info.index).all()
        assert (df_mut.columns == df_mut_info.columns).all()
        assert (df_mut == 1).equals(df_mut_info != 'null')

    if df_mut_info_fmt is not None:
        # verify formatted version; here some columns will have been dropped
        # or renamed in HGNC mapping; still we can verify that most agree
        df_mut_info_fmt_smp = simplify_tbl_df(df_mut_info_fmt)
        shared_cols = set(df_mut_info_fmt_smp.columns) & set(df_mut.columns)
        assert set(df_mut.index) == set(df_mut_info_fmt_smp.index)   # index identical
        assert len(shared_cols) >= len(df_mut.columns)*0.95  # most columns agree
        assert (df_mut.loc[:,shared_cols] == 1).equals(df_mut_info_fmt_smp.loc[df_mut.index, shared_cols] != 'null')
