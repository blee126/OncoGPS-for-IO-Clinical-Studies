import pandas as pd
import json
import sys
import os
import plotly.express as px
import plotly.graph_objects as go
import numpy as np
import math
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from natsort import natsorted


def read_tbl_result_table(file, rewrite_values=True):
    if file.endswith('.tbl'):
        f = open(file, 'r')
    elif file.endswith('.tbl.zip'):
        import zipfile
        _, filename = os.path.split(file)
        f = zipfile.ZipFile(file, 'r').open(filename.replace('.zip', ''), 'r')
    elif file.endswith('.tbl.gz'):
        import gzip
        f = gzip.open(file, 'r')
    comment = 0
    for line in f:
        if isinstance(line, bytes):
            line = line.decode('utf-8')
        if line.startswith('#'):
            comment += 1
        else:
            break
    f.close()
    m = pd.read_csv(file, sep='\t', header=0, index_col=0, na_values='NA',
                    skiprows=comment, compression='infer')
    columns = [json.loads(c.strip('"').replace('""', '"')) for c in m.columns]
    index = [json.loads(c.strip('"').replace('""', '"')) for c in m.index]
    m.columns = [el['label'] for el in columns]
    m.index = [el['label'] for el in index]
    if rewrite_values:
        for c in columns:
            if 'levels' in c['data_type']:
                before, after = [], []
                for el in c['data_type']['levels']:
                    before.append(el['value'])
                    after.append(el['label'])
                m[c['label']].replace(before, after, inplace=True)
    return m


def plot_boxplot(table, boxplot_file, title=None, labels=None, boxplot_sort='q3'):

    if table.shape[0] < 100:
        n_outs = 50
    elif table.shape[0] < 1000:
        n_outs = 10
    else:
        n_outs = 1

    if boxplot_sort == 'q3':
        order = table.quantile(q=0.75, axis=1).sort_values(ascending=True).index
    elif boxplot_sort == 'q1':
        order = table.quantile(q=0.25, axis=1).sort_values(ascending=True).index
    elif boxplot_sort == 'mean':
        order = table.mean(axis=1).sort_values(ascending=True).index
    elif boxplot_sort == 'median':
        order = table.median(axis=1).sort_values(ascending=True).index
    fig = go.Figure()
    out_threshold = 1.5
    min_y, max_y = float('inf'), -float('inf')
    if labels is not None:
        label_name = labels.columns[0]
        unique_labels = natsorted(labels[label_name].unique())
        for label in unique_labels:
            sample_subset = np.where(labels.values == label)[0]
            table_subset = table.iloc[sample_subset, :]
            q1s = table_subset.quantile(q=0.25, axis=1)
            medians = table_subset.median(axis=1)
            q3s = table_subset.quantile(q=0.75, axis=1)
            iqrs = q3s - q1s
            down_whiskers = [min(row[row > q1 - (out_threshold * iqr)].values)
                             for (_, row), q1, iqr in zip(table_subset.iterrows(), q1s, iqrs)]
            up_whiskers = [max(row[row < q3 + (out_threshold * iqr)].values)
                           for (_, row), q3, iqr in zip(table_subset.iterrows(), q3s, iqrs)]
            is_out1s = [row < whisker for (_, row), whisker in zip(table_subset.iterrows(), down_whiskers)]
            is_out3s = [row > whisker for (_, row), whisker in zip(table_subset.iterrows(), up_whiskers)]
            out1s = [row[is_out].values for (_, row), is_out in zip(table_subset.iterrows(), is_out1s)]
            out3s = [row[is_out].values for (_, row), is_out in zip(table_subset.iterrows(), is_out3s)]
            out1s_filtered = [outs[[el for el in np.argsort(np.absolute(outs)) if el < n_outs]] for outs in out1s]
            out3s_filtered = [outs[[el for el in np.argsort(np.absolute(outs)) if el < n_outs]] for outs in out3s]
            y_outliers = [np.append(out1, out3) for out1, out3 in zip(out1s_filtered, out3s_filtered)]
            trace = {
                'type': 'box',
                'median': medians.values,
                'q1': q1s.values,
                'q3': q3s.values,
                'lowerfence': down_whiskers,
                'upperfence': up_whiskers,
                'x': table_subset.index,
                'y': y_outliers,
                'name': label + ' (n={})'.format(table_subset.shape[0]),
                'whiskerwidth': 0.3,
                'marker_size': 2,
                'line': {'width': 0.7},
                'pointpos': 0
            }
            fig.add_trace(trace)
            np.warnings.filterwarnings('ignore', category=np.VisibleDeprecationWarning)
            y_values = np.concatenate([np.concatenate(y_outliers), medians.values, np.array(up_whiskers),
                                      np.array(down_whiskers), np.concatenate(np.array(out1s_filtered)),
                                      np.concatenate(np.array(out3s_filtered))])
            if min(y_values) < min_y:
                min_y = min(y_values)
            if max(y_values) > max_y:
                max_y = max(y_values)
    else:
        q1s = table.quantile(q=0.25, axis=1)
        medians = table.median(axis=1)
        q3s = table.quantile(q=0.75, axis=1)
        iqrs = q3s - q1s
        down_whiskers = [min(row[row > q1 - (out_threshold * iqr)].values)
                         for (_, row), q1, iqr in zip(table.iterrows(), q1s, iqrs)]
        up_whiskers = [max(row[row < q3 + (out_threshold * iqr)].values)
                       for (_, row), q3, iqr in zip(table.iterrows(), q3s, iqrs)]
        is_out1s = [row < whisker for (_, row), whisker in zip(table.iterrows(), down_whiskers)]
        is_out3s = [row > whisker for (_, row), whisker in zip(table.iterrows(), up_whiskers)]
        out1s = [row[is_out].values for (_, row), is_out in zip(table.iterrows(), is_out1s)]
        out3s = [row[is_out].values for (_, row), is_out in zip(table.iterrows(), is_out3s)]
        out1s_filtered = [outs[[el for el in np.argsort(np.absolute(outs)) if el < n_outs]] for outs in out1s]
        out3s_filtered = [outs[[el for el in np.argsort(np.absolute(outs)) if el < n_outs]] for outs in out3s]
        y_outliers = [np.append(out1, out3) for out1, out3 in zip(out1s_filtered, out3s_filtered)]
        trace = {
            'type': 'box',
            'median': medians.values,
            'q1': q1s.values,
            'q3': q3s.values,
            'lowerfence': down_whiskers,
            'upperfence': up_whiskers,
            'x': table.index,
            'y': y_outliers,
            'whiskerwidth': 0.3,
            'marker_size': 2,
            'line': {'width': 0.7},
            'pointpos': 0
        }
        fig.add_trace(trace)
        y_values = np.concatenate([np.concatenate(y_outliers), medians.values, np.array(up_whiskers),
                                   np.array(down_whiskers), np.concatenate(np.array(out1s_filtered)),
                                   np.concatenate(np.array(out3s_filtered))])
        if min(y_values) < min_y:
            min_y = min(y_values)
        if max(y_values) > max_y:
            max_y = max(y_values)
    y_range_margin = 0.01 * (max_y - min_y)
    fig.add_annotation(x=order[0], y=min_y-y_range_margin,
                       text="Showing up to {0} top and {0} bottom outlier points per sample".format(n_outs),
                       showarrow=False, xanchor='left', yanchor='bottom', borderpad=0, font_color='gray')
    fig.update_layout(xaxis_categoryorder='array', xaxis_categoryarray=list(order),
                      title_text=title, yaxis_range=[min_y-y_range_margin, max_y+y_range_margin])
    fig.write_html(boxplot_file)
    print('Boxplot written to {}'.format(boxplot_file))


def plot_pca(table, pca_file, title, labels):
    table_scaled = StandardScaler().fit_transform(table.T)
    pca_out = PCA(n_components=2).fit(table_scaled).components_
    if labels is not None:
        labels_name = str(labels.columns[0])
        labels_unique = labels[labels_name].unique()
        labels_counts = labels[labels_name].value_counts()
        labels[labels_name].replace(labels_unique, [label + ' (n={})'.format(labels_counts[label])
                                                    for label in labels_unique], inplace=True)
        table_pca = pd.DataFrame({'PC1': pca_out[0], 'PC2': pca_out[1],
                                  labels_name: labels.loc[table.index][labels_name].values}, index=table.index)
        table_pca.sort_values(labels_name, axis=0, inplace=True)
        fig = px.scatter(table_pca, x="PC1", y="PC2", color=labels_name, title=title)
        legend_width = max([len(el) for el in [labels_name] + [la for la in labels[labels_name].unique()]])
    else:
        table_pca = pd.DataFrame({'PC1': pca_out[0], 'PC2': pca_out[1]}, index=table.index)
        fig = px.scatter(table_pca, x="PC1", y="PC2", title=title)
        legend_width = 0
    fig.update_layout(autosize=False, width=1000+(legend_width*5), height=1000,
                      margin=dict(l=100, r=100, t=100, b=100))
    fig.write_html(pca_file)
    print('PCA plot written to {}'.format(pca_file))


def plot_barplot(data, barplot_file, title, labels):
    if labels is not None:
        labels_name = str(labels.columns[0])
        labels_unique = labels[labels_name].unique()
        labels_counts = labels[labels_name].value_counts()
        labels[labels_name].replace(labels_unique, [label + ' (n={})'.format(labels_counts[label])
                                    for label in labels_unique], inplace=True)
        data = pd.concat([data, labels], axis=1)
        data.sort_values(labels_name, axis=0, inplace=True)
        fig = px.bar(data, x=data.index, y='Count', color=labels_name, title=title)
    else:
        fig = px.bar(data, x=data.index, y='Count', title=title)
    fig.update_layout(xaxis_categoryorder='total descending', bargap=0)
    xaxis_gap = math.ceil(data.shape[0] * 0.01)
    fig.update_xaxes(title='', range=(-1 * xaxis_gap, data.shape[0] + xaxis_gap))
    fig.write_html(barplot_file)
    print('Barplot written to {}'.format(barplot_file))


def plot_numeric(table, outfile, title, labels=None, boxplot_sort='q3'):
    if table.shape[0] > 2000:
        sys.stderr.write('\nWARNING: number of samples equals {}. It is too many to create a boxplot - '
                         'max number of samples to plot on the boxplot is 2000. Plotting boxplot is omitted.\n'.
                         format(table.shape[0]))
    else:
        boxplot_file = outfile + '_boxplot.html'
        plot_boxplot(table, boxplot_file, title, labels, boxplot_sort)
    pca_file = outfile + '_pca.html'
    plot_pca(table, pca_file, title, labels)


def plot_binary(table, outfile, title, labels=None):
    data = pd.DataFrame(table.sum(axis=1), columns=['Count'])
    barplot_file = outfile + '_barplot.html'
    plot_barplot(data, barplot_file, title, labels)


def run(mode,
        input_table,
        title=None,
        sample_labels_table=None,
        sample_labels_column=None,
        boxplot_sort='q3',
        outfile=None):

    if mode not in ['numeric', 'binary']:
        raise Exception('\nError: wrong value of mode parameter - it should be numeric or binary.\n')

    if boxplot_sort not in ['q3', 'q1', 'median', 'mean']:
        raise Exception('\nError: wrong value of boxplot_sort parameter - '
                        'it should be one of: q3, q1, median or mean.\n')

    if input_table.endswith(('.tsv', '.tsv.gz', '.tsv.zip')):
        table = pd.read_csv(input_table, sep='\t', index_col=0, compression='infer')
    elif input_table.endswith(('.tbl', '.tbl.gz', 'tbl.zip')):
        if mode == 'binary':
            rewrite_values = False
        elif mode == 'numeric':
            rewrite_values = True
        table = read_tbl_result_table(input_table, rewrite_values=rewrite_values)
    else:
        raise Exception('\nError: wrong format of the input table: it should be written in tsv (tsv/tsv.zip/tsv.gz) '
                        'or in tbl (tbl/tbl.zip/tbl.gz) format.\n')

    input_path, input_file = os.path.split(input_table)
    if outfile is None:
        outfile, _ = os.path.splitext(input_table.replace('.tbl', '').replace('.tsv', ''))
    else:
        outfile = os.path.join(input_path, outfile)
    if title is None:
        title, _ = os.path.splitext(input_file)
    title += ' (N={})'.format(table.shape[0])

    if (sample_labels_table and not sample_labels_column) or \
       (not sample_labels_table and sample_labels_column):
        raise Exception('\nError: sample_labels_table must be given together with sample_labels_column.\n')
    elif sample_labels_table and sample_labels_column:
        if sample_labels_table.endswith('.tsv'):
            labels_table = pd.read_csv(sample_labels_table, sep='\t', index_col=0)
        elif sample_labels_table.endswith('.tbl'):
            labels_table = read_tbl_result_table(sample_labels_table)
        else:
            raise Exception('\nError: wrong format of the sample_labels_table: '
                            'it should be written in tsv or in tbl format.\n')
        if sample_labels_column not in labels_table:
            raise Exception(
                '\nError: sample_labels_column "{}" is not present in the given sample_labels_table "{}"\n'.
                    format(sample_labels_column, sample_labels_table))
        common_samples = [el for el in table.index if el in labels_table.index]
        if len(common_samples) < table.shape[0]:
            sys.stderr.write('\nWARNING: {} sample(s) are not present in the given sample_labels_table.\n'.
                             format(table.shape[0]-len(common_samples)))
        labels = pd.concat([pd.DataFrame({}, index=table.index),
                            labels_table.loc[common_samples][sample_labels_column]], axis=1)
        labels = labels.astype(str)
    else:
        labels = None

    if mode == 'numeric':
        plot_numeric(table, outfile, title, labels=labels, boxplot_sort=boxplot_sort)
    elif mode == 'binary':
        plot_binary(table, outfile, title, labels=labels)
