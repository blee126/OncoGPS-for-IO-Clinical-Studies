import csv
import json
import pdb
import sys
import uuid
import yaml
import copy
import six

import pandas as pd

from bi_import_utils import ontology
from bi_import_utils import commons

'''
Format metadata matrix (tab separated) as BI data table.

Notes:
  1. Column headers should be unique and match top-level keys from config file.
  2. Row headers should be unique and correspond to sample identifiers.
  3. Takes a config file (.yaml) with column-specific formatting specifications.

Note: Columns not matching any top-level config key are skipped.

Copyright 2018 Data4Cure, Inc. All rights reserved.
'''

as_clinical = False  # hardcoded for now; expose as option if becomes useful

domain_by_etype = {
    'gene': 'HGNC',
    'drug': 'drug',
    'intervention': 'Intervention',
    'environmental_condition': 'Environmental Condition',
    'health_condition': 'health_condition',
    'cell_line': 'Cell Line',
    'RNAi': 'RNAi',
    'CRISPRi': 'CRISPRi',
}


def read(
    input_tsv,
    config,
    verbose=False,
):
    """Read tab-separated file with metadata and yaml file specifying configuration.

    Parameters
    ----------
    input_tsv : str
        Path to input file containing metadat. Rows should correspond to samples and columns should
        correspond to metadata.
    config : str
        Path to input file yaml file containing configuration for metadata columns.
        correspond to metadata.
    verbose : bool, optional
        If True, print logging information to stderr.

    Returns
    -------
    metadata : pandas.DataFrame
        Pandas dataframe containing gene-level statistics. Rows correspond to genes and columns
        correspond to statistics.
    conf : dict
        Configuration for metadata columns.
    """
    # read clinical csv
    # metadata = pd.read_csv(input_tsv, sep='\t', header=0, index_col=0, na_values='NA', low_memory=False)
    # note: this prevents issues with rouding of numeric-like index columns which may cause duplicate rows
    metadata = pd.read_csv(input_tsv, sep='\t', header=0, na_values='NA', low_memory=False, dtype={0: 'object'})
    metadata = metadata.set_index(metadata.iloc[:,0])

    # read config YAML
    with open(config, 'r') as config_f:
        conf = yaml.load(config_f, Loader=yaml.SafeLoader)
    return(metadata, conf)


def write(metadata, conf, samples_domain, output_tbl, verbose=False):
    """Write metadata dataframe as BI tbl file using a configuration that describes the columns.

    Parameters
    ----------
    metadata : pandas.DataFrame
        Pandas dataframe containing gene-level statistics. Rows correspond to genes and columns
        correspond to statistics.
    conf : dict
        Configuration for metadata columns.
    samples_domain : str
        Domain of samples; e.g. your organization name.
    output_tbl: str
        Path to write tbl file to.
    verbose : bool, optional
        If True, print logging information to stderr.
    """
    # Create deepcopy of input matrix to avoid changing input object
    # TODO: At some point, it might be nice to replace df with metadata throughout to make searching
    # etc. easier.
    df = metadata.copy(deep=True)

    def row_json_clinical(x):
        x = six.text_type(x)
        return {
            'clinical': {
                'subject': {
                    'domain': samples_domain,
                    'domain_id': x,
                }
            },
            'label': '{} {}'.format(samples_domain, x),
        }

    def row_json_sample(x):
        x = six.text_type(x)
        return {
            'sample': {
                'source': samples_domain,
                'barcode': x,
                'subject': {'domain': samples_domain, 'domain_id': x}
            },
            'label': '{} {}'.format(samples_domain, x),
        }

    def make_censored_column(df, conf):
        censored_keys = ['censored_time_column', 'censored_event_column', 'censored_event_values']
        if any(x not in conf for x in censored_keys):
            raise ValueError('Column with "data_type_name": "censored" must have configuration '
                             'attributes: {}'.format(', '.join(censored_keys)))
        time_c = conf['censored_time_column']
        event_c = conf['censored_event_column']
        event_map = conf['censored_event_values']
        if set(event_map.keys()) != set(['censored', 'uncensored']):
            raise ValueError('The keys of "censored_event_values" attribute '
                             'must be "censored" and "uncensored".')
        event_map_rev = {v: k for k, v in event_map.items()}
        censored_values = []
        for x in df.index:
            t = float(df.loc[x, time_c])
            e = df.loc[x, event_c]
            if pd.isnull(t):
                t_val = None
            else:
                t_val = float(df.loc[x, time_c])
            if pd.isnull(e):
                cens_val = None
            else:
                if e in event_map_rev:
                    cens_val = event_map_rev[e] == 'censored'
                else:
                    raise ValueError('censored event column value: "{}" is missing from '
                                     'the "censored_event_values" configuration'.format(e))

            v = json.dumps({'time': t_val, 'censored': cens_val}, sort_keys=True)
            if t_val is None:
                v = None
            censored_values.append(v)

        return censored_values

    def try_fix_intlike_str(x):
        if pd.isnull(x):
            return None
        try:
            ans = str(int(x))
        except:
            ans = x
        return ans

    # row headers
    if as_clinical:
        # as clinical objects
        df.index = [json.dumps(row_json_clinical(x), sort_keys=True) for x in df.index]
    else:
        # as sample objects
        df.index = [json.dumps(row_json_sample(x), sort_keys=True) for x in df.index]

    new_col_headers = {}

    # column headers
    for c in conf.keys():
        c_use = c
        print(c)
        ename = conf[c]['name']
        etype = conf[c]['entity_type']
        dtype_name = conf[c]['data_type_name']
        dtype_type = conf[c]['data_type_type']

        # custom EM label
        em_label = ename
        # DEPRECATED
        # if 'em_label' in conf[c]:
        #     em_label = conf[c]['em_label']

        ordered = 'ordered_factor' in conf[c] and conf[c]['ordered_factor']

        if 'composite_column' in conf[c] and conf[c]['composite_column']:
            # make composite column: a column that does not exist in the dataframe,
            # but rather is generated from multiple existing dataframe columns;
            if dtype_name == 'censored':
                c_use = str(uuid.uuid4())
                df[c_use] = make_censored_column(df, conf[c])
            else:
                raise ValueError('Composite columns of data_type: {} are not supported.'
                                 .format(dtype_name))
        # else:
        #     # skip configuration key, not a column in the dataframe and does not
        #     # represent a composite column.
        #     print 'Skipping configuration column {}, not found in tsv file.'.format(c)
        #     continue

        if dtype_name == 'factor':
            assert dtype_type in ('character', 'numeric'), 'factor must be numeric/character'
            dtype_dict = {'name': 'factor', 'ordered': ordered, 'type': dtype_type}

        elif dtype_name == 'numeric':
            dtype_dict = copy.deepcopy(ontology.NUMERIC)

        elif dtype_name == 'character':
            dtype_dict = copy.deepcopy(ontology.CHARACTER)

        elif dtype_name == 'censored':
            if 'censored_time_unit' not in conf[c]:
                raise ValueError('Column {} with "data_type_name": "censored" requires '
                                 'a "censored_time_unit" configuration key'.format(c))

            if conf[c]['censored_time_unit'] not in ('day', 'week', 'month', 'year'):
                raise ValueError('censored_time_unit value must be one of: day, week, month, year')

            dtype_dict = {
                'name': 'censored', 'type': 'json', 'time_unit': conf[c]['censored_time_unit']
            }

        else:
            raise ValueError('Unexpected dtype_name: {}'.format(dtype_name))

        if 'factor_levels' in conf[c]:
            dtype_dict['levels'] = conf[c]['factor_levels']
        elif 'levels' in conf[c]:
            dtype_dict['levels'] = conf[c]['levels']

        # Special treatment of character factors to defend against the
        # known pandas issue 'numeric column has NAs so it must be a float'
        if dtype_dict['name'] == 'factor' and dtype_dict['type'] == 'character':
            # Note: pandas reads a column with numbers as numeric data type (dtype).
            # Unfortunately, if the column has missing values / NAs the dtype will be
            # float even if the values look like 1, 2, 3. This causes problems in the
            # case where a column was written as a character factor with values like
            # '1', '2', '3' (strings, not numbers) and it has NA values. In this case,
            # unless we do the operation below the values will be re-written at the
            # end of this function as 1.0, 2.0, 3.0, and may NOT match the column's
            # header data_type.levels which likely are '1', '2', '3'.
            assert 'levels' in dtype_dict, 'Missing levels for a factor column: {}'.format(c)
            if c in df.columns:
                # Check if the values of a 'fixed' column version show greater overlap
                # with the levels than the original column values. If so, replace.
                lvl_vals = set([x['value'] for x in dtype_dict['levels']])
                col_vals = set(df[c].dropna())
                col_new = [try_fix_intlike_str(x) for x in df[c]]
                col_vals_new = set([x for x in col_new if x is not None])
                if len(lvl_vals & col_vals_new) > len(lvl_vals & col_vals):
                    df[c] = col_new

        custom_attrs = None
        if 'custom_attrs' in conf[c]:
            custom_attrs = conf[c]['custom_attrs']

        measurement = None
        if 'measurement' in conf[c]:
            assert type(conf[c]['measurement']) == dict
            measurement = conf[c]['measurement']

        #################
        # column domain #
        #################
        if etype == 'generic_entity':
            # generic_entity(s) use samples domain
            col_domain = samples_domain

        elif etype in domain_by_etype:
            # preset domains, just set
            col_domain = domain_by_etype[etype]

        elif etype == 'phenotype':
            # phenotype, get from phenotype_info
            if dtype_name == 'censored':
                col_domain = 'Clinical'
            else:
                assert_msg = 'Missing: phenotype_info for phenotype column: {}'.format(c)
                assert 'phenotype_info' in conf[c], assert_msg
                phenotype_domain = conf[c]['phenotype_info']['domain']
                assert_msg = 'Unexpected phenotype_info.domain: {}'.format(phenotype_domain)
                assert phenotype_domain in ontology.PHENOTYPE_DOMAINS, assert_msg
                col_domain = phenotype_domain

            # CONSIDER
            # replace phenotype_info with `domain_name` attribute that
            # is required for certain entity types, e.g. `phenotype`.

        elif etype == 'cell_type':
            # cell type, get from cell_type_info
            assert_msg = 'Missing: cell_type_info for cell_type column: {}'.format(c)
            assert 'cell_type_info' in conf[c], assert_msg
            cell_type_domain = conf[c]['cell_type_info']['domain']
            assert_msg = 'Unexpected cell_type_info.domain: {}'.format(cell_type_domain)
            assert cell_type_domain in ontology.CELL_TYPE_DOMAINS, assert_msg
            col_domain = cell_type_domain

            # CONSIDER
            # replace cell_type_info with `domain_name` attribute that
            # is required for certain entity types, e.g. `cell_type`.

        else:
            raise ValueError('Unknown domain for column {}'.format(c))

        # entity measurement
        d = {
            'data_type': dtype_dict,
            'entity': {
                'domain': {'name': col_domain},
                'type': etype,
                'name': ename,
                'label': ename,
            },
            'label': em_label,
        }

        # entity measurement label modifications;
        # derived from measurement.label_prefix/suffix
        if measurement:
            d['measurement'] = measurement
            if 'label_suffix' in measurement:
                assert 'em_label' not in conf[c]
                d['label'] = '{} {}'.format(d['label'], measurement['label_suffix'])
            if 'label_prefix' in measurement:
                assert 'em_label' not in conf[c]
                d['label'] = '{} {}'.format(measurement['label_prefix'], d['label'])

        # custom attributes
        if custom_attrs:
            # verify all custom attributes have string/unicode values
            assert all(isinstance(v, six.string_types) for k, v in custom_attrs.items()), '{}'.format(custom_attrs)
            d['custom_attrs'] = custom_attrs

        # sanity check: measurement of survival column
        if dtype_name == 'censored':
            assert ename == 'Survival' and etype == 'phenotype', '{}, {}'.format(ename, etype)
            assert measurement['label_prefix'] in ontology.SURVIVAL_LABEL_PREFIXES
            assert measurement['attrs']['survival']['type'] in ontology.SURVIVAL_TYPES

        if 'somatic_mutation' in conf[c] and conf[c]['somatic_mutation']:
            # somatic mutation
            d['label'] = '{} {}'.format(
                d['label'],
                ontology.MODIFICATION_LABELS['somatic_mutation'],
            )
            d['modification'] = copy.deepcopy(ontology.SOMATIC_MUTATION)
            if 'aa_change' in conf[c]:
                aa_change = conf[c]['aa_change']
                d['modification']['details']['aa_change'] = aa_change
                d['label'] = d['label'] + ' ' + aa_change

        elif 'rna_expression' in conf[c] and conf[c]['rna_expression']:
            # RNA-expression
            raise ValueError('rna_expression: Not yet supported.')

        elif 'methylation' in conf[c] and conf[c]['methylation']:
            # Methylation
            raise ValueError('methylation: Not yet supported.')

        elif 'hypermethylation' in conf[c] and conf[c]['hypermethylation']:
            # Hypermethylation
            raise ValueError('hypermethylation: Not yet supported.')

        elif 'copy_gain' in conf[c] and conf[c]['copy_gain']:
            # Copy-gain
            raise ValueError('copy_gain: Not yet supported.')

        elif 'copy_loss' in conf[c] and conf[c]['copy_loss']:
            # Copy-loss
            raise ValueError('copy_loss: Not yet supported.')

        # DEPRECATED
        # elif 'drug_treatment' in conf[c] and conf[c]['drug_treatment']:
        #     # Drug treatment - TO BE DEPRACATED
        #     d['label'] = '{} Treatment'.format(d['label'])

        # DEPRECATED
        # elif 'treatment' in conf[c] and conf[c]['treatment']:
        #     # Drug treatment (NEW), populate 'treatment' EM key
        #     d['treatment'] = conf[c]['treatment']
        #     if 'label' in d['treatment']:
        #         d['label'] = '{} {}'.format(d['label'], d['treatment']['label'])

        # DEPRECATED
        # elif 'effect' in conf[c]:
        #     # numeric / categoric drug response
        #     d['effect'] = conf[c]['effect']
        #     d['label'] = '{} {}'.format(d['label'], ontology.EFFECT_LABELS[conf[c]['effect']])

        # DEPRECATED
        # if 'label_suffix' in conf[c]:
        #     d['label'] = '{} {}'.format(d['label'], conf[c]['label_suffix'])

        #
        # Finally, save the constructed column json header
        #
        new_col_headers[c_use] = json.dumps(d, sort_keys=True)

    # keep only the columns referenced in the YAML config
    df = df[[x for x in df.columns if x in new_col_headers]]
    df = df.rename(columns=new_col_headers)

    if len(df.columns) == 0:
        sys.exit('\nZero columns matched config file.\n')

    if verbose:
        sys.stderr.write('\nFormatted {} data columns.\n'.format(df.shape[1]))

    # write
    commons.write_df_as_tbl(df, output_tbl)

    if verbose:
        sys.stderr.write('\nWrote data table (.tbl) file to: {}\n'.format(output_tbl))


def format_file(
    input_tsv,
    config,
    samples_domain,
    output_tbl,
    verbose=False,
):
    """Read tab-separated file containing metadata along with a YAML file specifying the column
    information, and write as BI tbl file.

    Parameters
    ----------
    input_tsv : str
        Path to input file containing metadata. Rows should correspond to samples and columns should
        correspond to metadata.
    config : str
        Path to input file yaml file containing configuration for metadata columns.
    samples_domain : str
        Domain of samples; e.g. your organization name.
    output_tbl: str
        Path to write tbl file to.
    verbose : bool, optional
        If True, print logging information to stderr.
    """
    metadata, conf = read(input_tsv, config, verbose)
    write(metadata, conf, samples_domain, output_tbl, verbose=verbose)
