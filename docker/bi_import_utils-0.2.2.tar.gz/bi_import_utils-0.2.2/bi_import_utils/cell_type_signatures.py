import json
import sys
import copy
import pandas as pd

from bi_import_utils import ontology
from bi_import_utils import commons

'''
Format a tab-separated data matrix with cell-type specific signatures as BI data table.

Note: gene names should correspond to HGNC gene names.

Copyright 2020 Data4Cure, Inc. All rights reserved.
'''

_col_domain = 'Cell Type'  # Expose as parameter if becomes useful


def read(input_tsv, transpose=False, verbose=False):
    """Read tab-separated file with cell-type specific signatures.
    
    Parameters
    ----------
    input_tsv : str
        Path to input file containing cell-type specific signatures. Rows should correspond to genes and
        columns should correspond to cell types.
    transpose : bool, optional
        Transpose matrix when reading; use if rows represent genes and columns represent samples.
    verbose : bool, optional
        If True, print logging information to stderr.
    
    Returns
    -------
    signatures : pandas.DataFrame
        Pandas dataframe containing cell-type specific signatures. Rows correspond to genes and columns
        correspond to cell types.
        
    """
    if verbose:
        sys.stderr.write('\nReading input from {}\n'.format(input_tsv))

    signatures = pd.read_csv(input_tsv, sep='\t', header=0, index_col=0,
                             na_values='NA', low_memory=False)
    if transpose:
        # reverse pandas mechanism to ensure column uniqueness and transpose matrix
        signatures = commons.remove_col_duplicates_pandas(signatures).T

    if verbose:
        sys.stderr.write('\nData dimensions: {}\n'.format(signatures.shape))

    return signatures


def process(signatures, use_ensembl=False, use_synonyms=True, duplicate_genes='first', verbose=False):
    """Process dataframe with cell-type specific signatures.
    
    Parameters
    ----------
    signatures : pandas.DataFrame
        Pandas dataframe containing cell-type specific signatures. Rows correspond to genes and columns
        correspond to cell types.
    use_ensembl : bool, optional
        If True, convert ENSEMBL ids (rows in the dataframe) to HGNC gene names.
    use_synonyms : bool, optional
        If True, try to match gene names in the dataframe to HGNC gene names using synonyms when
        possible.
    duplicate_genes : str, optional
        Duplicate genes selection. Default: first occurrence is kept.
        Other options are min/mean/median/max value from duplicate genes.
    verbose : bool, optional
        If True, print logging information to stderr.
    
    Returns
    -------
    signatures : pandas.DataFrame
        Pandas dataframe containing cell-type specific signatures where gene names have been converted to
        HGNC or dropped if not known. Rows correspond to genes and columns correspond to cell types.
    dropped_elements: pandas.DataFrame
        Pandas dataframe containing dropped genes and a reason for it. Rows correspond to genes and
        columns to various information.
    """
    # Create deepcopy of input matrix to avoid changing input object
    signatures = signatures.copy(deep=True)

    # reverse pandas mechanism to ensure uniqueness of column names
    signatures = commons.remove_col_duplicates_pandas(signatures)

    # ensure uniqueness of cell types
    if not signatures.columns.is_unique:
        raise Exception("\nError: duplicate cell types. Please make sure your input has unique cell type identifiers.")

    # prep, upper-case gene names
    signatures.index = [c.upper() for c in signatures.index]

    # create new dataframe for storing duplicates, not translated ids, etc.
    dropped_elements = pd.DataFrame(index=signatures.index).assign(
        HGNC_symbol=signatures.index, description=None)

    # remove duplicates, if any
    signatures, dropped_elements = commons.drop_duplicate_rows(
        signatures, dropped_elements=dropped_elements, duplicate_genes=duplicate_genes)

    if verbose:
        sys.stderr.write('\nData dimension after removing duplicates: {}\n'.format(signatures.shape))

    if use_ensembl:
        # converting ENSEMBL ids to HGNC gene names and remove duplicates
        signatures, dropped_elements = commons.translate_ensembl_ids_to_hgnc(
            signatures, dropped_elements, duplicate_genes=duplicate_genes)

        if verbose:
            sys.stderr.write('\nData dimension after converting ENSEMBL ids to HGNC gene names: {}\n'.format(
                signatures.shape))

    # HGNC name filtering/matching
    signatures, drop = commons.match_HGNC_names_cols(
        signatures, use_syn=use_ensembl or use_synonyms, use_rows=True)

    # annotate rows, which were translated to HGNC symbols, but didn't pass HGNC filtering
    mask_hgnc = dropped_elements.description.isnull() & dropped_elements.HGNC_symbol.isin(drop)
    dropped_elements.loc[mask_hgnc, 'description'] = 'HGNC conversion'

    # select rows, which were duplicated or weren't translated to HGNC symbols or didn't pass HGNC filtering (mask_hgnc)
    dropped_elements = dropped_elements.loc[~dropped_elements.description.isnull(), :]
    if not use_ensembl:
        # drop column with HGNC symbols since it's a duplicate of an index
        dropped_elements.drop('HGNC_symbol', axis=1, inplace=True)

    # notify user about number of dropped elements due to duplication reasons
    no_of_duplicated_elements = dropped_elements[dropped_elements.description == 'Duplicated'].shape[0]
    if duplicate_genes == 'first' and no_of_duplicated_elements > 0:
        sys.stderr.write(('\nNumber of dropped genes due to duplication: {}. Consider using '
                          '`duplicate_genes` option to aggregate them.\n'.format(no_of_duplicated_elements)))

    return signatures, dropped_elements


def write(signatures, dropped_elements, output_tbl, no_save_dropped=False, verbose=False):
    """Write processed dataframe with cell-type specific signatures to BI tbl file.
    
    Parameters
    ----------
    signatures : pandas.DataFrame
        Pandas dataframe containing cell-type specific signatures that has been processed to conform to BI
        gene names. Rows correspond to genes and columns correspond to cell types.
    dropped_elements: pandas.DataFrame
        Pandas dataframe containing dropped genes and a reason for it. Rows correspond to genes and
        columns to various information.
    output_tbl: str
        Path to write tbl file to.
    no_save_dropped : bool, optional
        Skip saving dropped elements to additional file. (default = False)
    verbose : bool, optional
        If True, print logging information to stderr.
    """
    # format BI table
    def row_json_gene(x):
        return {
            'entity': {
                'name': x,
                'label': x,
                'domain': copy.deepcopy(ontology.HGNC_DOMAIN),
                'type': ontology.GENE_TYPE,
            },
            'label': x,
        }

    def column_json_cell_type(x):
        return {
            'data_type': ontology.NUMERIC,
            'entity': {
                'name': x,
                'label': x,
                'type': ontology.CELL_TYPE_TYPE,
                'domain': {'name': _col_domain},
            },
            'label': x,
        }

    signatures.index = [json.dumps(row_json_gene(x), sort_keys=True) for x in signatures.index]
    signatures.columns = [json.dumps(column_json_cell_type(x), sort_keys=True) for x in signatures.columns]

    # write BI table
    commons.write_df_as_tbl(signatures, output_tbl)
    if verbose:
        sys.stderr.write('\nWrote data table (.tbl) file to: {}\n'.format(output_tbl))

    # Save dropped and aggregated elements to files
    if not no_save_dropped and not dropped_elements.empty:
        commons.write_dropped_aggregated_as_tsv(dropped_elements, output_tbl)


def format_file(input_tsv, output_tbl, use_ensembl=False, use_synonyms=True, transpose=False,
                no_save_dropped=False, duplicate_genes='first', verbose=False):
    """Read file containing with cell-type specific signatures and write as BI tbl file.
    
    Parameters
    ----------
    input_tsv : str
        Path to input file containing cell-type specific signatures.
    output_tbl: str
        Path to write tbl file to.
    use_ensembl : bool, optional
        If True, convert ENSEMBL ids (rows in the dataframe) to HGNC gene names.
    use_synonyms : bool, optional
        If True, try to match gene names in the dataframe to HGNC gene names using synonyms when
        possible.
    transpose : bool, optional
        Transpose matrix when reading; use if rows represent genes and columns represent samples.
    no_save_dropped : bool, optional
        Skip saving dropped elements to additional file. (default = False)
    duplicate_genes : str, optional
        Duplicate genes selection. Default: first occurrence is kept.
        Other options are min/mean/median/max value from duplicate genes.
    verbose : bool, optional
        If True, print logging information to stderr.
    """
    signatures = read(input_tsv, transpose, verbose)
    signatures, dropped_elements = process(signatures, use_ensembl, use_synonyms, duplicate_genes, verbose)
    write(signatures, dropped_elements, output_tbl, no_save_dropped, verbose)
