
# entity types
GENE_TYPE = 'gene'
TERM_TYPE = 'term'
PROTEIN_TYPE = 'protein'
DRUG_TYPE = 'drug'
FUSION_TYPE = 'gene_fusion'
HEALTH_CONDITION_TYPE = 'health_condition'
GENERIC_ENTITY_TYPE = 'generic_entity'
CELL_TYPE_TYPE = 'cell_type'

SURVIVAL_LABEL_PREFIXES = (
    'Overall',
    # '5-Year',
    # 'Event Free',
    'Disease Free',
    'Progression Free',
    'Disease Specific',
    'Duration of Response',
)

SURVIVAL_TYPES = (
    'overall',
    'progression_free',
    'disease_specific',
    'disease_free',
    'duration_of_response',
)

PHENOTYPE_DOMAINS = ('Clinical', 'Pathology')
CELL_TYPE_DOMAINS = ('Cell Type', 'Tissue')

# data types
NUMERIC = {
    'name': 'numeric',
    'type': 'numeric',
}

CHARACTER = {
    'name': 'character',
    'type': 'character',
}

CENSORED = {
    'name': 'censored',
    'type': 'json',
}

MUTATION_FACTOR = {
    'name': 'factor',
    'type': 'numeric',
    'levels': [{'value': 0, 'label': 'WT', }, {'value': 1, 'label': 'MT', }],
    'ordered': False,
}

FUSION_FACTOR = {
    'name': 'factor',
    'type': 'numeric',
    'levels': [{'value': 0, 'label': 'WT', }, {'value': 1, 'label': 'FUSION', }],
    'ordered': False,
}

CNV_FACTOR = {
    'name': 'factor',
    'type': 'numeric',
    'levels': [
        {'value': -2, 'label': 'HOM-LOSS'},
        {'value': -1, 'label': 'HET-LOSS'},
        {'value': 0, 'label': 'WT'},
        {'value': 1, 'label': 'GAIN'},
        {'value': 2, 'label': 'MULTI-COPY-GAIN'},
    ],
    'ordered': True,
}

CNV_LOSS_FACTOR = {
    'name': 'factor',
    'type': 'numeric',
    'levels': [
        {'value': 0, 'label': 'WT'},
        {'value': 1, 'label': 'LOSS'},
    ],
    'ordered': False,
}

CNV_GAIN_FACTOR = {
    'name': 'factor',
    'type': 'numeric',
    'levels': [
        {'value': 0, 'label': 'WT'},
        {'value': 1, 'label': 'GAIN'},
    ],
    'ordered': False,
}

HYPERMETHYLATION_FACTOR = {
    'name': 'factor',
    'type': 'numeric',
    'levels': [
        {'value': 0, 'label': 'NORM'},
        {'value': 1, 'label': 'HMET'},
    ],
    'ordered': False,
}

UNORDERED_NUMERIC_FACTOR = {
    'name': 'factor',
    'type': 'numeric',
    'ordered': False,
}

SEQUENCE_VARIATION = 'dna_sequence_variation'

EPIGENETIC_MODIFICATION = 'epigenetic_modification'

GENE_INTERFERENCE = 'gene_interference'

SOMATIC_MUTATION = {
    'type': SEQUENCE_VARIATION,
    'details': {'type': 'somatic_mutation'},
}

SNV = {
    'type': SEQUENCE_VARIATION,
    'details': {'type': 'single_nucleotide_variant'},
}

INDEL = {
    'type': SEQUENCE_VARIATION,
    'details': {'type': 'indel'},
}

VARIANT = {
    'type': SEQUENCE_VARIATION,
    'details': {'type': 'variant'},
}

METHYLATION = {
    'type': EPIGENETIC_MODIFICATION,
    'details': {'type': 'methylation'},
}

HYPERMETHYLATION = {
    'type': EPIGENETIC_MODIFICATION,
    'details': {'type': 'hypermethylation'},
}

GENE_INTERFERENCE_CRISPRi = {
    'type': GENE_INTERFERENCE,
    'details': {'type': 'CRISPRi'},
}

GENE_INTERFERENCE_RNAi = {
    'type': GENE_INTERFERENCE,
    'details': {'type': 'RNAi'},
}

# domains
HGNC_DOMAIN = {'name': 'HGNC'}
GENE_FUSION = {'name': 'Gene Fusions'}

# abundances
GENE_COPY_LOSS = 'gene_copy_loss'
GENE_COPY_GAIN = 'gene_copy_gain'
GENE_ABUNDANCE = 'gene_abundance'
RNA_ABUNDANCE = 'rna_abundance'
ABUNDANCE = 'abundance'
PROTEIN_ABUNDANCE = 'protein_abundance'
MICRORNA_ABUNDANCE = 'microrna_abundance'

ABUNDANCE_LABELS = {
    GENE_COPY_LOSS: 'CopyLoss',
    GENE_COPY_GAIN: 'CopyGain',
    GENE_ABUNDANCE: 'CopyNumber',
    RNA_ABUNDANCE: 'RNAAbundance',
    ABUNDANCE: 'Abundance',
    PROTEIN_ABUNDANCE: 'ProteinAbundance',
    MICRORNA_ABUNDANCE: 'microRNAAbundance',
}

INTERFERENCE_LABELS = {
    'CRISPRi': 'CRISPRi',
    'RNAi': 'RNAi'
}


def abundance_label(x):
    return ABUNDANCE_LABELS[x]


MODIFICATION_LABELS = {
    'somatic_mutation': 'SomaticMutation',
    'methylation': 'Methylation',
    'hypermethylation': 'Hypermethylation',
    'single_nucleotide_variant': 'SNV',
    'indel': 'Indel',
    'variant': 'Variant',
    'fusion': 'GeneFusion',
}


def modification_label(d):
    res = MODIFICATION_LABELS[d['details']['type']]

    if 'rsid' in d['details']:
        res += ' %s' + d['details']['rsid']

    if 'aa_change' in d['details']:
        res += ' ' + d['details']['aa_change']

    return res

DRUG_RESPONSE_GI50 = 'drug_response_GI50'
DRUG_RESPONSE_IC50 = 'drug_response_IC50'
DRUG_RESPONSE_ACTAREA = 'drug_response_actArea'
DRUG_RESPONSE_TRUE = 'drug_response_True'
DRUG_RESPONSE_AUC = 'drug_response_AUC'
DRUG_RESPONSE_M_AUC = 'drug_response_-AUC'
DRUG_RESPONSE_ATARIS_SCORE = 'drug_response_ATARiS Score'
DRUG_RESPONSE_M_SERES_SCORE = 'drug_response_-SERES Score'
DRUG_RESPONSE_M_DEMETER_SCORE = 'drug_response_-DEMETER Score'

DRUG_RESPONSE_BINARY = 'drug_response_binary'
DRUG_RESPONSE_BEST_OVERALL = 'drug_response_best_overall'

EFFECT_LABELS = {
    DRUG_RESPONSE_GI50: 'response (-log GI50)',
    DRUG_RESPONSE_IC50: 'response (-log IC50)',
    DRUG_RESPONSE_ACTAREA: 'response (actArea)',
    DRUG_RESPONSE_TRUE: 'response (actArea)',
    DRUG_RESPONSE_AUC: 'response (AUC)',
    DRUG_RESPONSE_M_AUC: 'response (-AUC)',
    DRUG_RESPONSE_ATARIS_SCORE: 'response (ATARiS Score)',
    DRUG_RESPONSE_M_SERES_SCORE: 'response (-SERES Score)',
    DRUG_RESPONSE_M_DEMETER_SCORE: 'response (-DEMETER Score)',
    DRUG_RESPONSE_BINARY: 'Response',
    DRUG_RESPONSE_BEST_OVERALL: 'Best Overall Response',
}
