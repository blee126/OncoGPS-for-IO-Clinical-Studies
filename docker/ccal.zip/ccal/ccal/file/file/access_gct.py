from pandas import read_table

from .support.support.path import establish_path


def read_gct(file_path, drop_description=True):
    """
    Read .gct file.
    Arguments:
        file_path (str): .gct file path
        drop_description (bool): whether to drop 'Description' column
    Returns:
        DataFrame: [n_samples, n_features (+1 if drop_description == False)]
    """

    # Read .gct file
    df = read_table(file_path, skiprows=2)

    # Get first 2 columns
    c0, c1 = df.columns[:2]

    # Check if the 1st column is 'Name'; if so set it as the index
    if c0 == 'Name':
        df.set_index('Name', inplace=True)
    else:
        if c0.strip() == 'Name':
            raise ValueError('Strip extra spaces surrounding \'Name\'.')
        else:
            raise ValueError('Column 0 != \'Name\'.')

    # Check if the 2nd column is 'Description'; drop it if drop_description
    if c1 == 'Description':
        if drop_description:
            df.drop('Description', axis=1, inplace=True)
    else:
        if c1.strip() == 'Description':
            raise ValueError('Strip extra spaces surrounding \'Description\'.')
        else:
            raise ValueError('Column 1 != \'Description\'')

    return df


def write_gct(df, file_path, descriptions=()):
    """
    Write .gct file.
    Arguments:
        df (DataFrame): (n_samples, n_features); .gct DataFrame
        file_path (str): file path to write .gct DataFrame
        descriptions (iterable): (n_samples); 'Description' column
    Returns:
        None
    """

    # Copy
    df = df.copy()

    # Add 'Description' column if missing
    if df.columns[0] != 'Description':
        if len(descriptions):
            df.insert(0, 'Description', descriptions)
        else:
            df.insert(0, 'Description', df.index)

    # Set row & column names
    df.index.name = 'Name'
    df.columns.name = None

    # Write .gct file
    if not file_path.endswith('.gct'):
        file_path += '.gct'
    establish_path(file_path)
    with open(file_path, 'w') as f:

        f.writelines('#1.2\n{}\t{}\n'.format(df.shape[0], df.shape[1] - 1))
        df.to_csv(f, sep='\t')
