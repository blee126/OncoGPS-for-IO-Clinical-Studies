from pandas import DataFrame, concat

from .support.support.path import establish_path


def read_gmts(file_paths,
              sets=(),
              drop_description=True,
              save_clean=False,
              collapse=False):
    """
    Read .gmt files.
    Arguments:
        file_paths (iterable): .gmt file paths
        sets (iterable): set names to reads
        drop_description (bool): whether to drop 'Description' column
        collapse (bool): whether to collapse elements into a list
    Returns:
        DataFrame | list: (n_sets, size_largest_set) | (n_unique_elements)
    """

    # Read each .gmt file
    dfs = []
    for fp in file_paths:

        # Parse and read sets
        lines = []
        with open(fp) as f:
            for line in f:
                split = line.strip().split('\t')
                lines.append(split[:2] + sorted(
                    [g for g in set(split[2:]) if g]))

        # Make .gmt DataFrame
        dfs.append(DataFrame(lines))

    # Combine .gmt dfs
    df = concat(dfs).set_index(0).sort_index()
    df.index.name = 'Gene Set'

    # Drop 'Description' column
    if drop_description or collapse:
        df.drop(1, axis=1, inplace=True)
        df.columns = ['Gene {}'.format(i) for i in range(0, df.shape[1])]

    else:
        df.columns = ['Description'] + [
            'Gene {}'.format(i) for i in range(0, df.shape[1] - 1)
        ]

    # Keep specific sets
    if len(sets):
        df = df.ix[sorted(df.index & sets)].dropna(axis=1, how='all')

    if collapse:
        # Collapse sets into 1 gene list
        return sorted(set(df.unstack().dropna()))

    else:
        return df


def write_gmt(df, file_path, descriptions=()):
    """
    Write .gmt file.
    Arguments:
        df (DataFrame): .gmt DataFrame
        file_path (str): file path to write .gmt DataFrame
        descriptions (iterable): (n_samples); 'Description' column
    Returns:
        None
    """

    df = df.copy()

    # Add 'Description' column if missing
    if df.columns[0] != 'Description':
        if len(descriptions):
            df.insert(0, 'Description', descriptions)
        else:
            df.insert(0, 'Description', df.index)

    # Write .gmt
    if not file_path.endswith('.gmt'):
        file_path += '.gmt'
    establish_path(file_path)
    df.to_csv(file_path, header=None, sep='\t')
