from random import seed

from numpy import array
from numpy.random import randint, random_sample
from pandas import DataFrame

RANDOM_SEED = 20121020


def drop_df_slices(df,
                   axis,
                   only_obj=None,
                   max_n_unique_objects=None,
                   print_dropped_slices=False):
    """
    Drop df slices.
    Arguments:
        df (DataFrame):
        axis (int): 0 | 1
        only_obj (object):
        max_n_unique_objects (int): 0 < max_n_unique_objects
    Returns:
        DataFrame:
    """

    if only_obj is None and max_n_unique_objects is None:
        raise ValueError('Provide either only_obj or max_n_unique_objects.')

    # Select slices to be dropped
    dropped = array([False] * df.shape[[1, 0][axis]])

    if only_obj is not None:
        dropped |= (df == only_obj).all(axis=axis)

    if 0 < max_n_unique_objects:
        dropped |= df.apply(
            lambda s: s.unique().size <= max_n_unique_objects, axis=axis)

    # Drop
    print('Dropping {} axis-{} slices ...'.format(dropped.sum(), axis))

    if print_dropped_slices:
        print('* ======= Dropped slices ======= *')
        print(df.index[dropped].tolist())
        print('* ============================== *')

    if axis == 0:
        return df.loc[:, ~dropped]

    elif axis == 1:
        return df.loc[~dropped, :]


def split_df(df, n_split, axis=0):
    """
    Split df.
    Arguments:
        df (DataFrame):
        n_split (int): 0 < n_split <= n_rows
        axis (int): 0 | 1
    Returns:
        list: DataFrames
    """

    if axis not in (0, 1):
        raise ValueError('Unknown axis: {}.'.format(axis))

    if not (0 < n_split <= df.shape[axis]):
        raise ValueError('Invalid: 0 < n_split ({}) <= n_slices ({})'.format(
            n_split, df.shape[axis]))

    n = df.shape[axis] // n_split

    list_ = []

    for i in range(n_split):
        start_i = i * n
        end_i = (i + 1) * n

        if axis == 0:
            list_.append(df.iloc[start_i:end_i, :])

        elif axis == 1:
            list_.append(df.iloc[:, start_i:end_i])

    # Get leftovers (if any)
    i = n * n_split
    if i < df.shape[axis]:

        if axis == 0:
            list_.append(df.iloc[i:, :])

        elif axis == 1:
            list_.append(df.iloc[:, i:])

    return list_


def simulate_df(n_rows,
                n_cols,
                n_categories=None,
                index_prefix='Index ',
                column_prefix='Column ',
                random_seed=RANDOM_SEED):
    """
    Simulate DataFrame.
    Arguments:
        n_rows (int): number of rows
        n_cols (int): number of columns
        n_categories (None | int): None (for continuous) | int (for categorical)
        index_prefix (str): prefix for index
        column_prefix (str): prefix for column
        random_seed (int | array):
    Returns:
        DataFrame: (n_rows, n_cols)
    """

    seed(random_seed)

    if n_categories:
        df = DataFrame(randint(0, n_categories, (n_rows, n_cols)))

    else:
        df = DataFrame(random_sample((n_rows, n_cols)))

    df.index = ['{}{}'.format(index_prefix, i) for i in range(n_rows)]
    df.columns = ['{}{}'.format(column_prefix, i) for i in range(n_cols)]

    return df
