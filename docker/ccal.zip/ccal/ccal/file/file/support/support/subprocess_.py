from subprocess import PIPE, CalledProcessError, Popen, run

from .exit_ import exit_


def run_command(command, print_command=False):
    """
    Run command.
    Arguments:
        command (str):
        print_command (bool):
    Returns:
        Popen:
    """

    if print_command:
        print('{}'.format(command))

    return run(
        command,
        shell=True,
        stdout=PIPE,
        stderr=PIPE,
        check=True,
        universal_newlines=True)


def run_command_and_monitor(command, print_command=False):
    """
    Run command and monitor.
    Arguments:
        command (str):
        print_command (bool):
    Returns:
        None
    """

    if print_command:
        print('{}'.format(command))

    p = Popen(
        command, shell=True, stdout=PIPE, stderr=PIPE, universal_newlines=True)

    for line in p.stdout:
        print(line.strip())

    if p.poll():
        exit_(
            '\n'.join(p.stderr),
            exception=CalledProcessError(
                p.returncode, command, stderr=p.stderr))
