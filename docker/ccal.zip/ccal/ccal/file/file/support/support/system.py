from .subprocess_ import run_command


def shutdown():
    """
    Shutdown.
    Arguments:
        None
    Retuns:
        None
    """

    run_command('sudo shutdown -h now')


def reboot():
    """
    Reboot.
    Arguments:
        None
    Retuns:
        None
    """

    run_command('sudo reboot')
