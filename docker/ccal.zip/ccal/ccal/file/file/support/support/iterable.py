from numpy import asarray, mean, where


def group(iterable, n, keep_leftover_group=False):
    """
    Make a list of groups, each containing n objects from iterable in order.
    Arguments:
        iterable (iterable): whose objects will be grouped
        n (int): number of objects in a group
        keep_leftover_group (bool): whether to keep the partialy-leftover group
    Returns:
        list: groups, each containing n objects form iterable in order
    """

    list_ = []

    group = []
    for o in iterable:

        group.append(o)

        if len(group) == n:
            list_.append(group)
            group = []

    # Handle leftover
    if len(group) != 0 and (len(group) == n or keep_leftover_group):
        list_.append(group)

    return list_


def flatten_nested(iterable, iterable_types=(list, tuple)):
    """
    Flatten an arbitrarily-deep nested iterable by depth-first flattening.
    Arguments:
        iterable (iterable): objects
        iterable_types (iterable): types to be flattened
    Returns:
        list: flattened list
    """

    list_ = list(iterable)

    i = 0
    while i < len(list_):

        while isinstance(list_[i], iterable_types):

            if not list_[i]:  # Skip empty iterable
                list_.pop(i)
                i -= 1
                break

            else:  # Deepen
                list_[i:i + 1] = list_[i]

        i += 1

    return list_


def replace_bad_objects(iterable,
                        bad_objects=('--', 'unknown', 'n/a', 'N/A', 'na', 'NA',
                                     'nan', 'NaN', 'NAN'),
                        replacement=None):
    """
    Replace bad objects with replacement.
    Arguments:
        iterable (iterable): objects
        bad_objects (iterable): objects
        replacement (object):
    Returns:
        list:
    """

    return [where(o in bad_objects, replacement, o) for o in iterable]


def integize(iterable):
    """
    Integize iterable's objects.
    Arguments:
        iterable (iterable): objects
    Returns:
        list: ints
    """

    # Assign objects to ints
    o_to_i = {}
    for i, o in enumerate(sorted(set(iterable))):
        o_to_i[o] = i

    # Map objects to ints and return
    return [o_to_i[o] for o in iterable]


def group_and_apply_function_on_each_group(iterable, groups, function=mean):
    """
    Group iterables and apply function on each group.
    Arguments:
        iterable (iterable): (n)
        groups (iterable): (n)
        function (callable):
    Returns:
        list: (n_groups)
        list: (n_groups)
    """

    unique_groups_in_order = get_unique_objects_in_order(groups)

    applied_by_group = []

    for g in unique_groups_in_order:

        applied_by_group.append(function(asarray(iterable)[groups == g]))

    return unique_groups_in_order, applied_by_group


def get_unique_objects_in_order(iterable):
    """
    Get unique objects in the order of their appearance in iterable.
    Arguments:
        iterable (iterable): objects
    Returns:
        list: (n_unique_objects); unique objects ordered by their appearances
            in iterable
    """

    unique_objects_in_order = []

    for o in iterable:

        if o not in unique_objects_in_order:
            unique_objects_in_order.append(o)

    return unique_objects_in_order
