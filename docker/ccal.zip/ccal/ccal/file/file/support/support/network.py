from os import getcwd
from os.path import join
from socket import AF_INET, SOCK_STREAM, socket
from urllib.request import urlretrieve

from .path import establish_path


def download(url, directory_path=None):
    """
    Download url content.
    Arguments:
        url (str):
        directory_path (str): directory path to download into
    Returns:
        str: file path to the downloaded content
    """

    if not directory_path:
        directory_path = getcwd()

    file_name = url.split('/')[-1].split('?')[0]
    file_path = join(directory_path, file_name)

    establish_path(file_path)

    urlretrieve(url, file_path)

    return file_path


def get_open_port():
    """
    Get an open port.
    Arguments:
        None
    Returns:
        int:
    """

    s = socket(AF_INET, SOCK_STREAM)

    s.bind(('', 0))

    port = s.getsockname()[1]

    s.close()

    return port
