from gzip import open as gzip_open
from os import rename
from os.path import dirname
from shutil import copyfileobj
from tarfile import open as tarfile_open
from zipfile import ZipFile

from Bio.bgzf import open as bgzf_open


def unzip(zip_file_path):
    """
    Unzip zip_file_path.
    Arguments:
        zip_file_path (str):
    Returns:
        None
    """

    # TODO: preserve permissions

    with ZipFile(zip_file_path, 'r') as zip_f:
        zip_f.extractall(dirname(zip_file_path))


def extract_tar(tar_file_path):
    """
    Extract tar_file_path.
    Arguments:
        tar_file_path (str):
    Retuns:
        None
    """

    with tarfile_open(tar_file_path) as tar_f:
        tar_f.extractall(dirname(tar_file_path))


def gzip_compress(file_path):
    """
    Gzip compress file_path.
    Arguments:
        file_path (str):
    Returns:
        str:
    """

    with open(file_path, 'rb') as f:

        gzip_file_path = file_path + '.gz'

        with gzip_open(gzip_file_path + '.tmp', 'wb') as gzip_f:

            copyfileobj(f, gzip_f)

    rename(gzip_file_path + '.tmp', gzip_file_path)

    return gzip_file_path


def gzip_decompress(gzip_file_path):
    """
    Gzip decompress gzip_file_path.
    Arguments:
        gzip_file_path (str):
    Returns:
        str:
    """

    with gzip_open(gzip_file_path, 'rt') as gzip_f:

        file_path = gzip_file_path[:-3]

        with open(file_path + '.tmp', 'wt') as f:

            copyfileobj(gzip_f, f)

    rename(file_path + '.tmp', file_path)

    return file_path


def gzip_decompress_and_bgzip_compress(gzip_file_path):
    """
    Gzip decompress and bgzip compress gzip_file_path.
    Arguments:
        gzip_file_path (str):
    Returns:
        str:
    """

    with gzip_open(gzip_file_path, 'rb') as gzip_f:

        bgzip_file_path = gzip_file_path

        with bgzf_open(bgzip_file_path + '.tmp', 'wb') as bgzip_f:

            copyfileobj(gzip_f, bgzip_f)

    rename(bgzip_file_path + '.tmp', bgzip_file_path)

    return bgzip_file_path
