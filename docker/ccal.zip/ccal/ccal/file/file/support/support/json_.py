from json import dump, load

INDENT = 2


def read_json(json_file_path):
    """
    Read .json file.
    Arguments:
        json_file_path (str):
    Returns:
        dict
    """

    with open(json_file_path, 'r') as f:
        dict_ = load(f)

    return dict_


def write_json(json_dict, json_file_path):
    """
    Read .json file.
    Arguments:
        json_dict (dict):
        json_file_path (str):
    Returns:
        None
    """

    with open(json_file_path, 'w') as f:
        dump(json_dict, f, indent=INDENT)
