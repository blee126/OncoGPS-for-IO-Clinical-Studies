from sys import exit

from .log import echo_or_print


def exit_(text, exception=None):
    """
    Echo or print message and exit.
    Arguments:
        text (str):
        exception (exception):
    Returns:
        None
    """

    echo_or_print('Uh oh :( ... {}'.format(text), fg='red', bg='black')

    if exception is None:
        exit()
    else:
        raise exception
