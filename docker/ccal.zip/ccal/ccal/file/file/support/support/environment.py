from os import uname

from pip import get_installed_distributions, main

from .str_ import cast_str_to_builtins
from .subprocess_ import run_command


def get_shell_environment():
    """
    get shell environment.
    Arguments:
        None
    Returns:
        dict:
    """

    environemnt = {}

    for line in run_command('env').stdout.split('\n'):

        if not line or line.strip().startswith(':'):
            continue

        k, v = line.split('=', 1)
        k = k.strip()
        v = v.strip()

        environemnt[k] = v

        print('{} ==> {}'.format(k, v))

    return environemnt


def install_libraries(libraries):
    """
    Install libraries that are not already installed.
    Arguments:
        libraries (iterable):
    Returns:
        None
    """

    # Get currently installed libraries
    libraries_installed = [lib.key for lib in get_installed_distributions()]

    # Install libraries not found in the currently installed libraries
    for lib in libraries:
        if lib not in libraries_installed:
            print('Installing {} ...'.format(lib))
            main(['install', lib])
        else:
            print('{} is already installed.'.format(lib))


def get_reference(obj, namespace):
    """
    If obj is in namespace, return its reference. Else cast it with built-in
        types. Unknown obj will be casted as str.
    Arguments:
        obj (object):
        namespace (dict): {ref: obj, ...}
    Returns:
        int | float | bool | str:
    """

    for r, o in namespace.items():
        if obj is o:
            # obj is an existing obj
            return r

    # obj is a built-in type (or not in the namespace)
    return cast_str_to_builtins(obj)


def have_programs(program_names):
    """
    Check if the current environment have program_names.
    Arguments:
        program_names (iterable):
    Returns:
        bool:
    """

    for n in program_names:

        if not run_command('which {}'.format(n)).stdout.strip():
            return False

    return True


def get_machine():
    """
    Get machine.
    Arguments:
        None
    Returns:
        str:
    """

    uname_ = uname()

    return '{}_{}'.format(uname_.sysname, uname_.machine)
