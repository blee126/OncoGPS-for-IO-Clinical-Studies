from datetime import datetime
from io import UnsupportedOperation
from logging import FileHandler, Formatter, StreamHandler, getLogger
from random import choice

from click import secho


def get_now(only_time=False):
    """
    Get the current datetime.
    Arguments:
        only_time (bool): whether to show only time
    Returns:
        str: year-month-date hour-minute-second or hour-minute-second
    """

    if only_time:
        formatter = '%H:%M:%S'
    else:
        formatter = '%Y-%m-%d %H:%M:%S'

    return datetime.now().strftime(formatter)


def initialize_logger(name):
    """
    Initialize a logger.
    Arguments:
        name (str): logger name
    Returns:
        Logger:
    """

    logger = getLogger(name)

    logger.setLevel(10)

    fh = FileHandler(
        '/var/tmp/{}.{:%Y:%m:%d:%H:%M:%S}.log'.format(name, datetime.now()))
    fh.setFormatter(
        Formatter('%(asctime)s|%(levelname)s: %(message)s\n', '%H%M%S'))
    logger.addHandler(fh)

    sh = StreamHandler()
    sh.setFormatter(Formatter('%(levelname)s: %(message)s\n'))
    logger.addHandler(sh)

    logger.info('Initialized {} logger.'.format(name))

    return logger


def echo_or_print(text,
                  prefix='Uh oh :( ... ',
                  fg=None,
                  bg=None,
                  bold=None,
                  dim=None,
                  underline=None,
                  blink=None,
                  reverse=None,
                  reset=True):
    """
    Print message in color and exit. Available colors are: "black" | "red" |
        "green" | "yellow" | "blue" | "magenta" | "cyan" | "white"
    Arguments:
        text (str): the string to style with ansi codes
        prefix (str): str added before the text
        fg (str): if provided this will become the foreground color
        bg (str): if provided this will become the background color
        bold (bool): if provided this will enable or disable bold mode
        dim (bool): if provided this will enable or disable dim mode
        underline (bool): if provided this will enable or disable underline
        blink (bool): if provided this will enable or disable blinking
        reverse (bool): if provided this will enable or disable inverse rendering
            (foreground becomes background and the other way round)
        reset (bool): by default a reset-all code is added at the end of the
            string which means that styles do not carry over
    Returns:
        None
    """

    if fg == 'random':
        fg = choice([
            # 'red',
            'green',
            'yellow',
            'blue',
            'magenta',
            'cyan',
            'white',
        ])
        bg = 'black'

    try:
        secho(
            text,
            fg=fg,
            bg=bg,
            bold=bold,
            dim=dim,
            underline=underline,
            blink=blink,
            reverse=reverse,
            reset=reset)

    except UnsupportedOperation:
        print(text)
