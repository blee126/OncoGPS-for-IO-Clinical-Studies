from os.path import join

from .str_ import is_version
from .subprocess_ import run_command


def create_gitkeep(directory_path):
    """
    Create .gitkeep.
    Arguments:
        directory_path (str):
    Returns:
        None
    """

    open(join(directory_path, '.gitkeep'), 'w').close()

    print('Created {}.'.format(join(directory_path, '.gitkeep')))


def get_git_versions(sort=True):
    """
    Get git versions.
    Arguments:
        sort (bool):
    Returns:
        list:
    """

    tags = run_command('git tag --list').stdout.strip().split('\n')
    versions = [t for t in tags if is_version(t)]

    if sort:
        versions.sort(key=lambda iii: [int(i) for i in iii.split('.')])

    return versions


def standardize_git_url(git_url):
    """
    Standardize git URL.
    Arguments:
        git_url (str):
    Returns:
        str:
    """

    if git_url.endswith('/'):
        git_url = git_url[:-1]

    if git_url.endswith('.git'):
        git_url = git_url[:-4]

    return git_url
