from math import ceil
from random import seed

from numpy.random import randint, random_sample
from pandas import DataFrame, Series

from .iterable import replace_bad_objects
from .str_ import cast_str_to_builtins

RANDOM_SEED = 20121020


def cast_series_to_builtins(series):
    """
    Cast series objects in the order of int, float, bool, and str, returning
        the 1st successful casting.
    Arguments:
        series (Series): (n)
    Returns:
        Series: (n)
    """

    list_ = replace_bad_objects([cast_str_to_builtins(o) for o in series])

    try:
        return Series(list_, index=series.index, dtype=float)

    except TypeError as e:
        print(e)

    except ValueError as e:
        print(e)

    return Series(list_, index=series.index)


def make_membership_df_from_categorical_series(series):
    """
    Make a object-x-sample binary membership DataFrame from categorical series.
    Arguments:
        s (Series): (n_samples)
    Returns:
        DataFrame: (n_unique_objects, n_samples)
    """

    o_x_index = DataFrame(index=sorted(set(series)), columns=series.index)

    for o in o_x_index.index:
        o_x_index.loc[o] = (series == o).astype(int)

    return o_x_index


def get_top_and_bottom_series_indices(series, threshold):
    """
    Get top and bottom series indices.
    Arguments:
        series (Series):
        threshold (number): quantile if 0.5 < threshold < 1; ranking number if
            1 <= threshold
    Returns:
        Index: indices for the top and bottom objects
    """

    if 0.5 <= threshold < 1:

        top_and_bottom = (series <= series.quantile(1 - threshold)) | (
            series.quantile(threshold) <= series)

    elif 1 <= threshold:

        threshold = min(threshold, ceil(series.size / 2))

        rank = series.rank(method='dense')

        top_and_bottom = (rank <= threshold) | (
            (rank.max() - threshold) < rank)

    else:
        raise ValueError('threshold must be 0.5 <=.')

    return series.index[top_and_bottom]


def simulate_series(size,
                    n_categories=None,
                    name='Simulated Series',
                    index_prefix='Index ',
                    random_seed=RANDOM_SEED):
    """
    Simulate a Series.
    Arguments:
        size (int): size
        n_categories (None | int): None for continuous and int for categorical
        index_prefix (str): index prefix
        random_seed (int | array):
    Returns;
        Series: (size)
    """

    seed(random_seed)

    if n_categories:
        series = Series(randint(low=0, high=n_categories - 1, size=size))

    else:
        series = Series(random_sample(size))

    series.name = name

    series.index = ['{}{}'.format(index_prefix, i) for i in range(size)]

    return series
