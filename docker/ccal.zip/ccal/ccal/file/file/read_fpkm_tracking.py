from pandas import read_table


def read_fpkm_tracking(file_path, prefix=None):
    """
    Read .fpkm_tracking file (cufflinks output) and average gene values.
    Arguments:
        file_path (str):
        prefix (str):
    Returns:
        Series: (n_unique_genes)
    """

    df = read_table(file_path, index_col='gene_short_name')['FPKM']

    s = df.ix[df.index != '-'].groupby(level=0).mean().squeeze()

    if prefix:
        s.name = '{} FPKM'.format(prefix)

    return s
