from random import choice


def make_random_color():
    """
    Make a random color.
    Arguments:
        None
    Returns:
        str: hexcolor
    """

    return '#' + ''.join([choice('0123456789ABCDEF') for x in range(6)])
