from numpy import concatenate, where

from .cluster_2d_array_rows import cluster_2d_array_rows
from .get_1d_array_unique_objects_in_order import \
    get_1d_array_unique_objects_in_order


def cluster_2d_array_slices_by_group(array_2d, groups):
    """
    Cluster array_2d slices by group.
    Arguments:
        array_2d (array): (n_rows, n_columns)
        groups (array): (n_rows | n_columns); sorted group labels
    Returns:
        array: (n_rows | n_columns)
    """

    indices = []

    for i in get_1d_array_unique_objects_in_order(groups):

        group_indices = where(groups == i)[0]

        if groups.size == array_2d.shape[0]:

            clustered_indices = cluster_2d_array_rows(
                array_2d[group_indices, :])

        elif groups.size == array_2d.shape[1]:

            clustered_indices = cluster_2d_array_rows(
                array_2d[:, group_indices].T)

        else:
            raise ValueError(
                'groups length does not match the length of array_2d rows or columns.'
            )

        indices.append(group_indices[clustered_indices])

    return concatenate(indices)
