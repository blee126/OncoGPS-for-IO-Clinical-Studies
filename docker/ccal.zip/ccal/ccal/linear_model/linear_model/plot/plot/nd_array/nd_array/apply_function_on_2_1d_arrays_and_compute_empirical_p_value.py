from numpy import array, empty
from numpy.random import seed, shuffle

from .compute_empirical_p_value import compute_empirical_p_value

RANDOM_SEED = 20121020


def apply_function_on_2_1d_arrays_and_compute_empirical_p_value(
        array_1d_0,
        array_1d_1,
        function,
        direction,
        n_permutations=100,
        random_seed=RANDOM_SEED):
    """
    Apply function(array_1d_0, array_1d_1) and compute empirical p-value.
    Arguments:
        array_1d_0 (array): (n)
        array_1d_1 (array): (n)
        function (callable): function(array_1d_0, array_1d_1) ==> number
        direction (str): for deciding p-value computing side; 'left' | 'right'
        n_permutations (int): number of permutations
        random_seed (int | array):
    Returns:
        float: score
        float: p-value
    """

    value = function(array_1d_0, array_1d_1)

    random_values = empty(n_permutations)

    shuffled_array_1d_0 = array(array_1d_0)

    seed(random_seed)
    for i in range(n_permutations):

        shuffle(shuffled_array_1d_0)
        random_values[i] = function(shuffled_array_1d_0, array_1d_1)

    p_value = compute_empirical_p_value(value, random_values, direction)

    return value, p_value
