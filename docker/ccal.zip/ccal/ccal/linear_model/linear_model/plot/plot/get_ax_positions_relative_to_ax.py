def get_ax_positions_relative_to_ax(ax):
    """
    Get ax positions relative to the ax itself.
    Arguments:
        ax:
    Returns:
        float:
        float:
        float:
        float:
    """

    ax_x_min, ax_x_max = ax.get_xlim()
    ax_y_min, ax_y_max = ax.get_ylim()

    return ax_x_min, ax_x_max, ax_y_min, ax_y_max
