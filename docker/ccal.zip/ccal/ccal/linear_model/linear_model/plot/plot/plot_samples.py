from matplotlib.colorbar import ColorbarBase
from matplotlib.colors import NoNorm, Normalize
from matplotlib.pyplot import figure, show
from numpy import array, cos, linspace, pi, sin
from pandas import Series, isnull

from .decorate import decorate
from .get_ax_positions_relative_to_ax import get_ax_positions_relative_to_ax
from .get_ax_positions_relative_to_figure import \
    get_ax_positions_relative_to_figure
from .nd_array.nd_array.normalize_1d_array import normalize_1d_array
from .save_plot import save_plot
from .style import (CMAP_BINARY_WB, CMAP_CATEGORICAL_TAB20,
                    CMAP_CONTINUOUS_BWR, FIGURE_SIZE)


def plot_samples(sample_x_dimension,
                 sample_x_annotation=None,
                 annotation_types=None,
                 annotation_max_stds=None,
                 annotation_color_maps=None,
                 annotation_ranges=None,
                 annotation_to_strs=None,
                 ax=None,
                 figure_size=FIGURE_SIZE,
                 samples_to_be_emphasized=None,
                 nonemphasized_sample_alpha=0.08,
                 sample_marker_style={
                     'markersize': 28,
                     'markeredgewidth': 0.8,
                     'markeredgecolor': '#000726',
                 },
                 plot_sample_text=False,
                 sample_text_style={
                     'fontsize': 18,
                     'weight': 'bold',
                     'color': '#000726',
                 },
                 legend_marker_style={
                     'markersize': 28,
                     'markeredgewidth': 0.8,
                     'markeredgecolor': '#4E41D9',
                 },
                 legend_text_style={
                     'fontsize': 18,
                     'rotation': 45,
                     'horizontalalignment': 'right',
                     'verticalalignment': 'top',
                     'weight': 'bold',
                     'color': '#4E41D9',
                 },
                 sample_z_order=0,
                 legend_z_order=0,
                 file_path=None):
    """
    Plot samples and their annotations.
    Arguments:
        sample_x_dimension (DataFrame): (n_samples, 2)
        sample_x_annotation (DataFrame): (n_samples, n_annotations); numbers
        annotation_types (iterable): (n_annotations); strs; 'continuous' |
            'categorical' | 'binary'
        annotation_max_stds (iterable): (n_annotations)
        annotation_color_maps (iterable): (n_annotations); matplotlib.cms
        annotation_ranges (iterable): (n_annotations); [[min, max], ...]
        annotation_to_strs (iterable): (n_annotations); dicts
        ax (matplotlib.Ax):
        figure_size (iterable):
        samples_to_be_emphasized (iterable):
        nonemphasized_sample_alpha (float):
        sample_marker_style (dict):
        plot_sample_text (bool): whether to plot sample names
        sample_text_style (dict):
        legend_marker_style (dict):
        legend_text_style (dict):
        sample_z_order (int):
        legend_z_order (int):
        file_path (str):
    Returns:
        None
    """

    if ax:
        save_and_show = False
    else:
        ax = figure(figsize=figure_size).gca()
        save_and_show = True

    # Get ax positions
    ax_x_min, ax_x_max, ax_y_min, ax_y_max = get_ax_positions_relative_to_ax(
        ax)
    figure_ax_x_min, figure_ax_x_max, figure_ax_y_min, figure_ax_y_max = get_ax_positions_relative_to_figure(
        ax)

    if sample_x_annotation is None:
        # Plot samples without annotation

        for s_i, (s_name, (x, y)) in enumerate(sample_x_dimension.iterrows()):

            if samples_to_be_emphasized is None:
                alpha = 1
            else:
                if s_name in samples_to_be_emphasized:
                    alpha = 1
                else:
                    alpha = nonemphasized_sample_alpha

            ax.plot(
                x,
                y,
                'o',
                color='#20D9BA',
                alpha=alpha,
                aa=True,
                clip_on=False,
                zorder=sample_z_order,
                **sample_marker_style)

            if plot_sample_text:
                ax.text(
                    x,
                    y + 0.028,
                    s_name,
                    horizontalalignment='center',
                    clip_on=False,
                    zorder=sample_z_order,
                    **sample_text_style)

    else:
        # Plot samples with annotation

        n_annotations = sample_x_annotation.shape[1]

        # Sort annotations
        sample_x_annotation = sample_x_annotation.loc[sample_x_dimension.index]

        # Plot each annotation as a circle slice
        circle = 2 * pi
        ratios = (
            1 / n_annotations * array(range(n_annotations))).tolist() + [1]

        for a_i, (a_name, a) in enumerate(sample_x_annotation.items()):

            # Make proportional vertices
            r = linspace(ratios[a_i] * circle, ratios[a_i + 1] * circle, 80)
            marker_vertices = list(zip(cos(r), sin(r)))
            if 1 < n_annotations:
                marker_vertices = [[0, 0]] + marker_vertices

            # Get annotation type
            if annotation_types is None:
                raise ValueError(
                    'Need both sample_x_annotation and annotation_types.')
            else:
                a_type = annotation_types[a_i]
                if a_type not in ('continuous', 'categorical', 'binary'):
                    raise ValueError('Unknown annotation_types[{}]: {}.'.
                                     format(a_i, annotation_types[a_i]))

            # Normalize annotations and make color normalizer
            if a_type == 'continuous':

                # Normalize annotations
                if annotation_max_stds is not None and annotation_max_stds[a_i] is not None:
                    a = Series(
                        normalize_1d_array(a, '-0-').clip(
                            -annotation_max_stds[a_i],
                            annotation_max_stds[a_i]),
                        name=a.name,
                        index=a.index)

                # Make color normalizer
                if annotation_ranges is not None and annotation_ranges[a_i] is not None:
                    min_, max_ = annotation_ranges[a_i]
                else:
                    min_ = a.min()
                    max_ = a.max()
                norm = Normalize(vmin=min_, vmax=max_)

            else:

                # Normalize annotations
                a = a.astype(int, errors='ignore')

                # Make color normalizer
                norm = NoNorm()

            # Sort by magnitude
            a = a[a.abs().sort_values().index]

            # Set color map
            if annotation_color_maps is not None and annotation_color_maps[a_i] is not None:
                color_map = annotation_color_maps[a_i]
            else:
                if a_type == 'continuous':
                    color_map = CMAP_CONTINUOUS_BWR
                elif a_type == 'categorical':
                    color_map = CMAP_CATEGORICAL_TAB20
                else:
                    color_map = CMAP_BINARY_WB

            # Plot samples
            for s_i, (s_name, (x,
                               y)) in enumerate(sample_x_dimension.iterrows()):

                v = a.loc[s_name]
                if isnull(v):
                    color = '#080808'
                    alpha = nonemphasized_sample_alpha
                else:
                    color = color_map(norm(v))
                    alpha = 1

                if samples_to_be_emphasized is not None:
                    if s_name in samples_to_be_emphasized:
                        alpha = 1
                    else:
                        alpha = nonemphasized_sample_alpha

                ax.plot(
                    x,
                    y,
                    'o',
                    marker=marker_vertices,
                    color=color,
                    alpha=alpha,
                    aa=True,
                    clip_on=False,
                    zorder=sample_z_order,
                    **sample_marker_style)

                if plot_sample_text:
                    ax.text(
                        x,
                        y + 0.028,
                        s_name,
                        horizontalalignment='center',
                        clip_on=False,
                        zorder=sample_z_order,
                        **sample_text_style)

            # Plot legends
            width = 0.5
            height = width / 28
            figure_ax_x_center = (figure_ax_x_max - figure_ax_x_min) / 2

            box = [
                figure_ax_x_center - (width / 2) + figure_ax_x_min,
                -a_i * (figure_ax_y_max - figure_ax_y_min) / 8, width, height
            ]
            legend_ax = ax.get_figure().add_axes(box, xlim=(0, 1), ylim=(0, 1))

            if a_type == 'continuous':

                ColorbarBase(
                    legend_ax,
                    orientation='horizontal',
                    cmap=color_map,
                    norm=norm,
                    ticks=[min_, a.mean(), max_])
                decorate(ax=legend_ax, xticklabels_kwargs=legend_text_style)

                legend_ax.plot(
                    -0.08,
                    y,
                    'o',
                    marker=marker_vertices,
                    color='#4E41D9',
                    aa=True,
                    clip_on=False,
                    zorder=legend_z_order,
                    **legend_marker_style)

                if annotation_max_stds is not None and annotation_max_stds[a_i] is not None:
                    legend_ax.text(
                        0.5,
                        1.18,
                        'Standard Deviation',
                        clip_on=False,
                        zorder=legend_z_order,
                        **{
                            'fontsize': legend_text_style['fontsize'],
                            'horizontalalignment': 'center',
                            'color': legend_text_style['color'],
                        })

            else:

                legend_ax.set_axis_off()

                for i, a_ in enumerate(sorted(set(a))):

                    x = (i + 1) / (len(set(a)) + 1)

                    legend_ax.plot(
                        x,
                        y,
                        'o',
                        marker=marker_vertices,
                        color=color_map(norm(a_)),
                        aa=True,
                        clip_on=False,
                        zorder=legend_z_order,
                        **legend_marker_style)

                    if annotation_to_strs:
                        a_to_str = annotation_to_strs[a_i]
                        if a_to_str:
                            a_ = a_to_str[a_]

                    legend_ax.text(
                        x,
                        y - 0.8,
                        a_,
                        clip_on=False,
                        zorder=legend_z_order,
                        **legend_text_style)

            legend_ax.text(
                -0.18,
                y,
                a_name,
                clip_on=False,
                zorder=legend_z_order,
                **legend_text_style)

    if save_and_show:

        if file_path:
            save_plot(file_path)

        show()
