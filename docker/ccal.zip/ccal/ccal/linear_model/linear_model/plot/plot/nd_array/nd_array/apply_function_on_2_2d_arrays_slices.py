from numpy import empty


def apply_function_on_2_2d_arrays_slices(array_2d_0,
                                         array_2d_1,
                                         function,
                                         axis=0):
    """
    Apply function(array_2d_0_slice, array_2d_1_slice).
    Arguments:
        array_2d_0 (array): (a, b)
        array_2d_1 (array): (c, d)
        function (callable):
        axis (int): 0 | 1
    Returns:
        array (a, c) | (b, d)
    """

    if axis == 1:

        array_2d_0 = array_2d_0.T
        array_2d_1 = array_2d_1.T

    elif not axis == 0:
        ValueError('Unknown axis: {}.'.format(axis))

    array_2d = empty((array_2d_0.shape[1], array_2d_1.shape[1]))

    print('Applying {} ...'.format(function))
    for i_0 in range(array_2d.shape[0]):
        if i_0 % 10 == 0:
            print('\t{}/{} ...'.format(i_0 + 1, array_2d.shape[0]))

        array_2d_0_slice = array_2d_0[:, i_0]

        for i_1 in range(array_2d.shape[1]):

            array_2d_1_slice = array_2d_1[:, i_1]

            array_2d[i_0, i_1] = function(array_2d_0_slice, array_2d_1_slice)
    print('\t{}/{} - done.'.format(i_0 + 1, array_2d.shape[0]))

    return array_2d
