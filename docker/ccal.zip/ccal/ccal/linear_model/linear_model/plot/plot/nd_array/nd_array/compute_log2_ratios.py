from numpy import log2, where


def compute_log2_ratios(array_1d_0, array_1d_1):
    """
    Compute log2 ratios.
        array_1d_0 (array): (n)
        array_1d_1 (array): (n)
    Returns:
        array: (n); log2 fold ratios
    """

    array_1d_0_non_0_min = array_1d_0[array_1d_0 != 0].min()
    array_1d_1_non_0_min = array_1d_1[array_1d_1 != 0].min()
    print('array_1d_0_non_0_min = {}'.format(array_1d_0_non_0_min))
    print('array_1d_1_non_0_min = {}'.format(array_1d_1_non_0_min))

    array_1d_0 = where(array_1d_0 == 0, array_1d_0_non_0_min, array_1d_0)
    array_1d_1 = where(array_1d_1 == 0, array_1d_1_non_0_min, array_1d_1)

    normalization_factor = array_1d_0.sum() / array_1d_1.sum()
    print('normalization_factor = {}'.format(normalization_factor))

    return log2(array_1d_1 / array_1d_0 * normalization_factor)
