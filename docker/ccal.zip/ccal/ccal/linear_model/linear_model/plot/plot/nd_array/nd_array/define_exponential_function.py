from numpy import exp


def define_exponential_function(x, a, k, c):
    """
    Get exponential function of x with parameters a, k, and c.
    Arguments:
        x (array): independent variables
        a (number): parameter a
        k (number): parameter k
        c (number): parameter c
    Returns:
        array: (n_independent_variables)
    """

    return a * exp(k * x) + c
