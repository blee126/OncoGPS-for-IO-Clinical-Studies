from numpy import sqrt
from scipy.stats import norm


def compute_margin_of_error(array_1d, confidence=0.95):
    """
    Compute margin of error.
    Arguments:
        array_1d (array):
        confidence (float): 0 <= confidence <= 1
    Returns:
        float:
    """

    return norm.ppf(q=confidence) * array_1d.std() / sqrt(array_1d.size)
