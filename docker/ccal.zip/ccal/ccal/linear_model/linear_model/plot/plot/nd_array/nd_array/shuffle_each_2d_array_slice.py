from numpy.random import seed, shuffle

RANDOM_SEED = 20121020


def shuffle_each_2d_array_slice(array_2d, axis=0, random_seed=RANDOM_SEED):
    """
    Shuffle each array_2d slice.
    Arguments:
        array_2d (array): (n_rows, n_columns)
        axis (int): 0 | 1
        random_seed (int | array):
    Returns:
        array: (n_rows, n_columns)
    """

    array_2d = array_2d.copy()

    seed(random_seed)

    if axis == 0:

        for i in range(array_2d.shape[1]):
            shuffle(array_2d[:, i])

    elif axis == 1:

        for i in range(array_2d.shape[0]):
            shuffle(array_2d[i, :])

    else:
        ValueError('Unknown axis: {}.'.format(axis))

    return array_2d
