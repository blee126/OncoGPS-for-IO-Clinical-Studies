from matplotlib.colors import ListedColormap

from .make_random_color import make_random_color


def make_random_categorical_colormap(n_colors=None, bad_color=None):
    """
    Make random categorical colormap.
    Arguments:
        n_colors (int):
        bad_color (matplotlib color):
    Returns:
        matplotlib.Colormap:
    """

    color_map = ListedColormap([make_random_color() for i in range(n_colors)])

    if bad_color:
        color_map.set_bad(bad_color)

    return color_map
