from matplotlib.colors import ListedColormap


def make_categorical_colormap(colors, bad_color=None):
    """
    Make categorical colormap.
    Arguments:
        n_colors (int):
        bad_color (matplotlib color):
    Returns:
        matplotlib.Colormap:
    """

    color_map = ListedColormap(colors)

    if bad_color:
        color_map.set_bad(bad_color)

    return color_map
