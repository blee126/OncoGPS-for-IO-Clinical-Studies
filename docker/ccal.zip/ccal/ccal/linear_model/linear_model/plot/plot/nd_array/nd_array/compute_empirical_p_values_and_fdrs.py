from numpy import array, where
from statsmodels.sandbox.stats.multicomp import multipletests

from .compute_empirical_p_value import compute_empirical_p_value


def compute_empirical_p_values_and_fdrs(values, random_values):
    """
    Compute empirical p-values and FDRs.
    Arguments:
        values (array): (n)
        random_values (array): (n_random_values)
    Returns:
        array: (n); p-values
        array: (n); FDRs
    """

    p_values_l = array(
        [compute_empirical_p_value(v, random_values, 'less') for v in values])
    p_values_g = array(
        [compute_empirical_p_value(v, random_values, 'great') for v in values])

    fdrs_l = multipletests(p_values_l, method='fdr_bh')[1]
    fdrs_g = multipletests(p_values_g, method='fdr_bh')[1]

    # Take smaller p-values
    p_values = where(p_values_l < p_values_g, p_values_l, p_values_g)

    # Take smaller FDRs
    fdrs = where(fdrs_l < fdrs_g, fdrs_l, fdrs_g)

    return p_values, fdrs
