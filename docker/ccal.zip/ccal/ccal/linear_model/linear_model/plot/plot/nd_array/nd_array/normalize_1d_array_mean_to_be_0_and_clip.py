def normalize_1d_array_mean_to_be_0_and_clip(array_1d, std_max=3):
    """
    Normalize 1D array mean to be 0 and clip.
    Arguments:
        array_1d (array): (n_values)
        std_max (number):
    Returns:
        array:
    """

    return ((array_1d - array_1d.mean()) / array_1d.std()).clip(
        -std_max, std_max)
