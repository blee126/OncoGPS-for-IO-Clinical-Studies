from .make_nd_grid_coordinates import make_nd_grid_coordinates


def make_index_and_fraction_grid_coordinates_pair(mins,
                                                  maxs,
                                                  grid_sizes,
                                                  indexing='ij'):
    """
    """

    gc_i = make_nd_grid_coordinates(mins, maxs, grid_sizes)
    gc_i = [dc.astype(int) for dc in gc_i]

    gc_f = make_nd_grid_coordinates(mins, [1] * len(maxs), grid_sizes)

    return list(zip(zip(*gc_i), zip(*gc_f)))
