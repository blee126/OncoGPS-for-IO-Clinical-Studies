from numpy import array, empty
from scipy.optimize import curve_fit


def fit_function_on_each_2d_array_slice(array_2d,
                                        function,
                                        axis=0,
                                        maxfev=1000):
    """
    Fit function on each array_2d slice.
    Arguments:
        array_2d (array): (n_rows, n_columns)
        function (callable):
        axis (int): 0 | 1
        maxfev (int):
    Returns:
        list: (n_rows | n_columns); fitted parameters
    """

    if axis == 0:

        fits = empty(array_2d.shape[1])

        x = array(range(array_2d.shape[0]))

        for i in range(fits.size):

            y = array_2d[:, i]

            fits[i] = curve_fit(function, x, y, maxfev=maxfev)[0]

    elif axis == 1:

        fits = empty(array_2d.shape[0])

        x = array(range(array_2d.shape[1]))

        for i in range(fits.size):

            y = array_2d[i, :]

            fits[i] = curve_fit(function, x, y, maxfev=maxfev)[0]

    else:
        ValueError('Unknown axis: {}.'.format(axis))

    return fits
