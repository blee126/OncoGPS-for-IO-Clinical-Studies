def compute_empirical_p_value(value, random_values, direction):
    """
    Compute empirical p-value.
    Arguments:
        value (float):
        random_values (array):
        direction (str): 'less' | 'great'
    Returns:
        float: p-value
    """

    if direction == 'less':
        significant_random_values = random_values <= value

    elif direction == 'great':
        significant_random_values = value <= random_values

    else:
        raise ValueError('Unknown direction: {}.'.format(direction))

    p_value = significant_random_values.sum() / random_values.size

    if p_value == 0:
        p_value = 1 / random_values.size

    return p_value
