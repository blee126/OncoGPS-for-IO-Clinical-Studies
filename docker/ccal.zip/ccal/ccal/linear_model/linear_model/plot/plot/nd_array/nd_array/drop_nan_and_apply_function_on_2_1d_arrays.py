from numpy import isnan


def drop_nan_and_apply_function_on_2_1d_arrays(array_1d_0, array_1d_1,
                                               min_n_samples, function):
    """
    Drop nan and apply function(array_1d_0_without_nan, array_1d_1_without_nan).
    Arguments:
        array_1d_0 (array): (n)
        array_1d_1 (array): (n)
        min_n_samples (int):
        function (callable):
    Returns:
        object:
    """

    if array_1d_0.size != array_1d_1.size:
        raise ValueError('array_1d_0.size and array_1d_1.size differ.')

    nans = isnan(array_1d_0) | isnan(array_1d_1)

    array_1d_0_without_nan = array_1d_0[~nans]
    array_1d_1_without_nan = array_1d_1[~nans]

    if array_1d_0_without_nan.size < min_n_samples:
        print('There is less than {} samples after dropping nans.'.format(
            min_n_samples))
    else:
        return function(array_1d_0_without_nan, array_1d_1_without_nan)
