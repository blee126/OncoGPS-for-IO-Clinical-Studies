from numpy import linspace, meshgrid


def make_nd_grid_coordinates(mins, maxs, grid_sizes, indexing='ij'):
    """
    Make N-dimensional grid coordinates.
    Arguments:
        mins (iterable): (n_dimensions); grid coordinates' min
        maxs (iterable): (n_dimensions); grid coordinates' max
        grid_sizes (iterable): (n_dimensions); grid coordinates' size
        indexing (str): 'ij' (d0, ..., dn) | 'xy' (d1, d0, d2, ..., dn)
    Returns:
        list: (n_dimensions); of arrays (grid_size^n_dimensions)
    """

    return [
        m.ravel()
        for m in meshgrid(
            * [
                linspace(min_, max_, grid_size)
                for min_, max_, grid_size in zip(mins, maxs, grid_sizes)
            ],
            indexing=indexing)
    ]
