from matplotlib.pyplot import show
from pandas import DataFrame
from seaborn import clustermap

from .decorate import decorate
from .nd_array.nd_array.normalize_2d_array import normalize_2d_array
from .save_plot import save_plot
from .style import (CMAP_BINARY_WB, CMAP_CATEGORICAL_TAB20,
                    CMAP_CONTINUOUS_BWR, FIGURE_SIZE)


def plot_clustermap(df,
                    data_type='continuous',
                    pivot_kws=None,
                    method='complete',
                    metric='euclidean',
                    z_score=None,
                    standard_scale=None,
                    cbar_kws=None,
                    row_cluster=True,
                    col_cluster=True,
                    row_linkage=None,
                    col_linkage=None,
                    row_colors=None,
                    col_colors=None,
                    annotate='auto',
                    mask=None,
                    drop_axis=None,
                    normalization_axis=None,
                    normalization_method=None,
                    max_std=3,
                    figure_size=FIGURE_SIZE,
                    cmap=None,
                    title=None,
                    xlabel=None,
                    ylabel=None,
                    xlabel_kwargs={},
                    ylabel_kwargs={},
                    xticks=None,
                    yticks=None,
                    xticklabels_kwargs={},
                    yticklabels_kwargs={},
                    file_path=None,
                    **kwargs):
    """
    Plot clustermap.
    """

    if normalization_method:
        df = DataFrame(
            normalize_2d_array(
                df.values, normalization_method, axis=normalization_axis),
            index=df.index,
            columns=df.columns)
        if normalization_method == '-0-':
            df = df.clip(-max_std, max_std)

    if not cmap:
        if data_type == 'continuous':
            cmap = CMAP_CONTINUOUS_BWR
        elif data_type == 'categorical':
            cmap = CMAP_CATEGORICAL_TAB20
        elif data_type == 'binary':
            cmap = CMAP_BINARY_WB
        else:
            raise ValueError('Unknown data_type: {}.'.format(data_type))

    if annotate == 'auto':
        if all([n < 30 for n in df.shape]):
            annotate = True
        else:
            annotate = False

    clustergrid = clustermap(
        df,
        pivot_kws=pivot_kws,
        method=method,
        metric=metric,
        z_score=z_score,
        standard_scale=standard_scale,
        figsize=figure_size,
        cbar_kws=cbar_kws,
        row_cluster=row_cluster,
        col_cluster=col_cluster,
        row_linkage=row_linkage,
        col_linkage=col_linkage,
        row_colors=row_colors,
        col_colors=col_colors,
        annot=annotate,
        mask=mask,
        cmap=cmap)

    decorate(
        ax=clustergrid.ax_heatmap,
        despine_kwargs=dict(left=True, bottom=True),
        title=title,
        yaxis_position='right',
        xlabel=xlabel,
        ylabel=ylabel,
        xlabel_kwargs=xlabel_kwargs,
        ylabel_kwargs=ylabel_kwargs,
        xticks=xticks,
        yticks=yticks,
        xticklabels_kwargs=xticklabels_kwargs,
        yticklabels_kwargs=yticklabels_kwargs)

    if file_path:
        save_plot(file_path)

    show()
