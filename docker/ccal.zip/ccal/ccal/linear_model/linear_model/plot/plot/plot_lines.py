from matplotlib.pyplot import show

from .style import FONT_SMALLEST


def plot_lines(ax,
               x_lines=(),
               y_lines=(),
               linewidth=1,
               color='#4E41E6',
               alpha=0.8,
               text_buffer_ratio=0.01,
               z_order=0):
    """
    Plot lines.
    """

    ax_x_min, ax_x_max, ax_y_min, ax_y_max = ax.axis()
    ax_x_range = ax_x_max - ax_x_min
    ax_y_range = ax_y_max - ax_y_min

    for x in x_lines:
        ax.plot(
            [x, x], [ax_y_min, ax_y_max],
            linewidth=linewidth,
            color=color,
            alpha=alpha,
            zorder=z_order)

        ax.text(
            x,
            ax_y_min - ax_y_range * text_buffer_ratio,
            x,
            rotation=90,
            horizontalalignment='center',
            verticalalignment='top',
            zorder=z_order,
            **FONT_SMALLEST)

    for y in y_lines:
        ax.plot(
            [ax_x_min, ax_x_max], [y, y],
            linewidth=linewidth,
            color=color,
            zorder=z_order,
            alpha=alpha)

        ax.text(
            ax_x_max + ax_x_range * text_buffer_ratio,
            y,
            y,
            verticalalignment='center',
            zorder=z_order,
            **FONT_SMALLEST)
