# ND Array

Library for working with N-dimensional arrays :straight_ruler:
