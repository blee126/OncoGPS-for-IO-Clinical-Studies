from matplotlib.pyplot import figure, show
from pandas import isnull
from seaborn import barplot, boxplot, swarmplot, violinplot

from .decorate import decorate
from .save_plot import save_plot
from .style import FIGURE_SIZE


def plot_violin_box_or_bar(x=None,
                           y=None,
                           hue=None,
                           data=None,
                           order=None,
                           hue_order=None,
                           bw='scott',
                           cut=2,
                           scale='count',
                           scale_hue=True,
                           gridsize=100,
                           width=0.8,
                           inner='quartile',
                           split=False,
                           orient=None,
                           linewidth=None,
                           color=None,
                           palette=None,
                           saturation=0.75,
                           ax=None,
                           fliersize=5,
                           whis=1.5,
                           notch=False,
                           ci=95,
                           n_boot=1000,
                           units=None,
                           errcolor='0.26',
                           errwidth=None,
                           capsize=None,
                           size=5,
                           edgecolor='#FFFFFF',
                           violin_or_box='violin',
                           plot_swarm=True,
                           title=None,
                           xlabel=None,
                           ylabel=None,
                           file_path=None,
                           figure_size=FIGURE_SIZE,
                           **kwargs):
    """
    Plot violin, box, or bar.
    """

    if ax:
        save_and_show = False
    else:
        ax = figure(figsize=figure_size).gca()
        save_and_show = True

    # Get x & y
    if isinstance(x, str):
        x = data[x]
    if isinstance(y, str):
        y = data[y]

    if len(set([y_ for y_ in y if not isnull(y_)])) <= 2:
        # Use barplot for binary
        barplot(
            x=x,
            y=y,
            hue=hue,
            data=data,
            order=order,
            hue_order=hue_order,
            ci=ci,
            n_boot=n_boot,
            units=units,
            orient=orient,
            color=color,
            palette=palette,
            saturation=saturation,
            errcolor=errcolor,
            ax=ax,
            errwidth=errwidth,
            capsize=capsize,
            **kwargs)

    else:

        # Use violin or box plot for continuous or categorical
        if violin_or_box == 'violin':
            violinplot(
                x=x,
                y=y,
                hue=hue,
                data=data,
                order=order,
                hue_order=hue_order,
                bw=bw,
                cut=cut,
                scale=scale,
                scale_hue=scale_hue,
                gridsize=gridsize,
                width=width,
                inner=inner,
                split=split,
                orient=orient,
                linewidth=linewidth,
                color=color,
                palette=palette,
                saturation=saturation,
                ax=ax,
                **kwargs)

        elif violin_or_box == 'box':
            boxplot(
                x=x,
                y=y,
                hue=hue,
                data=data,
                order=order,
                hue_order=hue_order,
                orient=orient,
                color=color,
                palette=palette,
                saturation=saturation,
                width=width,
                fliersize=fliersize,
                linewidth=linewidth,
                whis=whis,
                notch=notch,
                ax=ax,
                **kwargs)

        else:
            raise ValueError(
                'Unknown violin_or_box: {}.'.format(violin_or_box))

        if plot_swarm:
            swarmplot(
                x=x,
                y=y,
                hue=hue,
                data=data,
                order=order,
                hue_order=hue_order,
                split=split,
                orient=orient,
                color=color,
                palette=palette,
                size=size,
                edgecolor=edgecolor,
                linewidth=linewidth,
                ax=ax,
                **kwargs)

    decorate(title=title, xlabel=xlabel, ylabel=ylabel)

    if save_and_show:

        if file_path:
            save_plot(file_path)

        show()
