from numpy import array


def get_1d_array_unique_objects_in_order(array_1d):
    """
    Get unique objects in the order of their appearance in array_1d.
    Arguments:
        array_1d (array): (n)
    Returns:
        array: (n_unique_objects); unique objects ordered by their appearances
            in array_1d
    """

    unique_objects_in_order = []

    for o in array_1d:

        if o not in unique_objects_in_order:
            unique_objects_in_order.append(o)

    return array(unique_objects_in_order)
