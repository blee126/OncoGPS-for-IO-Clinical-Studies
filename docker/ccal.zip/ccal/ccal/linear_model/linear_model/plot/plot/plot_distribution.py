from matplotlib.pyplot import figure, show
from seaborn import distplot

from .decorate import decorate
from .save_plot import save_plot
from .style import FIGURE_SIZE


def plot_distribution(a,
                      bins=None,
                      hist=True,
                      kde=True,
                      rug=False,
                      fit=None,
                      hist_kws=None,
                      kde_kws=None,
                      rug_kws=None,
                      fit_kws=None,
                      color='#20D9BA',
                      vertical=False,
                      norm_hist=False,
                      axlabel=None,
                      label=None,
                      ax=None,
                      figure_size=FIGURE_SIZE,
                      title='',
                      xlabel='',
                      ylabel='Frequency',
                      file_path=None):
    """
    Plot distribution.
    """

    if ax:
        save_and_show = False
    else:
        ax = figure(figsize=figure_size).gca()
        save_and_show = True

    distplot(
        a,
        bins=bins,
        hist=hist,
        kde=kde,
        rug=rug,
        fit=fit,
        hist_kws=hist_kws,
        kde_kws=kde_kws,
        rug_kws=rug_kws,
        fit_kws=fit_kws,
        color=color,
        vertical=vertical,
        norm_hist=norm_hist,
        axlabel=axlabel,
        label=label,
        ax=ax)

    decorate(title=title, xlabel=xlabel, ylabel=ylabel)

    if save_and_show:

        if file_path:
            save_plot(file_path)

        show()
