from matplotlib.colorbar import ColorbarBase, make_axes
from matplotlib.colors import Normalize
from matplotlib.gridspec import GridSpec
from matplotlib.pyplot import figure, show, subplot, tight_layout
from pandas import DataFrame
from seaborn import heatmap

from .decorate import decorate
from .save_plot import save_plot
from .style import CMAP_CONTINUOUS_BWR, FIGURE_SIZE


def plot_columns(df, figure_size=FIGURE_SIZE, file_path=None):
    """
    Plot heatmap for each column.
    """

    figure(figsize=figure_size)

    n_cols = df.shape[1]

    gs = GridSpec(2, n_cols)

    axes_heatmap = []
    for i in range(n_cols):
        axes_heatmap.append(subplot(gs[0, i:i + 1]))

    for i, (c_n, c) in enumerate(df.items()):
        ax = axes_heatmap[i]
        heatmap(
            DataFrame(c),
            xticklabels=False,
            yticklabels=False,
            ax=ax,
            cbar=False,
            cmap=CMAP_CONTINUOUS_BWR)
        decorate(ax=ax, ylabel=c_n)

    tight_layout()

    for i, (c_n, c) in enumerate(df.items()):
        ax = axes_heatmap[i]

        cax, kw = make_axes(
            ax,
            location='bottom',
            fraction=0.1,
            shrink=0.7,
            norm=Normalize(c.min(), c.max()),
            ticks=[c.min(), c.mean(), c.max()],
            cmap=CMAP_CONTINUOUS_BWR)
        ColorbarBase(cax, **kw)

        decorate(ax=cax)

    if file_path:
        save_plot(file_path)

    show()
