def get_ax_positions_relative_to_figure(ax):
    """
    Get ax positions relative to the figure it's on.
    Arguments:
        ax:
    Returns:
        float:
        float:
        float:
        float:
    """

    figure_ax_position = ax.get_position()

    figure_ax_x_min, figure_ax_y_min = figure_ax_position.p0
    figure_ax_x_max, figure_ax_y_max = figure_ax_position.p1

    return figure_ax_x_min, figure_ax_x_max, figure_ax_y_min, figure_ax_y_max
