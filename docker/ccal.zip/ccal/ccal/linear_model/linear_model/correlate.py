from matplotlib.pyplot import gca
from numpy import empty
from numpy.random import seed, shuffle
from sklearn.linear_model import LinearRegression

from .plot.plot.decorate import decorate
from .plot.plot.plot_points import plot_points

RANDOM_SEED = 20121020


def correlate(x,
              y,
              title_prefix='',
              xlabel='',
              ylabel='',
              n_permutations=0,
              plot_=True,
              random_seed=RANDOM_SEED):
    """
    Correlate x and y and compute empirical p-value.
    Arguments:
        x (array): (n)
        y (array): (n)
        title_prefix (str):
        xlabel (str):
        ylabel (str):
        n_permutations (int): number of permutations for permutation test
        plot_ (bool): whether to plot the correlation
        random_seed (int | array):
    Returns:
         float: R^2
         float: p-value
    """

    m = LinearRegression()

    # Compute R^2
    m.fit([[x_] for x_ in x], y)
    r2 = m.score([[x_] for x_ in x], y)

    # Permute and compute R^2
    if n_permutations:
        # Compute p-value by permutation test

        m_ = LinearRegression()

        permuted_r2s = empty(n_permutations)

        y_ = y.copy()

        seed(random_seed)

        for i in range(n_permutations):

            shuffle(y_)

            m_.fit([[x_] for x_ in x], y_)
            r2_ = m_.score([[x_] for x_ in x], y_)

            # TODO: Figure out how to deal with opposite slopes
            permuted_r2s[i] = r2_

        p_value = max((r2 <= permuted_r2s).sum() / permuted_r2s.size,
                      1 / permuted_r2s.size)
    else:
        p_value = None

    if plot_:
        plot_points(
            x, y, xlabel=xlabel, ylabel=ylabel, markersize=18, color='#20D9BA')

        plot_points(
            x,
            m.coef_ * x + m.intercept_,
            linestyle='-',
            linewidth=3,
            color='#9017E6',
            ax=gca())

        title = 'R^2={:.3f}'.format(r2)
        if p_value is not None:
            title = title + ' & p-value={:.3e}'.format(p_value)
        if title_prefix:
            title = '{}\n{}'.format(title_prefix, title)

        decorate(title=title)

    return r2, p_value
