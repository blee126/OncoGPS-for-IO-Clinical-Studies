# Linear Model

Library for working with linear models :rocket:
