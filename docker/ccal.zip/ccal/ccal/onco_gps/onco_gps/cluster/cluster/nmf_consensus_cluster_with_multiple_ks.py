from os.path import join

from pandas import DataFrame, Series

from .nmf_consensus_cluster import nmf_consensus_cluster
from .plot.plot.plot_heatmap import plot_heatmap
from .plot.plot.plot_points import plot_points
from .support.support.multiprocess import multiprocess
from .support.support.path import establish_path

RANDOM_SEED = 20121020


def nmf_consensus_cluster_with_multiple_ks(df,
                                           ks,
                                           n_jobs=1,
                                           n_clusterings=50,
                                           algorithm='als',
                                           init=None,
                                           solver='cd',
                                           beta_loss='frobenius',
                                           tol=0.0001,
                                           max_iter=1000,
                                           random_seed=RANDOM_SEED,
                                           alpha=0.0,
                                           l1_ratio=0.0,
                                           verbose=0,
                                           shuffle=False,
                                           directory_path=None):
    """
    NMF consensus cluster (NMFCC) df columns with multiple ks and compute
        cophenetic correlation coefficients (CCCs).
    Arguments:
        df (DataFrame): (n_features, n_samples); A matrix
        ks (iterable): ks for NMF
        n_jobs (int): number of parallel jobs
        n_clusterings (int): number of NMF clusterings for consensus
        algorithm (str): 'als' | 'ls'
        init:
        solver:
        beta_loss:
        tol:
        max_iter:
        random_seed (int | array):
        alpha:
        l1_ratio:
        verbose:
        shuffle:
        directory_path (str):
    Returns:
        dict: NMFs; {
            k: {
                w: W matrix,
                h: H matrix,
                e: reconstruction error
            }
        }
        DataFrame: (n_ks, n_samples); clusterings
        Series: (n_ks); CCCs
    """

    nmfs = {}
    cs = {}
    cccs = {}

    args = [(df, k, n_clusterings, algorithm, init, solver, beta_loss, tol,
             max_iter, random_seed, alpha, l1_ratio, verbose, shuffle,
             directory_path) for k in ks]

    returns = multiprocess(nmf_consensus_cluster, args, n_jobs=n_jobs)

    for k, r in zip(ks, returns):

        w, h, e, c, ccc = r

        k_key = 'K{}'.format(k)
        nmfs[k_key] = {'w': w, 'h': h, 'e': e}
        cs[k_key] = c
        cccs[k_key] = ccc

    cs = DataFrame(cs, index=df.columns).T
    cccs = Series(cccs, name='CCC')

    if directory_path:
        establish_path(directory_path, path_type='directory')

        cs.to_csv(join(directory_path, 'nmfccs.txt'), sep='\t')

        plot_heatmap(
            cs,
            axis_to_sort=1,
            data_type='categorical',
            title='NMFCC Distributions',
            file_path=join(directory_path, 'nmfcc_distributions.png'))

        plot_points(
            sorted(ks), [cccs['K{}'.format(k)] for k in sorted(ks)],
            linestyle='-',
            markersize=8,
            title='NMFCC CCCs',
            xlabel='K',
            ylabel='CCC',
            file_path=join(directory_path, 'nmfcc_cccs.png'))

    return nmfs, cs, ccc
