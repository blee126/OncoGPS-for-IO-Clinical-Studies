from .count_coclusterings import count_coclusterings
from .hierarchical_cluster_distances_and_compute_ccc import \
    hierarchical_cluster_distances_and_compute_ccc


def consensus_cluster(sample_x_clustering):
    """
    Count the number of times samples are clustered together, and normalize the
        count by dividing it with the number of clusterings. Compute clustering
        distances by 1 - coclusterings. And hierarchical cluster the clustering
        distances and compute cophenetic correlation coefficient (CCC).
    Arguments:
        sample_x_clustering (array): (n_samples, n_clusterings)
    Returns:
        array: z (linkage)
        float: CCC
    """

    coclusterings = count_coclusterings(sample_x_clustering)

    clustering_distances = 1 - coclusterings

    return hierarchical_cluster_distances_and_compute_ccc(clustering_distances)
