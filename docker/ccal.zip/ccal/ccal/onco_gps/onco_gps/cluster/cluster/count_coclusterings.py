from numpy import zeros


def count_coclusterings(sample_x_clustering):
    """
    Count the number of times samples are clustered together, and normalize the
        count by dividing it with the number of clusterings.
    Arguments:
        sample_x_clustering (array): (n_samples, n_clusterings)
    Returns:
        array: (n_samples, n_samples)
    """

    n_samples, n_clusterings = sample_x_clustering.shape

    # Make sample-x-sample matrix
    coclusterings = zeros((n_samples, n_samples))

    # Count the number of co-clusterings
    for i in range(n_samples):

        for j in range(n_samples):

            for c_i in range(n_clusterings):

                v1 = sample_x_clustering[i, c_i]
                v2 = sample_x_clustering[j, c_i]
                if v1 and v2 and (v1 == v2):
                    coclusterings[i, j] += 1

    # Normalize by the number of clusterings and return
    return coclusterings / n_clusterings
