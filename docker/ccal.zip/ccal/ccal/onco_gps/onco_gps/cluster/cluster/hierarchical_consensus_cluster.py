from os.path import join

from numpy import empty
from numpy.random import random_integers, seed
from pandas import DataFrame
from scipy.cluster.hierarchy import fcluster
from sklearn.cluster import AgglomerativeClustering

from .consensus_cluster import consensus_cluster
from .information.information.compute_information_coefficient import \
    compute_information_distance
from .nd_array.nd_array.apply_function_on_2_2d_arrays_slices import \
    apply_function_on_2_2d_arrays_slices
from .plot.plot.plot_clustermap import plot_clustermap
from .plot.plot.plot_heatmap import plot_heatmap
from .support.support.path import establish_path

RANDOM_SEED = 20121020


def hierarchical_consensus_cluster(
        df,
        k,
        distances=None,
        distance_function=compute_information_distance,
        n_clusterings=50,
        random_seed=RANDOM_SEED,
        directory_path=None):
    """
    Hierarchical consensus cluster (HCC) df columns with k and compute
        cophenetic correlation coefficients (CCCs).
    Arguments:
        df (DataFrame): (n_features, n_samples)
        ks (iterable): (n_ks); Ks for clustering
        distances (DataFrame): (n_samples, n_samples); distance
        distance_function (callable):
        n_clusterings (int): number of hierarchical clusterings for consensus
        random_seed (float | array):
        directory_path (str): where to save the results
    Returns:
        array: hierarchical clustering object (linkage object)
        array:( n_samples); clustering
        float: CCC
    """

    if directory_path:
        establish_path(directory_path, path_type='directory')

    if distances is None:
        print('Computing distances with {} ...'.format(distance_function))

        distances = apply_function_on_2_2d_arrays_slices(
            df.values, df.values, distance_function)
        distances = DataFrame(distances, index=df.columns, columns=df.columns)

        if directory_path:
            distances.to_csv(join(directory_path, 'distances.txt'), sep='\t')

            plot_clustermap(
                distances,
                title='Distances',
                file_path=join(directory_path, 'distances.png'))

    print('HCC with K = {} ...'.format(k))

    sample_x_clustering = empty((distances.shape[0], n_clusterings))

    # Make hierarchical clustering object
    # TODO: unify hierarchical clustering method:
    #   hc = linkage(distances, method=method ()
    #   c = fcluster(hc, k, criterion='maxclust')
    m = AgglomerativeClustering(n_clusters=k)

    seed(random_seed)
    for i in range(n_clusterings):
        if i % 10 == 0:
            print('\tK = {}: {}/{} ...'.format(k, i + 1, n_clusterings))

        # Random sample with repeat and hierarchical cluster
        indices = random_integers(0, distances.shape[0] - 1,
                                  distances.shape[0])
        sample_x_clustering[indices, i] = m.fit_predict(
            distances.iloc[indices, indices])
    print('\tK = {}: {}/{} - done.'.format(k, i + 1, n_clusterings))

    hc, ccc = consensus_cluster(sample_x_clustering)

    c = fcluster(hc, k, criterion='maxclust') - 1

    if directory_path:

        plot_heatmap(
            df,
            column_annotation=c,
            normalization_method='-0-',
            normalization_axis=1,
            title='HCC with K = {}'.format(k),
            file_path=join(directory_path, 'hcc_k{}.png'.format(k)))

        plot_heatmap(
            distances,
            column_annotation=c,
            title='HCC with K = {}: Distances'.format(k),
            file_path=join(directory_path, 'hcc_k{}_distances.png'.format(k)))

    return distances, hc, c, ccc
