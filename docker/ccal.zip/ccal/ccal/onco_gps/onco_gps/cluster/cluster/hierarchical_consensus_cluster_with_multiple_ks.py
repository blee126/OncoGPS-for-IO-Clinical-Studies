from os.path import join

from pandas import DataFrame, Series

from .hierarchical_consensus_cluster import hierarchical_consensus_cluster
from .information.information.compute_information_coefficient import \
    compute_information_distance
from .nd_array.nd_array.apply_function_on_2_2d_arrays_slices import \
    apply_function_on_2_2d_arrays_slices
from .plot.plot.plot_clustermap import plot_clustermap
from .plot.plot.plot_heatmap import plot_heatmap
from .plot.plot.plot_points import plot_points
from .support.support.multiprocess import multiprocess
from .support.support.path import establish_path

RANDOM_SEED = 20121020


def hierarchical_consensus_cluster_with_multiple_ks(
        df,
        ks,
        distances=None,
        distance_function=compute_information_distance,
        n_jobs=1,
        n_clusterings=50,
        random_seed=RANDOM_SEED,
        directory_path=None):
    """
    Hierarchical consensus cluster (HCC) df columns with multiple ks and compute
        cophenetic correlation coefficients (CCCs).
    Arguments:
        df (DataFrame): (n_features, n_samples)
        ks (iterable): (n_ks); Ks for clustering
        distances (DataFrame): (n_samples, n_samples); distance
        distance_function (callable):
        n_jobs (int): number of parallel jobs
        n_clusterings (int): number of hierarchical clusterings for consensus
        random_seed (float | array):
        directory_path (str): where to save the results
    Returns:
        DataFrame: (n_samples, n_samples); distances
        list: hierarchical clustering object (linkage object) per k
        DataFrame: (n_ks, n_samples); clusterings
        Series: (n_ks); CCCs
    """

    hcs = {}
    cs = {}
    cccs = {}

    if distances is None:
        print('Computing distances with {} ...'.format(distance_function))

        distances = apply_function_on_2_2d_arrays_slices(
            df.values, df.values, distance_function)
        distances = DataFrame(distances, index=df.columns, columns=df.columns)

        if directory_path:
            distances.to_csv(join(directory_path, 'distances.txt'), sep='\t')

            plot_clustermap(
                distances,
                title='Distances',
                file_path=join(directory_path, 'distances.png'))

    args = [(df, k, distances, distance_function, n_clusterings, random_seed,
             directory_path) for k in ks]

    returns = multiprocess(hierarchical_consensus_cluster, args, n_jobs=n_jobs)

    for k, r in zip(ks, returns):

        distances, hc, c, ccc = r

        k_key = 'K{}'.format(k)
        hcs[k_key] = hc
        cs[k_key] = c
        cccs[k_key] = ccc

    cs = DataFrame(cs, index=df.columns).T
    cccs = Series(cccs, name='CCC')

    if directory_path:
        establish_path(directory_path, path_type='directory')

        cs.to_csv(join(directory_path, 'hccs.txt'), sep='\t')

        plot_heatmap(
            cs,
            axis_to_sort=1,
            data_type='categorical',
            title='HCC Distributions',
            file_path=join(directory_path, 'hcc_distributions.png'))

        plot_points(
            sorted(ks), [cccs['K{}'.format(k)] for k in sorted(ks)],
            linestyle='-',
            markersize=8,
            title='HCC CCCs',
            xlabel='K',
            ylabel='CCC',
            file_path=join(directory_path, 'hcc_cccs.png'))

    return distances, hcs, cs, cccs
