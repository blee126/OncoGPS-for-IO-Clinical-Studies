from scipy.cluster.hierarchy import cophenet, linkage
from scipy.spatial.distance import pdist
from scipy.stats import pearsonr


def hierarchical_cluster_distances_and_compute_ccc(distances,
                                                   zero_self_distances=True,
                                                   method='ward'):
    """
    Hierarchical cluster distances and compute cophenetic correlation
        coefficient (CCC).
    Arguments:
        distances (array): (n, n); distances
        zero_self_distances (bool): whether to force self distances (d[i, i]) to
            be 0
        method (str): method parameter compatible for
            scipy.cluster.hierarchy.linkage
    Returns:
        array: z (linkage)
        float: CCC
    """

    if zero_self_distances:
        # Force self distances (d[i, i]) to be 0
        for i in range(distances.shape[0]):
            distances[i, i] = 0

    # Hierarchical cluster distances
    hc = linkage(distances, method=method)

    # Compute ccc, which is pearson correlation between distance-matrices
    #    distances and HC-cophenetic distances
    return hc, pearsonr(pdist(distances), cophenet(hc))[0]
