from sklearn.svm import SVR


def regress(training,
            training_classes,
            testing,
            kernel='rbf',
            degree=3,
            gamma='auto',
            coef0=0.0,
            tol=0.001,
            c=1.0,
            epsilon=0.1,
            shrinking=True,
            cache_size=200,
            verbose=False,
            max_iter=-1):
    """
    Train a regressor using training and predict the classes of testing.
    Arguments:
        training (array | DataFrame): (n_training_samples, n_dimensions)
        training_classes (array | Series): (n_training_samples)
        testing (array | DataFrame): (n_testing_samples, n_dimensions)
        kernel:
        degree:
        gamma:
        coef0:
        tol:
        c:
        epsilon:
        shrinking:
        cache_size:
        verbose:
        max_iter:
    Returns:
        array: (n_testing_samples)
    """

    clf = SVR(
        kernel=kernel,
        degree=degree,
        gamma=gamma,
        coef0=coef0,
        tol=tol,
        C=c,
        epsilon=epsilon,
        shrinking=shrinking,
        cache_size=cache_size,
        verbose=verbose,
        max_iter=max_iter)

    clf.fit(training, training_classes)

    return clf.predict(testing)
