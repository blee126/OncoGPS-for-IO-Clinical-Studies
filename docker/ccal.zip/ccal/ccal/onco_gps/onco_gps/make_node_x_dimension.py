from .nd_array.nd_array.normalize_2d_array import normalize_2d_array
from .dimension_reduction.dimension_reduction.mds import mds


def make_node_x_dimension(node_x_sample, n_dimensions, mds_distance_function,
                          mds_random_seed):
    """
    Make node-x-dimension.
    Arguments:
        node_x_sample (array): (n_nodes, n_samples)
        n_dimensions (int):
        mds_distance_function (callable):
        mds_random_seed (number):
    Returns:
        array: (n_nodes, n_dimensions)
    """

    if not mds_distance_function:
        mds_distance_function = 'euclidean'

    node_x_dimension = mds(
        node_x_sample,
        n_target_dimensions=n_dimensions,
        distance_function=mds_distance_function,
        random_seed=mds_random_seed)

    node_x_dimension = normalize_2d_array(node_x_dimension, '0-1', axis=0)

    return node_x_dimension
