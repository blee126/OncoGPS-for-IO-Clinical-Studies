from numpy import empty, unique, zeros

from .kernel_density.kernel_density.compute_bandwidths import \
    compute_bandwidths
from .kernel_density.kernel_density.kde import kde


def make_grid_values_and_categorical_phenotypes(
        sample_x_dimension, sample_phenotypes, n_grids, bandwidth_factor):
    """
    Make grid values and categorical phenotypes.
    Arguments:
        sample_x_dimension (array): (n_samples, n_dimensions)
        sample_phenotypes (array): (n_samples)
        n_grids (int):
        bandwidth_factor (number):
    Returns:
        array: (n_grids, n_grids); grid values
        array: (n_grids, n_grids); grid categorical phenotypes
    """

    n_dimensions = sample_x_dimension.shape[1]

    variable_types = 'c' * n_dimensions

    global_bandwidths = compute_bandwidths(
        [sample_x_dimension[:, i]
         for i in range(n_dimensions)], variable_types)

    global_bandwidths *= bandwidth_factor

    # Set grid limits
    mins = [0] * n_dimensions
    maxs = [1] * n_dimensions

    s_to_gv = {}

    for s in unique(sample_phenotypes):

        variables = [
            sample_x_dimension[sample_phenotypes == s][:, i]
            for i in range(n_dimensions)
        ]

        kd = kde(
            variables,
            variable_types,
            bandwidths=global_bandwidths,
            mins=mins,
            maxs=maxs,
            grid_size=n_grids)

        s_to_gv[s] = kd / kd.sum()

    size = [n_grids] * n_dimensions
    grid_values = zeros(size)
    grid_phenotypes = empty(size, dtype=int)

    # Assign the highest grid value and its corresponding phenotype to each grid
    for i in range(n_grids):
        for j in range(n_grids):

            max_probability = 0
            phenotype = None

            for s, gv in s_to_gv.items():

                p = gv[i, j]

                if max_probability < p:
                    max_probability = p
                    phenotype = s

            grid_values[i, j] = max_probability
            grid_phenotypes[i, j] = phenotype

    return grid_values, grid_phenotypes
