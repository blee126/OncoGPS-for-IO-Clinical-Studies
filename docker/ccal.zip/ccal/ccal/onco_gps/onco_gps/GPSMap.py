from colorsys import hsv_to_rgb, rgb_to_hsv
from gzip import open
from math import ceil
from pickle import dump, load

from matplotlib.colors import to_rgb
from matplotlib.path import Path
from matplotlib.pyplot import figure
from numpy import empty, issubdtype, number, ones, zeros
from numpy.ma import array as ma_array
from pandas import DataFrame, Series
from scipy.spatial import ConvexHull, Delaunay

from .classification.classification.classify import classify
from .make_grid_values_and_categorical_phenotypes import \
    make_grid_values_and_categorical_phenotypes
from .make_grid_values_and_continuous_phenotypes import \
    make_grid_values_and_continuous_phenotypes
from .make_node_x_dimension import make_node_x_dimension
from .make_sample_x_dimension import make_sample_x_dimension
from .nd_array.nd_array.make_index_and_fraction_grid_coordinates_pair import \
    make_index_and_fraction_grid_coordinates_pair
from .nd_array.nd_array.normalize_1d_array import normalize_1d_array
from .plot.plot.plot_samples import plot_samples
from .plot.plot.plot_violin_box_or_bar import plot_violin_box_or_bar
from .plot.plot.save_plot import save_plot
from .plot.plot.style import CMAP_CATEGORICAL_TAB20, FIGURE_SIZE
from .regression.regression.regress import regress
from .support.support.path import establish_path

RANDOM_SEED = 20121020


# TODO: don't allow invalid style keyword arguments to be set
class GPSMap:
    """
    """

    def __init__(self,
                 node_x_sample,
                 std_max=3,
                 n_dimensions=2,
                 mds_distance_function=None,
                 mds_random_seed=RANDOM_SEED,
                 node_x_dimension=None,
                 n_pulls=None,
                 pull_power=1,
                 figure_size=FIGURE_SIZE,
                 title_style={
                     'fontsize': 38,
                     'weight': 'bold',
                     'color': '#9017E6',
                 },
                 subtitle_style={
                     'fontsize': 28,
                     'weight': 'bold',
                     'color': '#20D9BA',
                 },
                 node_marker_style={
                     'marker': 'o',
                     'markersize': 38,
                     'markerfacecolor': '#000726',
                     'markeredgewidth': 2.8,
                     'markeredgecolor': '#4E41D9',
                 },
                 node_text_style={
                     'fontsize': 28,
                     'weight': 'bold',
                     'color': '#000726',
                 },
                 triangulation_style={
                     'linewidth': 1.8,
                     'color': '#220530',
                 },
                 background_color_alpha_factor=1,
                 background_boundary_color=None,
                 n_contours=18,
                 contour_style={
                     'linewidths': 0.18,
                     'colors': '#000726',
                 },
                 sample_marker_style={
                     'markersize': 28,
                     'markeredgewidth': 0.8,
                     'markeredgecolor': '#000726',
                 },
                 sample_text_style={
                     'fontsize': 18,
                     'weight': 'bold',
                     'color': '#000726',
                 },
                 legend_spacing=0.1,
                 sample_legend_marker_style={
                     'markersize': 28,
                     'markeredgewidth': 0.8,
                     'markeredgecolor': '#4E41D9',
                 },
                 sample_legend_text_style={
                     'fontsize': 18,
                     'rotation': 45,
                     'horizontalalignment': 'right',
                     'verticalalignment': 'top',
                     'weight': 'bold',
                     'color': '#4E41D9',
                 },
                 phenotype_legend_marker_style={
                     'markersize': 18,
                     'markeredgewidth': 0.8,
                     'markeredgecolor': '#20D9BA',
                 },
                 phenotype_legend_text_style={
                     'fontsize': 18,
                     'weight': 'bold',
                     'color': '#20D9BA',
                 }):
        """
        Initialize a GPSMap.
        Arguments:
            node_x_sample (dataframe): (n_nodes, n_samples)
            std_max (number):
            n_dimensions (int):
            mds_distance_function (callable):
            mds_random_seed (int):
            node_x_dimension (array): (n_nodes, n_dimensions)
            n_pulls (int):
            pull_power (number):
            figure_size (iterable):
            title_style (dict):
            subtitle_style (dict):
            node_marker_style (dict):
            node_text_style (dict):
            triangulation_style (dict):
            background_color_alpha_factor (number):
            background_boundary_color (matplotlib color):
            n_contours (int):
            contour_style (dict):
            sample_marker_style (dict):
            sample_text_style (dict):
            legend_spacing (number):
            sample_legend_marker_style (dict):
            sample_legend_text_style (dict):
            phenotype_legend_marker_style (dict):
            phenotype_legend_text_style (dict):
        Returns:
            GPSMap:
        """

        self._check_node_x_sample(node_x_sample)

        self._nodes = node_x_sample.index.tolist()
        self._samples = node_x_sample.columns.tolist()
        self._projected_samples = None

        # Normalize node_x_sample and remember normalizing parameters
        normalized_rows = empty(node_x_sample.shape)

        self._normalizing_means = empty(node_x_sample.shape[0])
        self._normalizing_stds = empty(node_x_sample.shape[0])
        self._normalizing_mins = empty(node_x_sample.shape[0])
        self._normalizing_maxs = empty(node_x_sample.shape[0])

        self._std_max = std_max

        for i, row in enumerate(node_x_sample.values):

            self._normalizing_means[i] = row.mean()
            self._normalizing_stds[i] = row.std()

            row = normalize_1d_array(row, '-0-')
            row = row.clip(-self._std_max, self._std_max)

            self._normalizing_mins[i] = row.min()
            self._normalizing_maxs[i] = row.max()

            row = normalize_1d_array(row, '0-1')

            normalized_rows[i] = row

        self._node_x_sample = DataFrame(
            normalized_rows, index=self._nodes, columns=self._samples)
        self._node_x_projected_sample = None

        if node_x_dimension is None:

            self._n_dimensions = n_dimensions

            self._node_x_dimension = DataFrame(
                make_node_x_dimension(self._node_x_sample, self._n_dimensions,
                                      mds_distance_function, mds_random_seed),
                index=self._nodes)
        else:
            if not node_x_dimension.index.equals(self._node_x_sample.index):
                raise ValueError(
                    'Nodes of node_x_dimension and node_x_sample must be the same.'
                )
            self._n_dimensions = node_x_dimension.shape[1]
            self._node_x_dimension = node_x_dimension

        convexhull = ConvexHull(self._node_x_dimension)
        self._boundary = Path(convexhull.points[convexhull.vertices])

        self._n_pulls = n_pulls
        self._pull_power = pull_power
        self._sample_x_dimension = DataFrame(
            make_sample_x_dimension(self._node_x_sample.values,
                                    self._node_x_dimension.values,
                                    self._n_pulls, self._pull_power),
            index=self._samples)
        self._projected_sample_x_dimension = None

        self._phenotypes = None
        self._sample_phenotypes = None
        self._projected_sample_phenotypes = None

        self._ax = None

        self.title_style = title_style
        self.subtitle_style = subtitle_style

        self.node_marker_style = node_marker_style
        self.node_text_style = node_text_style

        self.triangulation_style = triangulation_style

        self.background_color_alpha_factor = background_color_alpha_factor
        self.background_boundary_color = background_boundary_color

        self.n_contours = n_contours
        self.contour_style = contour_style

        self.sample_marker_style = sample_marker_style
        self.sample_text_style = sample_text_style

        self.legend_spacing = legend_spacing
        self.sample_legend_marker_style = sample_legend_marker_style
        self.sample_legend_text_style = sample_legend_text_style

        self.phenotype_legend_marker_style = phenotype_legend_marker_style
        self.phenotype_legend_text_style = phenotype_legend_text_style

    def load(file_path):
        """
        Load GPSMap from file_path.
        Arguments:
            file_path (str):
        Returns:
            gps_map (GPSMap):
        """

        with open(file_path, 'rb') as f:
            return load(f)

    def save(gps_map, file_path):
        """
        Save GPSMap to file_path.
        Arguments:
            gps_map (GPSMap):
            file_path (str):
        Returns:
            None
        """

        if not file_path.endswith('.pickle.gz'):
            file_path += '.pickle.gz'

        establish_path(file_path)

        # TODO: investigate why ax can't be pickled when using Jupyter Notebook
        gps_map._ax = None

        with open(file_path, 'wb') as f:
            dump(gps_map, f)

    def set_sample_phenotypes(self,
                              sample_phenotypes,
                              phenotype_type='categorical',
                              n_grids=256,
                              bandwidth_factor=1,
                              phenotype_color_map=CMAP_CATEGORICAL_TAB20,
                              phenotype_to_str=None):
        """
        Set sample phenotypes.
        Arguments:
            sample_phenotypes (Series): numbers | strs (only if categorical or
                binary)
            phenotype_type (str): 'continuous' | 'categorical' | 'binary'
            n_grids (int):
            bandwidth_factor (number):
            phenotype_color_map (matplotlib.cm):
            phenotype_to_str (dict):
        Returns:
            None
        """

        phenotype_to_n = sample_phenotypes.value_counts()
        if (phenotype_to_n < 3).any():
            raise ValueError(
                'A phenotype cannot have less than 3 samples: {}.'.format(
                    phenotype_to_n))

        if not sample_phenotypes.index.equals(self._node_x_sample.columns):
            raise ValueError(
                'Sample of sample_phenotypes and node_x_sample must be the same.'
            )

        if not issubdtype(sample_phenotypes, number):
            raise ValueError('sample_phenoetypes must be numbers.')

        self._n_grids = n_grids

        if phenotype_type == 'continuous':

            sample_phenotypes = Series(
                normalize_1d_array(sample_phenotypes, '-0-'),
                index=sample_phenotypes.index,
                name=sample_phenotypes.name)

            self._sample_phenotypes = sample_phenotypes

            self._grid_values, self._grid_phenotypes = make_grid_values_and_continuous_phenotypes(
                self._sample_x_dimension.values, self._sample_phenotypes,
                self._n_grids)

        elif phenotype_type in ('categorical', 'binary'):

            self._sample_phenotypes = sample_phenotypes

            self._grid_values, self._grid_phenotypes = make_grid_values_and_categorical_phenotypes(
                self._sample_x_dimension.values, self._sample_phenotypes,
                self._n_grids, bandwidth_factor)

        else:
            raise ValueError(
                'Unknown phenotype_type: {}.'.format(phenotype_type))

        self._phenotypes = sorted(set(self._sample_phenotypes))
        self._phenotype_type = phenotype_type
        self._phenotype_color_map = phenotype_color_map
        self._phenotype_to_str = phenotype_to_str

        if self._projected_samples is not None:
            self.project_samples(
                self._node_x_projected_sample,
                normalization_method=self._projection_normalization_method)

    def project_samples(self, node_x_sample, normalization_method=None):
        """
        Project samples.
        Arguments:
            node_x_sample (dataframe): (n_nodes, n_samples)
            normalization_method (str): 'by_data' | 'by_map' | None
        Returns:
            Series: (n_samples); predicted sample phenotypes
        """

        self._check_node_x_sample(node_x_sample)

        nodes = node_x_sample.index.tolist()
        if self._nodes != nodes:
            raise ValueError(
                'Nodes of node_x_dimension and node_x_sample must be the same.'
            )

        self._projected_samples = node_x_sample.columns.tolist()

        self._projection_normalization_method = normalization_method

        normalized_rows = empty(node_x_sample.shape)

        for i, row in enumerate(node_x_sample.values):

            mean = self._normalizing_means[i]
            std = self._normalizing_stds[i]
            min_ = self._normalizing_mins[i]
            max_ = self._normalizing_maxs[i]

            if normalization_method == 'by_data':
                row = normalize_1d_array(row, '-0-')

            elif normalization_method == 'by_map':
                row = (row - mean) / std

            if normalization_method in ('by_data', 'by_map'):
                row = row.clip(-self._std_max, self._std_max)

            if normalization_method == 'by_data':
                row = normalize_1d_array(row, '0-1')

            elif normalization_method == 'by_map':
                row = (row - min_) / (max_ - min_)

            normalized_rows[i] = row

        self._node_x_projected_sample = DataFrame(
            normalized_rows, index=nodes, columns=self._projected_samples)

        self._projected_sample_x_dimension = DataFrame(
            make_sample_x_dimension(self._node_x_projected_sample.values,
                                    self._node_x_dimension.values,
                                    self._n_pulls, self._pull_power),
            index=self._projected_samples)

        if self._phenotypes is not None:

            if self._phenotype_type == 'continuous':
                predicted_phenotypes = regress(self._node_x_sample.T,
                                               self._sample_phenotypes,
                                               self._node_x_projected_sample.T)
            else:
                predicted_phenotypes = classify(
                    self._node_x_sample.T, self._sample_phenotypes,
                    self._node_x_projected_sample.T)

            self._projected_sample_phenotypes = Series(
                predicted_phenotypes,
                name='Projected Sample Phenotypes',
                index=self._projected_samples)

        return self._projected_sample_phenotypes

    def _check_node_x_sample(self, node_x_sample):
        """
        """

        # Check for any duplicated node
        if (1 < node_x_sample.index.value_counts()).any():
            raise ValueError('node_x_sample cannot have duplicated nodes.')

        # Check for any duplicated sample
        if (1 < node_x_sample.columns.value_counts()).any():
            raise ValueError('node_x_sample cannot have duplicated samples.')

        # Check for any null
        if node_x_sample.isnull().values.any():
            raise ValueError('node_x_sample cannot have any null.')

        # TODO: check for data type
        # TODO: check for any row with only 1 number

    def plot_titles_nodes_and_triangulation(self,
                                            figure_size=FIGURE_SIZE,
                                            title=None,
                                            subtitle=None,
                                            file_path=None):
        """
        Plot titles, nodes, and triangulation.
        Arguments:
            figure_size (iterable):
            tltle (str):
            subtitle (str):
            file_path (str):
        Returns:
            None
        """

        self._make_ax(figure_size)
        self._plot_title(title)
        self._plot_subtitle(subtitle)
        self._plot_nodes()
        self._plot_triangulation()

        if file_path:
            save_plot(file_path)

    def plot_samples(self,
                     sample_type='original',
                     figure_size=FIGURE_SIZE,
                     title=None,
                     subtitle=None,
                     samples_to_be_emphasized=None,
                     plot_sample_text=False,
                     file_path=None):
        """
        Plot titles, nodes, and triangulation.
        Plot samples.
        Arguments:
            sample_type (str): 'original' | 'projected'
            figure_size (iterable):
            tltle (str):
            subtitle (str):
            samples_to_be_emphasized (iterable):
            plot_sample_text (bool):
            file_path (str):
        Returns:
            None
        """

        if sample_type == 'original':
            sample_x_dimension = self._sample_x_dimension

        elif sample_type == 'projected':
            if self._projected_samples is None:
                raise ValueError('Projected samples are not set.')

            sample_x_dimension = self._projected_sample_x_dimension

            subtitle = '{} nodes, {} samples, and {} phenotypes'.format(
                len(self._nodes),
                len(self._projected_samples), len(self._phenotypes))

        else:
            raise ValueError('Unknown sample_type: {}.'.format(sample_type))

        self.plot_titles_nodes_and_triangulation(
            figure_size=figure_size, title=title, subtitle=subtitle)

        plot_samples(
            sample_x_dimension,
            ax=self._ax,
            samples_to_be_emphasized=samples_to_be_emphasized,
            plot_sample_text=plot_sample_text,
            sample_z_order=5,
            legend_z_order=0)

        if file_path:
            save_plot(file_path)

    def plot_samples_with_phenotype(self,
                                    sample_type='original',
                                    figure_size=FIGURE_SIZE,
                                    title=None,
                                    subtitle=None,
                                    samples_to_be_emphasized=None,
                                    plot_sample_text=False,
                                    file_path=None):
        """
        Plot titles, nodes, and triangulation.
        Plot samples with phenotypes.
        Arguments:
            sample_type (str): 'original' | 'projected'
            figure_size (iterable):
            tltle (str):
            subtitle (str):
            samples_to_be_emphasized (iterable):
            plot_sample_text (bool):
            file_path (str):
        Returns:
            None
        """

        if self._phenotypes is None:
            raise ValueError(
                'Sample phenotypes are not set. Call <gps_map>.set_sample_phenotypes(...) before <gps_map>.plot_samples_with_phenotype(...).'
            )

        if sample_type == 'original':
            sample_x_dimension = self._sample_x_dimension
            sample_x_annotation = DataFrame(self._sample_phenotypes)

        elif sample_type == 'projected':
            if self._projected_samples is None:
                raise ValueError('Projected samples are not set.')

            sample_x_dimension = self._projected_sample_x_dimension
            sample_x_annotation = DataFrame(self._projected_sample_phenotypes)

            subtitle = '{} nodes, {} samples, and {} phenotypes'.format(
                len(self._nodes),
                len(self._projected_samples), len(self._phenotypes))

        else:
            raise ValueError('Unknown sample_type: {}.'.format(sample_type))

        self.plot_titles_nodes_and_triangulation(
            figure_size=figure_size, title=title, subtitle=subtitle)

        self._plot_background_color()
        self._plot_contour()
        if self._phenotype_type != 'continuous':
            self._plot_phenotype_legend(self.legend_spacing)

        plot_samples(
            sample_x_dimension,
            sample_x_annotation=sample_x_annotation,
            annotation_types=[self._phenotype_type],
            annotation_color_maps=[self._phenotype_color_map],
            annotation_to_strs=[self._phenotype_to_str],
            ax=self._ax,
            samples_to_be_emphasized=samples_to_be_emphasized,
            sample_marker_style=self.sample_marker_style,
            plot_sample_text=plot_sample_text,
            sample_text_style=self.sample_text_style,
            legend_marker_style=self.sample_legend_marker_style,
            legend_text_style=self.sample_legend_text_style,
            sample_z_order=5,
            legend_z_order=0)

        if file_path:
            save_plot(file_path)

    def plot_samples_with_annotations(self,
                                      sample_x_annotation,
                                      annotation_types,
                                      sample_type='original',
                                      annotation_max_stds=None,
                                      annotation_color_maps=None,
                                      annotation_ranges=None,
                                      annotation_to_strs=None,
                                      figure_size=FIGURE_SIZE,
                                      title=None,
                                      subtitle=None,
                                      samples_to_be_emphasized=None,
                                      plot_sample_text=False,
                                      violin_or_box='box',
                                      file_path=None):
        """
        Plot titles, nodes, and triangulation.
        Plot samples with annotations.
        Arguments:
            sample_x_annotation (DataFrame): (n_samples, n_annotations); numbers
            annotation_types (iterable): (n_annotations); strs; 'continuous' |
                'categorical' | 'binary'
            sample_type (str): 'original' | 'projected'
            annotation_max_stds (iterable): (n_annotations); STD for normalizing
            annotation_color_maps (iterable): (n_annotations); matplotlib.cms
            annotation_ranges (iterable): (n_annotations); [[min, max], ...]
            annotation_to_strs (iterable): (n_annotations); dicts
            figure_size (iterable):
            title (str):
            subtitle (str):
            samples_to_be_emphasized (iterable):
            plot_sample_text (bool):
            violin_or_box (str): 'violin' | 'box'
            file_path (str):
        Returns:
            None
        """

        if sample_type == 'original':
            sample_x_dimension = self._sample_x_dimension

        elif sample_type == 'projected':
            if self._projected_samples is None:
                raise ValueError('Projected samples are not set.')

            sample_x_dimension = self._projected_sample_x_dimension

            subtitle = '{} nodes, {} samples, and {} phenotypes'.format(
                len(self._nodes),
                len(self._projected_samples), len(self._phenotypes))

        else:
            raise ValueError('Unknown sample_type: {}.'.format(sample_type))

        self.plot_titles_nodes_and_triangulation(
            figure_size=figure_size, title=title, subtitle=subtitle)

        if self._phenotypes is not None:

            self._plot_background_color()
            self._plot_contour()
            if self._phenotype_type != 'continuous':
                self._plot_phenotype_legend(self.legend_spacing)

        plot_samples(
            sample_x_dimension,
            sample_x_annotation=sample_x_annotation,
            annotation_types=annotation_types,
            annotation_max_stds=annotation_max_stds,
            annotation_color_maps=annotation_color_maps,
            annotation_ranges=annotation_ranges,
            annotation_to_strs=annotation_to_strs,
            ax=self._ax,
            samples_to_be_emphasized=samples_to_be_emphasized,
            sample_marker_style=self.sample_marker_style,
            plot_sample_text=plot_sample_text,
            sample_text_style=self.sample_text_style,
            legend_marker_style=self.sample_legend_marker_style,
            legend_text_style=self.sample_legend_text_style,
            sample_z_order=5,
            legend_z_order=0)

        if file_path:
            save_plot(file_path)

        if self._phenotypes is not None:

            sample_x_annotation = sample_x_annotation.loc[
                sample_x_dimension.index]

            for a_i, (a_name, a) in enumerate(sample_x_annotation.items()):

                plot_violin_box_or_bar(
                    self._sample_phenotypes,
                    a,
                    violin_or_box=violin_or_box,
                    palette=[
                        self._phenotype_color_map(p) for p in self._phenotypes
                    ],
                    figure_size=[ceil(d / 2) for d in figure_size])

    def plot_phenotype_centroids(self,
                                 figure_size=FIGURE_SIZE,
                                 title=None,
                                 subtitle=None,
                                 centroid_marker_style={
                                     'markersize': 48,
                                     'markeredgewidth': 2.8,
                                     'markeredgecolor': '#000000',
                                 },
                                 plot_sample_text=True,
                                 centroid_text_style={
                                     'fontsize': 28,
                                     'weight': 'bold',
                                     'color': '#000726',
                                 },
                                 file_path=None):
        """
        Plot phenotype centroids.
        Arguments:
            figure_size (iterable):
            tltle (str):
            subtitle (str):
            centroid_marker_style (dict):
            plot_sample_text (bool):
            centroid_text_style (dict):
            file_path (str):
        Returns:
            None
        """

        if self._phenotypes is None:
            raise ValueError(
                'Sample phenotypes are not set. Call <gps_map>.set_sample_phenotypes(...) before <gps_map>.plot_samples_with_phenotype(...).'
            )

        self.plot_titles_nodes_and_triangulation(
            figure_size=figure_size, title=title, subtitle=subtitle)

        node_x_centroid = self._node_x_sample.groupby(
            by=self._sample_phenotypes, axis=1).mean()

        centroid_x_dimension = DataFrame(
            make_sample_x_dimension(node_x_centroid.values,
                                    self._node_x_dimension.values,
                                    self._n_pulls, self._pull_power))

        self._plot_background_color()
        self._plot_contour()
        if self._phenotype_type != 'continuous':
            self._plot_phenotype_legend(self.legend_spacing)

        plot_samples(
            centroid_x_dimension,
            sample_x_annotation=DataFrame(self._phenotypes),
            annotation_types=[self._phenotype_type],
            annotation_color_maps=[self._phenotype_color_map],
            annotation_to_strs=[self._phenotype_to_str],
            ax=self._ax,
            sample_marker_style=centroid_marker_style,
            plot_sample_text=plot_sample_text,
            sample_text_style=centroid_text_style,
            sample_z_order=5,
            legend_z_order=0)

        if file_path:
            save_plot(file_path)

    def _make_ax(self, figure_size):
        """
        """

        self._ax = figure(figsize=figure_size).gca()
        self._ax.set_xlim((0, 1))
        self._ax.set_ylim((0, 1))
        self._ax.set_axis_off()

    def _plot_title(self, title, z_order=0):
        """
        """

        if not title:
            title = 'GPS Map'

        self._ax.text(
            0, 1.18, title, clip_on=False, zorder=z_order, **self.title_style)

    def _plot_subtitle(self, subtitle, z_order=0):
        """
        """

        if not subtitle:

            if self._phenotypes is None:
                subtitle = '{} nodes and {} samples'.format(
                    len(self._nodes), len(self._samples))

            else:
                subtitle = '{} nodes, {} samples, and {} phenotypes'.format(
                    len(self._nodes), len(self._samples),
                    len(self._phenotypes))

        self._ax.text(
            0,
            1.13,
            subtitle,
            clip_on=False,
            zorder=z_order,
            **self.subtitle_style)

    def _plot_nodes(self, z_order=4):
        """
        """

        self._ax.plot(
            self._node_x_dimension[0],
            self._node_x_dimension[1],
            linestyle='',
            aa=True,
            clip_on=False,
            zorder=z_order,
            **self.node_marker_style)

        for i in self._node_x_dimension.index:

            x, y = self._node_x_dimension.loc[i]
            if x < 0.5:
                x -= 0.05
            elif 0.5 < x:
                x += 0.05
            if y < 0.5:
                y -= 0.05
            elif 0.5 < y:
                y += 0.05

            self._ax.text(
                x,
                y,
                i,
                horizontalalignment='center',
                verticalalignment='center',
                clip_on=False,
                zorder=z_order,
                **self.node_text_style)

    def _plot_triangulation(self, z_order=3):
        """
        """

        triangulation = Delaunay(self._node_x_dimension)

        self._ax.triplot(
            triangulation.points[:, 0],
            triangulation.points[:, 1],
            triangulation.simplices.copy(),
            aa=True,
            clip_on=False,
            zorder=z_order,
            **self.triangulation_style)

    def _plot_background_color(self, z_order=1):
        """
        """

        self._background_colors = ones(
            (*([self._n_grids] * self._n_dimensions), 3))

        mins = [0] * self._n_dimensions
        maxs = [self._n_grids - 1] * self._n_dimensions
        grid_sizes = [self._n_grids] * self._n_dimensions

        index_and_fraction_grid_coordinates_pair = make_index_and_fraction_grid_coordinates_pair(
            mins, maxs, grid_sizes)

        grid_values_min = self._grid_values.min()
        grid_values_max = self._grid_values.max()
        grid_values_range = grid_values_max - grid_values_min

        for indices, coordinates in index_and_fraction_grid_coordinates_pair:

            if self._boundary.contains_point(coordinates):

                if self._phenotype_type == 'continuous':
                    i = self._grid_phenotypes[indices] * self._grid_values[
                        indices]
                else:
                    i = self._grid_phenotypes[indices]
                c = self._phenotype_color_map(i)

                hsv = rgb_to_hsv(*c[:3])

                p = self._grid_values[indices]

                pn = (p - grid_values_min) / grid_values_range

                rgb = hsv_to_rgb(hsv[0],
                                 pn * self.background_color_alpha_factor,
                                 hsv[2] * pn + (1 - pn))

                self._background_colors[indices[::-1]] = rgb

        if self.background_boundary_color is not None:

            background_boundary_color = to_rgb(self.background_boundary_color)

            for indices, coordinates in index_and_fraction_grid_coordinates_pair:

                if self._boundary.contains_point(coordinates):

                    p = self._grid_phenotypes[indices]
                    i, j = indices
                    p_d = self._grid_phenotypes[i + 1, j]
                    p_r = self._grid_phenotypes[i, j + 1]

                    if p != p_d or p != p_r:
                        self._background_colors[
                            indices[::-1]] = background_boundary_color

        self._ax.imshow(
            self._background_colors,
            interpolation=None,
            origin='lower',
            aspect='auto',
            extent=self._ax.axis(),
            clip_on=False,
            zorder=z_order)

    def _plot_contour(self, z_order=2):
        """
        """

        if self._phenotype_type == 'continuous':
            phenotypes = [-1, 1]
        else:
            phenotypes = self._phenotypes

        for p in phenotypes:

            mask = zeros([self._n_grids] * self._n_dimensions, dtype=bool)

            mins = [0] * self._n_dimensions
            maxs = [self._n_grids - 1] * self._n_dimensions
            grid_sizes = [self._n_grids] * self._n_dimensions

            for indices, coordinates in make_index_and_fraction_grid_coordinates_pair(
                    mins, maxs, grid_sizes):

                if not self._boundary.contains_point(
                        coordinates) or self._grid_phenotypes[indices] != p:
                    mask[indices] = True

            self._ax.contour(
                ma_array(self._grid_values, mask=mask).transpose(),
                self.n_contours,
                origin='lower',
                aspect='auto',
                extent=self._ax.axis(),
                corner_mask=True,
                linestyle='solid',
                aa=True,
                clip_on=False,
                zorder=z_order,
                **self.contour_style)

    def _plot_phenotype_legend(self, spacing, z_order=0):
        """
        """

        for i, p in enumerate(sorted(self._phenotypes)):

            y = 1 - (i + 1) / (len(self._phenotypes) + 1)

            c = self._phenotype_color_map(p)

            self._ax.plot(
                1 + spacing,
                y,
                marker='s',
                color=c,
                aa=True,
                clip_on=False,
                zorder=z_order,
                **self.phenotype_legend_marker_style)

            self._ax.text(
                1 + spacing + 0.02,
                y,
                'Phenotype {} (n={})'.format(
                    p, (self._sample_phenotypes == p).sum()),
                verticalalignment='center',
                clip_on=False,
                zorder=z_order,
                **self.phenotype_legend_text_style)
