from sklearn.svm import SVC

RANDOM_SEED = 20121020


def classify(training,
             training_classes,
             testing,
             c=1.0,
             kernel='rbf',
             degree=3,
             gamma='auto',
             coef0=0.0,
             shrinking=True,
             probability=False,
             tol=0.001,
             cache_size=200,
             class_weight=None,
             verbose=False,
             max_iter=-1,
             decision_function_shape=None,
             random_seed=RANDOM_SEED):
    """
    Train a classifier using training and predict the classes of testing.
    Arguments:
        training (array | DataFrame): (n_training_samples, n_dimensions)
        training_classes (array | Series): (n_training_samples)
        testing (array | DataFrame): (n_testing_samples, n_dimensions)
        c:
        kernel:
        degree:
        gamma:
        coef0:
        shrinking:
        probability:
        tol:
        cache_size:
        class_weight:
        verbose:
        max_iter:
        decision_function_shape:
        random_seed:
    Returns:
        array: (n_testing_samples)
    """

    clf = SVC(
        C=c,
        kernel=kernel,
        degree=degree,
        gamma=gamma,
        coef0=coef0,
        shrinking=shrinking,
        probability=probability,
        tol=tol,
        cache_size=cache_size,
        class_weight=class_weight,
        verbose=verbose,
        max_iter=max_iter,
        decision_function_shape=decision_function_shape,
        random_state=random_seed)

    clf.fit(training, training_classes)

    return clf.predict(testing)
