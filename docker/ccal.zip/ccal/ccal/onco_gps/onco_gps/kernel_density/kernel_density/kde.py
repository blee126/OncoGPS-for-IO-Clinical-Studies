from statsmodels.nonparametric.kernel_density import KDEMultivariate

from .nd_array.nd_array.make_nd_grid_coordinates import \
    make_nd_grid_coordinates


def kde(coordinates,
        variable_types,
        bandwidths='cv_ml',
        mins=(),
        maxs=(),
        grid_sizes=(),
        grid_size=64):
    """
    Compute Gaussian-KDE(coordinates) and evaluate at grid coordinates.
    Arguments:
        coordinates (iterable): (n_dimensions); array per dimension; KDE
            coordinates
        variable_types (str): (n_dimensions); KDE coordinates' type: 'c'
            (continuous) | 'u' (unordered) | 'o' (ordered)
        bandwidths (iterable | str): (n_dimensions); KDE coordinates'
            bandwidth or bandwidths-computing method: 'cv_ls' | 'cv_ml' |
            'normal_reference'
        mins (iterable): (n_dimensions); grid coordinates' min
        maxs (iterable): (n_dimensions); grid coordinates' max
        grid_sizes (iterable): (n_dimensions); grid coordinates' size
        grid_size (int): grid coordinates' size when grid_sizes is ()
    Returns:
        array: (n_dimensions); Gaussian-KDE(coordinates) evaluated at grid
            coordinates
    """

    # Compute Gaussian-KDE(coordinates) (indexed by: d0, ..., d(n-1))
    kd = KDEMultivariate(coordinates, var_type=variable_types, bw=bandwidths)

    # Set mins, maxs, and grid_sizes
    if not mins:
        mins = [a.min() for a in coordinates]
    if not maxs:
        maxs = [a.max() for a in coordinates]
    if not grid_sizes:
        grid_sizes = [grid_size for i in range(len(coordinates))]

    # Make grid coordinates with 'ij' indexing [ordered by d0, ..., d(n - 1)]
    grid_coordinates = make_nd_grid_coordinates(mins, maxs, grid_sizes)

    # Evaluate Gaussian-KDE(coordinates) at grid coordinates, and reshape
    return kd.pdf(grid_coordinates).reshape(grid_sizes)
