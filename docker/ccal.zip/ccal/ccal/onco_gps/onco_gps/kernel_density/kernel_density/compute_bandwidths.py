from statsmodels.nonparametric.kernel_density import KDEMultivariate


def compute_bandwidths(coordinates, variable_types, bandwidths='cv_ml'):
    """
    Compute bandwidths.
    Arguments:
        coordinates (iterable): (n_dimensions); array per dimension; KDE
            coordinates
        variable_types (str): (n_dimensions); KDE coordinates' type: 'c'
            (continuous) | 'u' (unordered) | 'o' (ordered)
        bandwidths (iterable | str): (n_dimensions); KDE coordinates'
            bandwidth or bandwidths-computing method: 'cv_ls' | 'cv_ml' |
            'normal_reference'
    Returns:
        array: (n_dimensions); bandwidths
    """

    kde = KDEMultivariate(coordinates, var_type=variable_types, bw=bandwidths)

    return kde.bw
