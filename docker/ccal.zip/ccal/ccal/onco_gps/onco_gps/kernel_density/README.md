# Kernal Density

Library for working with kernel densities (KDE) :bell:
