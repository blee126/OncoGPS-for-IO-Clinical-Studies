from sklearn.manifold import MDS

from .nd_array.nd_array.apply_function_on_2_2d_arrays_slices import \
    apply_function_on_2_2d_arrays_slices

RANDOM_SEED = 20121020


def mds(point_x_dimension,
        n_target_dimensions=2,
        distance_function='euclidean',
        metric=True,
        n_init=1000,
        max_iter=1000,
        verbose=0,
        eps=1e-3,
        n_jobs=1,
        random_seed=RANDOM_SEED):
    """
    Multidimensional scale rows of point_x_dimension from n_dimensions into
        n_target_dimensions dimensions.
    Arguments:
        point_x_dimension (array): (n_points, n_dimensions)
        n_target_dimensions (int): number of final dimensions
        distance_function (str | callable):
        metric:
        n_init (int):
        max_iter (int):
        verbose:
        eps:
        n_jobs:
        random_seed (int | array): random seed for the initial point_x_target_dimension
    Returns;
        array: (n_points, n_target_dimensions)
    """

    if isinstance(distance_function, str):

        mds_ = MDS(
            n_components=n_target_dimensions,
            dissimilarity=distance_function,
            metric=metric,
            n_init=n_init,
            max_iter=max_iter,
            verbose=verbose,
            eps=eps,
            n_jobs=n_jobs,
            random_state=random_seed)

        point_x_target_dimension = mds_.fit_transform(point_x_dimension)

    else:

        mds_ = MDS(
            n_components=n_target_dimensions,
            dissimilarity='precomputed',
            metric=metric,
            n_init=n_init,
            max_iter=max_iter,
            verbose=verbose,
            eps=eps,
            n_jobs=n_jobs,
            random_state=random_seed)

        point_x_target_dimension = mds_.fit_transform(
            apply_function_on_2_2d_arrays_slices(
                point_x_dimension,
                point_x_dimension,
                distance_function,
                axis=1))

    return point_x_target_dimension
