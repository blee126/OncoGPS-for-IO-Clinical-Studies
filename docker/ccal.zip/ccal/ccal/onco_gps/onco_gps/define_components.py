from .cluster.cluster.nmf_consensus_cluster_with_multiple_ks import \
    nmf_consensus_cluster_with_multiple_ks

RANDOM_SEED = 20121020


def define_components(df,
                      ks,
                      directory_path,
                      n_jobs=1,
                      n_clusterings=100,
                      algorithm='als',
                      random_seed=RANDOM_SEED):
    """
    NMF consensus cluster df columns into ks clusters and compute cophenetic
        correlation coefficients (CCC).
    Arguments:
        df (DataFrame): (n_rows, n_columns): A matrix
        ks (iterable): ks for NMF
        directory_path (str): where output files are save
        n_jobs (int):
        n_clusterings (int): number of NMF for consensus clustering
        algorithm (str): 'als' | 'ls'
        random_seed (int | array):
    Returns:
        dict: {k: {w: W, h: H, e: reconstruction error}}; NMFs
        DataFrame: (n_ks, n_samples); Cs
        Series: (n_ks); CCCs
    """

    # NMF-consensus cluster (while saving 1 NMF result per k)
    nmfs, cs, cccs = nmf_consensus_cluster_with_multiple_ks(
        df,
        ks,
        n_jobs=n_jobs,
        n_clusterings=n_clusterings,
        algorithm=algorithm,
        random_seed=random_seed,
        directory_path=directory_path)

    return nmfs, cs, cccs
