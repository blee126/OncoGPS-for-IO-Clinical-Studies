from .cluster.cluster.hierarchical_consensus_cluster_with_multiple_ks import \
    hierarchical_consensus_cluster_with_multiple_ks

RANDOM_SEED = 20121020


def define_states(df,
                  ks,
                  directory_path,
                  distances=None,
                  n_jobs=1,
                  std_max=3,
                  n_clusterings=100,
                  random_seed=RANDOM_SEED):
    """
    Hierarchical consensus cluster array_2d columns and compute cophenetic
        correlation coefficients (CCC).
    Arguments:
        df (DataFrame): (n_features, n_samples)
        ks (iterable): (n_ks); ks for clustering
        directory_path (str): where output files are save
        distances (array | DataFrame): (n_samples, n_samples); distances
        n_jobs (int): number of parallel jobs
        std_max (number):
        n_clusterings (int): number of hierarchical clusterings for consensus
        random_seed (float | array):
    Returns:
        DataFrame: (n_samples, n_samples); distances
        list: hierarchical clustering object or linkage object per k
        DataFrame: (n_ks, n_samples); Cs
        Series: (n_ks); CCCs
    """

    # Hierarchical-consensus cluster
    ds, hcs, cs, cccs = hierarchical_consensus_cluster_with_multiple_ks(
        df,
        ks,
        distances=distances,
        n_jobs=n_jobs,
        n_clusterings=n_clusterings,
        random_seed=random_seed,
        directory_path=directory_path)

    return ds, hcs, cs, cccs
