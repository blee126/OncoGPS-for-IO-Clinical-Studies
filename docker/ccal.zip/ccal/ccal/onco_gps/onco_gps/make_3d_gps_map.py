# def make_3d_gps_map(training_h,
#                     training_states,
#                     file_path,
#                     std_max=3,
#                     mds_seed=RANDOM_SEED,
#                     power=None,
#                     fit_min=0,
#                     fit_max=2,
#                     power_min=1,
#                     power_max=5,
#                     samples_to_plot=(),
#                     training_annotation=(),
#                     title='3D Onco-GPS',
#                     titlefont_size=39,
#                     titlefont_color='4E41D9',
#                     paper_bgcolor='FFFFFF',
#                     plot_bgcolor='000000',
#                     component_marker_size=26,
#                     component_marker_opacity=0.92,
#                     component_marker_line_width=2.2,
#                     component_marker_line_color='9017E6',
#                     component_marker_color='000726',
#                     component_textfont_size=22,
#                     component_textfont_color='FFFFFF',
#                     state_colors=(),
#                     sample_marker_size=13,
#                     sample_marker_opacity=0.92,
#                     sample_marker_line_width=0.19,
#                     sample_marker_line_color='9017E6'):
#     """
#
#     training_h:
#     training_states:
#     file_path:
#     std_max:
#     mds_seed:
#     power:
#     fit_min:
#     fit_max:
#     power_min:
#     power_max:
#     samples_to_plot:
#     training_annotation:
#     title:
#     titlefont_size:
#     titlefont_color:
#     paper_bgcolor:
#     plot_bgcolor:
#     component_marker_size:
#     component_marker_opacity:
#     component_marker_line_width:
#     component_marker_line_color:
#     component_marker_color:
#     component_textfont_size:
#     component_textfont_color:
#     state_colors:
#     sample_marker_size:
#     sample_marker_opacity:
#     sample_marker_line_width:
#     sample_marker_line_color:
#     :return:
#     """
#
#     # ==========================================================================
#     # Process training H matrix
#     #   Set H matrix's indices to be str (better for .ix)
#     #   Drop samples with all-0 values before normalization
#     #   Normalize H matrix (May save normalizing parameters for normalizing
#     # testing H matrix later)
#     #       -0- normalize
#     #       Clip values over 3 standard deviation
#     #       0-1 normalize
#     #   Drop samples with all-0 values after normalization
#     # ==========================================================================
#     training_h = drop_slices(training_h, 0)
#     training_h = normalize_2d(training_h, '-0-', axis=1)
#     training_h = training_h.clip(-std_max, std_max)
#     training_h = normalize_2d(training_h, '0-1', axis=1)
#     training_h = drop_slices(training_h, 0)
#
#     # ==========================================================================
#     # Get training component coordinates
#     # ==========================================================================
#     print('Computing component coordinates using informational distance ...')
#     dissimilarity = information_coefficient
#     components = mds(
#         training_h,
#         n_components=3,
#         dissimilarity=dissimilarity,
#         random_seed=mds_seed)
#     components = DataFrame(
#         components, index=training_h.index, columns=['x', 'y', 'z'])
#     components = normalize_2d(components, '-0-', axis=0)
#
#     # ==========================================================================
#     # Get training component power
#     #   If n_pulls is not specified, all components pull a sample
#     #   If power is not specified, compute component power by fitting (power
#     # will be 1 if fitting fails)
#     # ==========================================================================
#     n_pulls = training_h.shape[0]
#     if not power:
#         print('Computing component power ...')
#         if training_h.shape[0] < 4:
#             print('\tCould\'t model with Ae^(kx) + C; too few data points.')
#             power = 1
#         else:
#             try:
#                 power = _compute_component_power(training_h, fit_min, fit_max,
#                                                  power_min, power_max)
#             except RuntimeError as e:
#                 power = 1
#                 print(
#                     '\tCould\'t model with Ae^(kx) + C; {}; set power to be 1.'.
#                     format(e))
#
#     # ==========================================================================
#     # Compute training sample coordinates
#     # Process training states
#     #   Series states
#     #   Keep only samples in H matrix
#     # ==========================================================================
#     training_samples = DataFrame(
#         index=training_h.columns,
#         columns=['x', 'y', 'z', 'state', 'annotation'])
#
#     print(
#         'Computing training sample coordinates using {} components and {:.3f} '
#         'power ...'.format(n_pulls, power))
#     training_samples.ix[:, ['x', 'y', 'z']] = _compute_sample_coordinates(
#         components, training_h, n_pulls, power)
#
#     training_samples.ix[:, 'state'] = Series(
#         training_states, index=training_h.columns)
#
#     # ==========================================================================
#     # Process training annotation
#     # ==========================================================================
#     if len(training_annotation):
#         # ======================================================================
#         # Series annotation
#         # Keep only samples in H matrix
#         # ======================================================================
#         if isinstance(training_annotation, Series):
#             training_samples.ix[:, 'annotation'] = training_annotation.ix[
#                 training_samples.index]
#         else:
#             training_samples.ix[:, 'annotation'] = training_annotation
#
#     # ==========================================================================
#     # Limit samples to plot
#     # Plot 3D Onco-GPS
#     # ==========================================================================
#     if len(samples_to_plot):
#         training_samples = training_samples.ix[samples_to_plot, :]
#
#     print('Plotting ...')
#     import plotly
#
#     layout = plotly.graph_objs.Layout(
#         title=title,
#         titlefont=dict(
#             size=titlefont_size,
#             color=titlefont_color, ),
#         paper_bgcolor=paper_bgcolor,
#         plot_bgcolor=plot_bgcolor, )
#
#     data = []
#     trace_components = plotly.graph_objs.Scatter3d(
#         name='Component',
#         x=components.ix[:, 'x'],
#         y=components.ix[:, 'y'],
#         z=components.ix[:, 'z'],
#         text=components.index,
#         mode='markers+text',
#         marker=dict(
#             size=component_marker_size,
#             opacity=component_marker_opacity,
#             line=dict(
#                 width=component_marker_line_width,
#                 color=component_marker_line_color, ),
#             color=component_marker_color, ),
#         textposition='middle center',
#         textfont=dict(
#             size=component_textfont_size,
#             color=component_textfont_color, ))
#     data.append(trace_components)
#
#     # Assign colors to states
#     state_colors = assign_colors(
#         training_samples.ix[:, 'state'].unique().size, colors=state_colors)
#     for s in sorted(training_samples.ix[:, 'state'].unique()):
#         trace = plotly.graph_objs.Scatter3d(
#             name='State {}'.format(s),
#             x=training_samples.ix[training_samples.ix[:, 'state'] == s, 'x'],
#             y=training_samples.ix[training_samples.ix[:, 'state'] == s, 'y'],
#             z=training_samples.ix[training_samples.ix[:, 'state'] == s, 'z'],
#             text=training_samples.index[training_samples.ix[:, 'state'] == s],
#             mode='markers',
#             marker=dict(
#                 size=sample_marker_size,
#                 opacity=sample_marker_opacity,
#                 line=dict(
#                     width=sample_marker_line_width,
#                     color=sample_marker_line_color, ),
#                 color='rgba{}'.format(state_colors[s]), ), )
#         data.append(trace)
#
#     fig = plotly.graph_objs.Figure(layout=layout, data=data)
#
#     plotly.offline.plot(fig, filename=file_path)
