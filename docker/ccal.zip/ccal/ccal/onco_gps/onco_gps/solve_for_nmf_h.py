from pandas import DataFrame

from .linear_algebra.linear_algebra.solve_ax_equal_b import solve_ax_equal_b
from .plot.plot.plot_nmf import plot_nmf


def solve_for_nmf_h(w_matrix,
                    a_matrix,
                    w_matrix_normalization_method='sum',
                    how_to_drop_na_in_a_matrix='all',
                    a_matrix_normalization_method='-0-_clip_shift',
                    a_matrix_normalization_axis=0,
                    std_max=3,
                    method='nnls',
                    file_path_prefix=None):
    """
    Sovle for H: in W * H = A.
    Arguments:
        w_matrix (DataFrame): (n_rows, k)
        a_matrix (DataFrame): (n_rows, n_columns)
        method (str): 'nnls' | 'pinv'
        file_path_prefix (str): where file_path_prefix_solved_nmf_h_k{}.{tsv,
            pdf} are saved
    Returns:
        DataFrame: (k, n_columns)
    """

    print('Solving for H in: W{} * H = A{} ...'.format(w_matrix.shape,
                                                       a_matrix.shape))
    h_matrix = solve_ax_equal_b(
        w_matrix.values,
        a_matrix.values,
        method=method,
        force_nonnegative=True)

    h_matrix = DataFrame(
        h_matrix, index=w_matrix.columns, columns=a_matrix.columns)

    if file_path_prefix:

        h_matrix.to_csv(
            file_path_prefix +
            '_solved_nmf_h_k{}.tsv'.format(h_matrix.shape[0]),
            sep='\t')

    plot_nmf(
        w_matrix=w_matrix,
        h_matrix=h_matrix,
        file_path_prefix=file_path_prefix)

    return h_matrix
