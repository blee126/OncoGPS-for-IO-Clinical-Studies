from numpy import empty, nansum, sort


def make_sample_x_dimension(node_x_sample, node_x_dimension, n_pulls,
                            pull_power):
    """
    Make sample-x-dimension.
    Arguments:
        node_x_sample (array): (n_nodes, n_samples)
        node_x_dimension (array): (n_nodes, n_dimensions)
        n_pulls (int):
        pull_power (number):
    Returns:
        array: (n_samples, n_dimensions)
    """

    sample_x_dimension = empty((node_x_sample.shape[1],
                                node_x_dimension.shape[1]))

    if not n_pulls:
        n_pulls = node_x_sample.shape[0]

    for is_ in range(node_x_sample.shape[1]):

        pulls = node_x_sample[:, is_]

        pulls[pulls < sort(pulls)[-n_pulls]] = 0

        for id_ in range(node_x_dimension.shape[1]):

            ncs = node_x_dimension[:, id_]

            scs = nansum(pulls**pull_power * ncs)
            scs /= nansum(pulls**pull_power)

            sample_x_dimension[is_, id_] = scs

    return sample_x_dimension
