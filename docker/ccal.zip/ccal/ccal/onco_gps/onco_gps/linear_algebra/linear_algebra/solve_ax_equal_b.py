from numpy import dot, empty
from numpy.linalg import pinv
from scipy.optimize import nnls


def solve_ax_equal_b(a, b, method='nnls', force_nonnegative=False):
    """
    Solve a(n, k) * x(k, m) = b(n, m) for x.
    Arguments:
        a (array): (n, k)
        b( array): (n, m)
        method (str): 'nnls' | 'pinv'
        force_nonnegative (bool):
    Returns:
        array: (k, m)
    """

    if method == 'nnls':

        x = empty((a.shape[1], b.shape[1]))

        # Solve for each column
        for i in range(b.shape[1]):
            x[:, i] = nnls(a, b[:, i])[0]

    elif method == 'pinv':

        a_pinv = pinv(a)
        x = dot(a_pinv, b)

    else:
        raise ValueError('Unknown method: {}.'.format(method))

    if force_nonnegative:
        x[x < 0] = 0

    return x
