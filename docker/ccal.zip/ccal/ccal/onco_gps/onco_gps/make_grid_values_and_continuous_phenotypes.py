from numpy import absolute, asarray, empty, zeros
from sklearn.svm import SVR

from .nd_array.nd_array.make_index_and_fraction_grid_coordinates_pair import \
    make_index_and_fraction_grid_coordinates_pair


def make_grid_values_and_continuous_phenotypes(sample_x_dimension,
                                               sample_phenotypes, n_grids):
    """
    Make grid values and continuous phenotypes.
    Arguments:
        sample_x_dimension (array): (n_samples, n_dimensions)
        sample_phenotypes (array): (n_samples)
        n_grids (int):
    Returns:
        array: (n_grids, n_grids); grid values
        array: (n_grids, n_grids); grid continuous phenotypes
    """

    n_dimensions = sample_x_dimension.shape[1]

    svr_values = SVR(kernel='rbf')
    svr_phenotype = SVR(kernel='rbf')

    svr_values.fit(sample_x_dimension, absolute(sample_phenotypes))
    svr_phenotype.fit(sample_x_dimension, sample_phenotypes)

    size = [n_grids] * n_dimensions
    grid_values = zeros(size)
    grid_phenotypes = empty(size, dtype=int)

    mins = [0] * n_dimensions
    maxs = [n_grids - 1] * n_dimensions
    grid_sizes = [n_grids] * n_dimensions

    for indices, coordinates in make_index_and_fraction_grid_coordinates_pair(
            mins, maxs, grid_sizes):

        # Predicted probability
        p = svr_values.predict(asarray([coordinates]))
        grid_values[indices] = p

        # Predicted annotation
        p = svr_phenotype.predict(asarray([coordinates]))
        if sample_phenotypes.mean() <= p:
            grid_phenotypes[indices] = 1
        else:
            grid_phenotypes[indices] = -1

    return grid_values, grid_phenotypes
