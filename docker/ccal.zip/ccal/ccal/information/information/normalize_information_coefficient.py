def normalize_information_coefficients(ics, method, clip_min=None, clip_max=None):
    """
    Normalize information coefficients.
    Arguments:
        ics (array):
        method (str): '0-1' | 'p1d2' | 'clip':
            '0-1' will normalize ics to be from 0 to 1 where the minimum ic becomes 0 and the maximum ic becomes 1;
            'p1d2' will add 1 to ics and divide it by 2, resulting in 0-1 normalization where -1 becomes 0 and 1 becomes 1;
            'clip' will just clip ics with clip_min and clip_max.
        clip_min (float):
        clip_max (float):
    Returns:
        array:
    """

    if method == '0-1':
        return (ics - ics.min()) / (ics.max() - ics.min())

    elif method == 'p1d2':
        return (ics + 1) / 2

    elif method == 'clip':
        return ics.clip(clip_min, clip_max)

    else:
        raise ValueError('Unknown method {}.'.format(method))
