import rpy2.robjects as ro
from numpy import asarray, exp, finfo, log, sign, sqrt
from numpy.random import random_sample, seed
import rpy2.robjects.numpy2ri as numpy2ri
from rpy2.robjects.packages import importr
from scipy.stats import pearsonr

RANDOM_SEED = 20121020

EPS = finfo(float).eps

# TODO: don't use R by using Python equivalent (and as fast) bcv and mass.kde2d
ro.conversion.py2ri = numpy2ri
mass = importr('MASS')
bcv = mass.bcv
kde2d = mass.kde2d


def compute_information_distance(x,
                                 y,
                                 n_grids=25,
                                 jitter=1E-10,
                                 random_seed=RANDOM_SEED):
    """
    Compute information distance between x and y, which can be continuous,
        categorical, or binary.
    Arguments:
         x (array): (2 < n)
         y (array): (2 < n)
         n_grids (int): number of grids for computing bandwidths
         jitter (number):
         random_seed (int | array):
    Returns:
         float: 0 <= information distance (1 - information coefficient) <= 2
    """

    ic = compute_information_coefficient(
        x, y, n_grids=n_grids, jitter=jitter, random_seed=random_seed)

    return (1 - ic) / 2


def compute_information_coefficient(x,
                                    y,
                                    n_grids=25,
                                    jitter=1E-10,
                                    random_seed=RANDOM_SEED):
    """
    Compute information coefficient between x and y, which can be continuous,
        categorical, or binary.
    Arguments:
         x (array): (2 < n)
         y (array): (2 < n)
         n_grids (int): number of grids for computing bandwidths
         jitter (number):
         random_seed (int | array):
    Returns:
         float: -1 <= information coefficient  <= 1
    """

    # Add jitter
    seed(random_seed)
    x = x + random_sample(x.size) * jitter
    y = y + random_sample(y.size) * jitter

    # Compute correlation to get the sign of coefficient
    cor = pearsonr(x, y)[0]

    # Compute bandwidths
    bandwidth_x = asarray(bcv(x)[0]) * (1 - abs(cor) * 0.75)
    bandwidth_y = asarray(bcv(y)[0]) * (1 - abs(cor) * 0.75)

    # Compute P(X, Y), P(X), and P(Y)
    fxy = asarray(
        kde2d(x, y, asarray([bandwidth_x, bandwidth_y]), n=asarray([n_grids]))
        [2]) + EPS
    dx = (x.max() - x.min()) / (n_grids - 1)
    dy = (y.max() - y.min()) / (n_grids - 1)
    pxy = fxy / (fxy.sum() * dx * dy)
    px = pxy.sum(axis=1) * dy
    py = pxy.sum(axis=0) * dx

    # Compute mutual information
    mi = (pxy * log(pxy / (
        asarray([px] * n_grids).T * asarray([py] * n_grids)))).sum() * dx * dy

    # Alternative way to compute MI by computing for H(x, y), H(x), and H(y)
    # hxy = - (pxy * log(pxy)).sum() * dx * dy
    # hx = -(px * log(px)).sum() * dx
    # hy = -(py * log(py)).sum() * dy
    # mi = hx + hy - hxy

    # Compute information coefficient
    ic = sign(cor) * sqrt(1 - exp(-2 * mi))

    return ic
