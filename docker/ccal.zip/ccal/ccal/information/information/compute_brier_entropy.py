from numpy import sort


def compute_brier_entropy(a, n=1):
    """
    Compute Brier entropy of a, assuming n correct assignments.
    Arguments:
        a (array): (n)
        n (int): number of correct assignments
    Returns:
        float: 0 <= float
    """

    # Compute probability
    p = a / a.sum()

    # Sort probability in descending order
    p = sort(p)
    p = p[::-1]

    brier_error = 0
    for i in range(n):
        brier_error += (1 - p[i])**2 + sum(
            [p[not_i]**2 for not_i in range(len(p)) if not_i != i])

    return brier_error
