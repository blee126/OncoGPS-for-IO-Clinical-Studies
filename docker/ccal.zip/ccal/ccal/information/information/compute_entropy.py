from numpy import log


def compute_entropy(a):
    """
    Compute entropy.
    Arguments:
        a (array): (n)
    Returns:
        float: 0 <= float
    """

    # Compute probability
    p = a / a.sum()

    # Compute entropy from probability
    return -(p * log(p)).sum()
